"""Install or remove optional pre-login startup. First enable Background alerts in CaDi as the target user."""
import argparse
import os
from pathlib import Path
import platform
import plistlib
import subprocess
import sys
import tempfile


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=("install","remove"))
    p.add_argument("--user",required=True,help="The unprivileged account that uses CaDi")
    p.add_argument("--watch-script",type=Path,required=True,help="Full path to the installed cadi_watch.py")
    args=p.parse_args()
    watch=args.watch_script.resolve(strict=True)
    if watch.name!="cadi_watch.py":p.error("Choose the installed cadi_watch.py.")
    install=args.action=="install"
    user=args.user
    if platform.system()=="Windows":
        import ctypes
        if not ctypes.windll.shell32.IsUserAnAdmin():p.error("Open PowerShell as administrator to register the boot task.")
        # Never load user-writable watcher code in this administrative process.
        buf=ctypes.create_unicode_buffer(32768)
        if not ctypes.windll.kernel32.GetSystemDirectoryW(buf,len(buf)):p.error("System directory unavailable")
        ps=Path(buf.value)/"WindowsPowerShell/v1.0/powershell.exe"
        env=os.environ.copy()
        env.update(CADI_USER=user,CADI_BIN=str(Path(sys.executable).with_name("pythonw.exe")),
                   CADI_ARGS=subprocess.list2cmdline(["-I","-B",str(watch),"loop"]),PSModulePath=str(ps.parent/"Modules"))
        base="""$ErrorActionPreference='Stop'; $sid=([System.Security.Principal.NTAccount]::new($env:CADI_USER)).Translate([System.Security.Principal.SecurityIdentifier]).Value;
if($sid -notmatch '^S-1-5-21-[0-9-]+$'){throw 'Choose a regular local or domain user.'}; $name='CaDi watch '+$sid; """
        command="""$a=New-ScheduledTaskAction -Execute $env:CADI_BIN -Argument $env:CADI_ARGS;
$t=New-ScheduledTaskTrigger -AtStartup;
$p=New-ScheduledTaskPrincipal -UserId $env:CADI_USER -LogonType S4U -RunLevel Limited;
$s=New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries;
Register-ScheduledTask -TaskName $name -Action $a -Trigger $t -Principal $p -Settings $s -Force | Out-Null""" if install else "Unregister-ScheduledTask -TaskName $name -Confirm:$false"
        subprocess.run([str(ps),"-NoProfile","-NonInteractive","-Command",base+command],env=env,check=True)
    else:
        import pwd
        account=pwd.getpwnam(user)
        if os.geteuid()!=0 or account.pw_uid<1:p.error("Run as administrator and choose your regular account.")
        if platform.system()=="Linux":
            if install: subprocess.run(["/usr/bin/loginctl","enable-linger",user],check=True)
            else:
                print("Turn off the CaDi user service in Incident monitor. User lingering may support other services and is left under your control.")
                return
        elif platform.system()=="Darwin":
            label="org.cadi.bootwatch."+str(account.pw_uid)
            path=Path("/Library/LaunchDaemons")/(label+".plist")
            subprocess.run(["/bin/launchctl","bootout","system/"+label],capture_output=True)
            if install:
                data=plistlib.dumps(dict(Label=label,UserName=user,ProgramArguments=[sys.executable,"-I","-B",str(watch),"loop"],
                    EnvironmentVariables={"HOME":account.pw_dir},RunAtLoad=True,KeepAlive={"SuccessfulExit":False},ThrottleInterval=20))
                with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as f:f.write(data);tmp=Path(f.name)
                tmp.chmod(0o644);os.replace(tmp,path)
                subprocess.run(["/bin/launchctl","bootstrap","system",str(path)],check=True)
            else:path.unlink(missing_ok=True)
        else:p.error("Unsupported operating system")
    print("Startup registration updated. Check the last sample time in Incident monitor after reboot.")


if __name__=="__main__":main()
