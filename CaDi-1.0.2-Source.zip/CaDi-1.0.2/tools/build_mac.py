"""Build an ad-hoc signed Intel macOS bundle from the locked Rust crate and pinned Python runtime."""
import argparse
import hashlib
import os
import platform
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = "x86_64-apple-darwin"
RUNTIME_URL = (
    "https://github.com/astral-sh/python-build-standalone/releases/download/"
    "20261124/cpython-3.12.16%2B20261124-x86_64-apple-darwin-install_only_stripped.tar.gz"
)
RUNTIME_SHA256 = "6d7ef4efa1adf65f312e6e865040ce03ef8a4bd7e1b45415193295c9ffc0dbdd"


def unpack_runtime(archive, destination):
    digest = hashlib.sha256()
    with archive.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != RUNTIME_SHA256:
        raise SystemExit("Python runtime checksum mismatch.")
    names = (ROOT / "macos/runtime-files.txt").read_text().splitlines()
    with tarfile.open(archive) as tar:
        for name in names:
            path = destination / name
            path.parent.mkdir(parents=True, exist_ok=True)
            entry = tar.getmember("python/" + name)
            with tar.extractfile(entry) as reader, path.open("wb") as writer:
                shutil.copyfileobj(reader, writer)
            path.chmod(entry.mode & 0o755)


def build(runtime, output):
    env = dict(os.environ, MACOSX_DEPLOYMENT_TARGET="10.15")
    with tempfile.TemporaryDirectory() as workdir:
        work = Path(workdir)
        if runtime is None:
            runtime = work / "python-runtime.tar.gz"
            with urllib.request.urlopen(RUNTIME_URL, timeout=120) as download, runtime.open("wb") as file:
                shutil.copyfileobj(download, file)
        app = work / "CaDi v1.app"
        contents = app / "Contents"
        resources = contents / "Resources"
        executable = contents / "MacOS/CaDi"
        executable.parent.mkdir(parents=True)
        unpack_runtime(runtime, resources / "runtime")
        subprocess.run(["cargo", "build", "--locked", "--release", "--target", TARGET,
                        "--target-dir", str(ROOT / "target")], cwd=ROOT, env=env, check=True)
        shutil.copy2(ROOT / "target" / TARGET / "release/cadi-desktop", executable)
        for script in ["cadi_guard.py","cadi_inspect.py","cadi_process.py","cadi_watch.py","cadi_recovery.py"]:
            shutil.copy2(ROOT / "engine" / script, resources)
        shutil.copy2(ROOT / "macos/CaDi.icns", resources)
        shutil.copy2(ROOT / "tools/install_boot_watch.py", resources)
        shutil.copy2(ROOT / "QUICKSTART.md",resources)
        shutil.copy2(ROOT / "macos/Info.plist", contents)
        shutil.copytree(ROOT / "macos/Licenses", resources / "Licenses")
        shutil.copy2(ROOT / "LICENSE", resources / "LICENSE")
        crate = resources / "Rust-source"
        shutil.copytree(ROOT / "src", crate / "src")
        for filename in ["Cargo.toml", "Cargo.lock"]:
            shutil.copy2(ROOT / filename, crate)
        for path in sorted((resources / "runtime").rglob("*")):
            if path.is_file():
                with path.open("rb") as file:
                    if file.read(4) == bytes.fromhex("cffaedfe"):
                        subprocess.run(["codesign", "--force", "--sign", "-", str(path)], check=True)
        subprocess.run(["codesign", "--force", "--sign", "-", str(app)], check=True)
        subprocess.run(["codesign", "--verify", "--deep", "--strict", str(app)], check=True)
        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=output.parent) as staged:
            archive = Path(staged) / "release.zip"
            subprocess.run(["ditto", "-c", "-k", "--keepParent", str(app), str(archive)], check=True)
            archive.replace(output)
    print(output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, help="Optional local copy of the pinned runtime archive")
    parser.add_argument("--output", type=Path, default=ROOT / "dist/CaDi-v1-Mac-Intel.zip")
    args = parser.parse_args()
    if platform.system() != "Darwin":
        parser.error("The bundle builder runs on macOS with Xcode Command Line Tools and Rust installed.")
    build(args.runtime, args.output)
