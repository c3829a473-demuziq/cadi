"""Local process visibility review and identity-checked requests to quit."""
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import time


def ps_rows():
    out = subprocess.check_output(["/bin/ps", "-A", "-o", "pid=", "-o", "comm="],
                                  timeout=10, text=True, errors="replace")
    result = {}
    for line in out.splitlines():
        parts = line.strip().split(None, 1)
        if len(parts) == 2 and parts[0].isdigit():
            result[int(parts[0])] = parts[1]
    return result


def unix_source(system):
    if system == "Linux":
        return {int(p.name) for p in Path("/proc").iterdir() if p.name.isdecimal()}
    lib = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
    count = lib.proc_listallpids(None, 0)
    if count <= 0:
        raise OSError("macOS process inventory unavailable.")
    for _ in range(3):
        buf = (ctypes.c_int * (count + 1024))()
        used = lib.proc_listallpids(buf, ctypes.sizeof(buf))
        if used > 0 and used < len(buf):
            return set(buf[:used])
        count = max(len(buf) * 2, used)
    raise OSError("macOS process inventory was incomplete.")


def repeated(samples):
    (a,b),(c,d) = samples
    return ((set(a)-set(b)) & (set(c)-set(d))) | ((set(b)-set(a)) & (set(d)-set(c)))


def key(pid, birth, path):
    return str(pid) + "-" + hashlib.sha256(json.dumps([pid, str(birth), str(path)]).encode()).hexdigest()


def linux_identity(pid):
    root = Path("/proc") / str(pid)
    tail = (root/"stat").read_text().rsplit(")",1)[1].split()
    birth = tail[19]
    path = (root/"exe").readlink()
    fields = dict(line.split(":",1) for line in (root/"status").read_text().splitlines() if ":" in line)
    home = Path.home().resolve()
    own = (os.getuid() != 0 and set(fields["Uid"].split()) == {str(os.getuid())}
           and int(fields["CapEff"],16) == 0 and path.is_absolute() and home in path.parents
           and path.stat().st_uid == os.getuid() and pid not in (0,1,os.getpid(),os.getppid())
           and path.name.lower() not in ("cadi", "cadi-desktop"))
    return key(pid,birth,path),str(path),own


MAC = """
ObjC.import('AppKit');
function run(args) {
 const active = $.NSWorkspace.sharedWorkspace.runningApplications, rows=[];
 for(let i=0;i<active.count;i++){
   const a=active.objectAtIndex(i);
   if(a.activationPolicy!==0 || !a.bundleURL || !a.executableURL || !a.launchDate)continue;
   const id=ObjC.unwrap(a.bundleIdentifier)||'',path=ObjC.unwrap(a.executableURL.path)||'';
   if(!id || id.startsWith('com.apple.') || id==='org.cadi.desktop' || !path)continue;
   const stamp=String(a.launchDate.timeIntervalSince1970),pid=Number(a.processIdentifier);
   if(args.length && pid===Number(args[0]) && stamp===args[1] && path===args[2])return a.terminate?'requested':'declined';
   rows.push([pid,stamp,path]);
 }
 return args.length?'changed':JSON.stringify(rows);
}"""


def mac_apps(*args):
    out = subprocess.check_output(["/usr/bin/osascript","-l","JavaScript","-e",MAC,*args],
                                  timeout=12, text=True).strip()
    return out if args else json.loads(out)


def mac_owned(pid):
    return os.geteuid()!=0 and subprocess.run(["/bin/ps","-p",str(pid),"-o","uid="],
               capture_output=True,text=True,timeout=4).stdout.strip()==str(os.geteuid())


def windows_source(ps):
    data = json.loads(ps("""$a=@(Get-Process | ForEach-Object {@{pid=$_.Id;name=$_.ProcessName}})
$b=@(Get-CimInstance Win32_Process | ForEach-Object {[int]$_.ProcessId})
@{a=$a;b=$b} | ConvertTo-Json -Depth 4 -Compress"""))
    return {int(x["pid"]):x["name"] for x in data["a"]}, set(data["b"])


def windows_apps(ps, selection=()):
    # The only substituted values are validated decimal PID and .NET UTC start ticks.
    target, birth = selection or (0,0)
    if not re.fullmatch(r"\d{1,10}",str(target)) or not re.fullmatch(r"\d{1,20}",str(birth)):
        raise ValueError("Invalid process identity")
    code = """$rows=@(); $me=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$session=(Get-Process -Id $PID).SessionId
foreach($p in Get-Process){
 try {
  if($p.SessionId -ne $session -or $p.MainWindowHandle -eq 0 -or $p.Id -le 4){continue}
  if(TARGET -ne 0 -and $p.Id -ne TARGET){continue}
  $null=$p.Handle; $birth=$p.StartTime.ToUniversalTime().Ticks.ToString(); $path=$p.MainModule.FileName
  if(!$path -or $path.StartsWith($env:SystemRoot+'\\',[StringComparison]::OrdinalIgnoreCase) -or $p.ProcessName -eq 'CaDi'){continue}
  $w=Get-CimInstance Win32_Process -Filter ('ProcessId='+$p.Id)
  if((Invoke-CimMethod -InputObject $w -MethodName GetOwnerSid).Sid -ne $me -or $p.HasExited){continue}
  if(TARGET -ne 0){if($birth -eq 'BORN' -and $p.CloseMainWindow()){'requested';return};continue}
  $rows+=,@($p.Id,$birth,$path)
 }catch{continue}
}
if(TARGET -ne 0){'changed'}else{ConvertTo-Json -InputObject $rows -Compress -Depth 4}"""
    out=ps(code.replace("TARGET",str(target)).replace("BORN",str(birth)))
    return out if selection else json.loads(out)


def scan(system, ps):
    samples=[]
    labels=("Get-Process", "Windows management inventory") if system=="Windows" else (
        "ps", "/proc" if system=="Linux" else "macOS libproc")
    for i in range(2):
        if i:
            time.sleep(.25)
        a,b = windows_source(ps) if system=="Windows" else (ps_rows(), unix_source(system))
        if not a or not b:
            raise ValueError("A process list was unavailable. Visibility could not be compared.")
        samples.append((a,b))
    mismatches=repeated(samples)
    common=set(samples[0][0]) & samples[0][1] & set(a) & b
    notes=[f"Compared {labels[0]} with {labels[1]} twice. {len(common)} PIDs appeared in all four lists."]
    for pid in sorted(mismatches):
        if pid:
            notes.append(f"[REVIEW] PID {pid} · {a.get(pid,'name unavailable')} · visible only in {labels[0] if pid in a else labels[1]} in both samples.")
    if not mismatches:
        notes.append("No repeated disagreement between the two lists.")
    notes.append("Permissions and process timing can affect these lists. Both rely on the OS. This check cannot establish whether a process is hidden by a rootkit.")
    apps={}
    try:
        if system in ("Windows","Darwin"):
            raw=windows_apps(ps) if system=="Windows" else mac_apps()
            for pid,birth,path in raw:
                if pid in common and (system=="Windows" or mac_owned(pid)):
                    apps[pid]=(key(pid,birth,path),path)
        else:
            for pid in common:
                try:
                    ident,path,own=linux_identity(pid)
                    if own and hasattr(os,"pidfd_open") and hasattr(signal,"pidfd_send_signal"):
                        apps[pid]=(ident,path)
                except (OSError, ValueError, IndexError, KeyError):
                    continue
    except (OSError, ValueError, subprocess.SubprocessError):
        notes.append("[UNKNOWN] The list of apps eligible to quit was unavailable.")
    items=[]
    for pid in sorted((common | mismatches)-{0}):
        name=a.get(pid) or "Name unavailable"
        identity,path=apps.get(pid,("",name))
        items.append(dict(id=identity,name=f"{pid} · {Path(name).name}",detail=path,
                          action="Ask app to quit" if identity else ""))
    return dict(items=items, notes=notes)


def stop(system, ident, ps):
    m=re.fullmatch(r"([1-9]\d{0,9})-[a-f0-9]{64}",ident)
    if not m:
        raise ValueError("Select an eligible process from a new scan.")
    pid=int(m[1])
    if system=="Linux":
        if not hasattr(os,"pidfd_open") or not hasattr(signal,"pidfd_send_signal"):
            raise ValueError("This system cannot bind a quit request to a specific running process.")
        fd=os.pidfd_open(pid)
        try:
            token, _, own=linux_identity(pid)
            if own and token==ident:
                signal.pidfd_send_signal(fd,signal.SIGTERM)
                return "Quit requested. A new scan will show whether the app exited."
        finally:
            os.close(fd)
    else:
        apps=windows_apps(ps) if system=="Windows" else mac_apps()
        for current,birth,path in apps:
            if current!=pid or key(pid,birth,path)!=ident:
                continue
            if system=="Windows":
                result=windows_apps(ps,(pid,birth))
            elif mac_owned(pid):
                result=mac_apps(str(pid),str(birth),path)
            else:
                break
            if result=="requested":
                return "Quit requested. The app may ask you to save. Rescan after it closes."
    raise ValueError("The app changed, exited, or declined the request. Scan again.")
