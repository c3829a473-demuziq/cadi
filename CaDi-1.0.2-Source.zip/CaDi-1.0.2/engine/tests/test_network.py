import concurrent.futures
import io
import json
import os
from pathlib import Path
import socket
import sys
import threading
import time
import unittest
from unittest.mock import Mock, patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import cadi_guard as g


class RoutingTests(unittest.TestCase):
    def test_protocol_89_is_raw_hex_field(self):
        h="sl local_address rem_address st"
        data=h+"\n0: 00000000:0059 00000000:0000 07\n1: 00000000:0006 00000000:0059 07"
        self.assertEqual(g.raw_ospf_count(data,4),1)
        self.assertEqual(g.raw_ospf_count(h+"\n0: "+"0"*32+":0059 foo 07",6),1)
        with self.assertRaises(ValueError): g.raw_ospf_count(h+"\ntruncated",4)

    def test_saved_frr_settings_hide_secrets(self):
        r=g.frr_flags("ospfd=yes\nospf6d=no\nospfd_options='private'\n# ospfd=no")
        self.assertEqual(r,{"ospfd":"yes","ospf6d":"no"})
        cfg="router ospf vrf private-vrf\n passive-interface default\n exit\nrouter ospf 2\n passive-interface default\n no passive-interface default\ninterface private\n ip ospf authentication-key private"
        r=g.saved_ospf_v2_defaults(cfg)
        self.assertEqual((r["ospfv2_router_stanzas"],r["explicit_passive_default"]),(2,1))
        self.assertNotIn("private",json.dumps(r))

    def test_frr_exact_vendor_mapping(self):
        for distro,status in (("debian","REVIEW"),("kali","UNKNOWN")):
            with patch.object(g,"execute",return_value="installed 8.4.4-1.1~deb12u2"),patch.object(g,"small_file",return_value=f"ID={distro}\nVERSION_CODENAME=bookworm"):
                self.assertEqual(g.frr_advisory()["status"],status)

    def test_interface_counter_reset_and_missing_capture_rights(self):
        a=dict(rx_bytes=100,rx_packets=4,tx_bytes=30,tx_packets=3)
        b=dict(a,rx_bytes=8,tx_bytes=40)
        with patch.object(g,"interface_counts",side_effect=[a,b]),patch.object(g,"observe_headers",side_effect=PermissionError()),patch.object(g.time,"sleep"):
            r=g.traffic_report("wg0",1,True)
        self.assertEqual(r["deltas"]["tx_bytes"],10)
        self.assertIsNone(r["deltas"]["rx_bytes"])
        self.assertIn("header_note",r)
        with self.assertRaises(g.Unavailable):g.traffic_report("../foo",1,False)

    @unittest.skipUnless(sys.platform.startswith("linux"),"Linux interface")
    def test_real_loopback_traffic(self):
        with socket.socket() as server, socket.socket() as client, concurrent.futures.ThreadPoolExecutor() as pool:
            server.bind(("127.0.0.1",0)); server.listen()
            client.connect(server.getsockname())
            conn,_=server.accept()
            with conn:
                future=pool.submit(g.traffic_report,"lo",1,False)
                time.sleep(.25)
                client.sendall(b"A"*2048); self.assertTrue(conn.recv(2048))
                r=future.result()
        self.assertGreaterEqual(r["deltas"]["rx_bytes"],2048)
        self.assertGreaterEqual(r["deltas"]["tx_bytes"],2048)


class WorkersAndConnectorTests(unittest.TestCase):
    def test_scheduler_thresholds(self):
        for m,c,limit in [(80,4,0),(128,8,1),(None,8,1),(2047,4,1),(2048,4,2),(4096,1,1)]:
            self.assertEqual(g.worker_limit(m,c),limit)
        with patch.object(g,"available_mib",return_value=100),patch.object(g,"bounded_output") as launch:
            report=g.run_workers("Linux",["traffic","ospf"],1,"lo")
            launch.assert_not_called()
            self.assertTrue(all(r["status"]=="SKIPPED" for r in report["results"].values()))

    def test_failure_isolated(self):
        def child(argv,*args,**kwargs):
            if "traffic" in argv:raise g.Unavailable("Interface unavailable")
            return '{"check":"Local OSPF"}'
        with patch.object(g,"available_mib",return_value=512),patch.object(g,"bounded_output",side_effect=child):
            r=g.run_workers("Linux",["traffic","ospf"],1,"lo")
        self.assertEqual(r["results"]["traffic"]["status"],"UNAVAILABLE")
        self.assertEqual(r["results"]["ospf"]["status"],"COMPLETED")

    def test_child_timeout_and_output_limit(self):
        with self.assertRaises(g.Unavailable):
            g.bounded_output([sys.executable,"-c","print('a'*1024)"],None,None,limit=100)
        with self.assertRaises(g.Unavailable):
            g.bounded_output([sys.executable,"-c","import time;time.sleep(10)"],None,None,timeout=.15)

    def test_validation(self):
        for name,args in [("apply",{}),("interface_sample",{"interface":"lo","seconds":31}),("interface_sample",{"interface":"../../etc"}),
                          ("run_workers",{"checks":["arbitrary-shell"]}),("run_workers",{"checks":["ospf","ospf"]}),
                          ("hardening_plan",{"control":"bogus"}),("host_audit",{"command":"arbitrary"})]:
            with self.subTest(name=name),self.assertRaises((ValueError,g.Unavailable)):
                g.connector_call("Linux",name,args)
        with patch.object(g,"execute") as run:
            report=g.connector_call("Linux","hardening_plan",{"control":"linux-ufw"})
            self.assertEqual(report["preview_command"],"cadi-guard plan linux-ufw")
            run.assert_not_called()

    def test_stdio_and_request_limit(self):
        messages=[
          {"id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25"}},
          {"method":"notifications/initialized"},
          {"id":2,"method":"tools/list"},
          {"id":3,"method":"tools/call","params":{"name":"hardening_plan","arguments":{}}},
          {"id":4,"method":"tools/call","params":{"name":"run_workers","arguments":{"checks":["injection"]}}},
        ]
        inp=b"".join((json.dumps(dict(x,jsonrpc="2.0"))+"\n").encode() for x in messages)
        out=io.BytesIO();g.mcp_server("Linux",io.BytesIO(inp),out)
        replies=list(map(json.loads,out.getvalue().splitlines()))
        self.assertEqual([r["id"] for r in replies],[1,2,3,4])
        self.assertNotIn("apply",[t["name"] for t in replies[1]["result"]["tools"]])
        self.assertFalse(replies[2]["result"]["isError"])
        self.assertEqual(replies[3]["error"]["code"],-32602)
        out=io.BytesIO();g.mcp_server("Linux",io.BytesIO(b"X"*65537),out)
        self.assertIn("error",json.loads(out.getvalue()))

    def test_command_panel_safe_embedding(self):
        with patch.object(g,"entry_args",return_value=["/my python","-I","/tmp/</script>123"]):
            html=g.panel_html("Linux")
        self.assertNotIn("/tmp/</script>",html)
        self.assertIn("Copy worker command",html)
        self.assertIn("Copy Hermes configuration",html)

class RemovedFeatureTests(unittest.TestCase):
    def test_old_commands_are_rejected_and_remaining_cli_are_visible(self):
        import contextlib
        for cmd in ("cleanup", "remove", "tunnel"):
            with self.subTest(cmd=cmd), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as result:
                    g.main([cmd])
                self.assertEqual(result.exception.code, 2)
        out = io.StringIO()
        with contextlib.redirect_stdout(out), self.assertRaises(SystemExit):
            g.main(["--help"])
        self.assertIn("processes", out.getvalue())
        self.assertIn("audit", out.getvalue())

    def test_connector_and_command_builder_do_not_offer_removed_checks(self):
        for system in ("Linux", "Darwin", "Windows"):
            specs = g.connector_tools(system)
            names = {item["name"] for item in specs}
            self.assertIn("host_audit", names)
            self.assertNotIn("tunnel_sample", names)
            self.assertNotIn("tunnel", g.worker_choices(system))
            self.assertEqual("run_workers" in names, system == "Linux")
        self.assertNotIn("tailscale", g.panel_html("Linux").lower())
