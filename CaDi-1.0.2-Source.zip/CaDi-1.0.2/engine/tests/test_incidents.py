import importlib.util,json,os,pathlib,shutil,subprocess,sys,tempfile,unittest,zipfile
from unittest.mock import patch
P=pathlib.Path
root=P(__file__).resolve().parents[1]
def module(name):
    spec=importlib.util.spec_from_file_location(name,root/(name+".py"))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
proc=module("cadi_process");watch=module("cadi_watch");backup=module("cadi_recovery")


class ProcessTests(unittest.TestCase):
    def test_persistent_disagreement_only(self):
        self.assertEqual(proc.repeated([({1,2,7},{1,3,4}),({1,2,4},{1,3,7})]),{2,3})
    def test_changed_birth_refused(self):
        with patch.object(proc.os,"pidfd_open",create=True,return_value=42),patch.object(proc.os,"close"),patch.object(proc.signal,"pidfd_send_signal",create=True) as send,patch.object(proc,"linux_identity",return_value=("different","app",True)):
            with self.assertRaises(ValueError):proc.stop("Linux",proc.key(4321,"birth","path"),None)
            send.assert_not_called()
    def test_nonowned_app_refused(self):
        ident=proc.key(4321,2,"test")
        with patch.object(proc.os,"pidfd_open",create=True,return_value=43),patch.object(proc.os,"close"),patch.object(proc.signal,"pidfd_send_signal",create=True) as send,patch.object(proc,"linux_identity",return_value=(ident,"test",False)):
            with self.assertRaises(ValueError):proc.stop("Linux",ident,None)
            send.assert_not_called()
    def test_windows_clock_and_owner_rechecked(self):
        ident=proc.key(234,"1234","An app.exe")
        with patch.object(proc,"windows_apps",side_effect=[[(234,"5678","An app.exe")]]) as apps:
            with self.assertRaises(ValueError):proc.stop("Windows",ident,None)
            self.assertEqual(apps.call_count,1)


class MonitorTests(unittest.TestCase):
    def sample(self):return {"k":dict(service="SSH",local="192.0.2.1",port=22,peer="192.0.2.2",peer_port=15000)}
    def test_default_offline_and_persistent_dedupe(self):
        with tempfile.TemporaryDirectory() as d, patch.object(watch,"post") as remote:
            root=P(d);notice=[]
            for _ in range(2):watch.observe(root,"Linux",self.sample(),lambda *args:notice.append(args))
            self.assertEqual(len(notice),1);remote.assert_not_called()
            self.assertEqual(len(watch.read(root/"events.json",{})["events"]),1)
            self.assertIn("192.0.2.2",watch.report(root))
    def test_local_only_model_and_bounded_frequency(self):
        with tempfile.TemporaryDirectory() as d,patch.object(watch,"post",return_value=b'{"choices":[{"message":{"content":"Review the login."}}]}') as post:
            folder=P(d);watch.write(folder/"config.json",{"model":"local","url":"http://127.0.0.1:11434/v1"})
            for inventory in [self.sample(),{},self.sample()]:watch.observe(folder,"Linux",inventory,lambda *_:None)
            self.assertEqual(post.call_count,1);self.assertNotIn(b"192.0.2.2",post.call_args.args[1])
            self.assertIn("Review the login",watch.report(folder))
    def test_endpoint_restrictions(self):
        for dest in ["https://host.invalid/v1","http://127.0.0.1.example.org:443/v1","http://user:secret@127.0.0.1:11434/v1"]:
            with self.assertRaises(ValueError):watch.endpoint(dest,True)
        with self.assertRaises(ValueError):watch.endpoint("http://example.org/topic",False)
    def test_corrupt_backup_rejected_without_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            root=P(d);archive=root/"bad.cadi"
            with zipfile.ZipFile(archive,"w") as z:
                z.writestr("contents",b"broken");z.writestr("manifest.json",json.dumps(dict(name="saved",sha256="bad")))
            with self.assertRaisesRegex(ValueError,"verification failed"):backup.restore(archive,root)
            self.assertFalse(list(root.glob("Recovered-*")))
    def test_manual_recovery_writes_a_new_copy(self):
        with tempfile.TemporaryDirectory() as d:
            root=P(d);src=root/"song.txt";src.write_text("original")
            archive=P(backup.save(src,root).splitlines()[-1]);src.write_text("changed")
            recovered=P(backup.restore(archive,root).splitlines()[-1])
            self.assertEqual(src.read_text(),"changed");self.assertEqual(recovered.read_text(),"original")
