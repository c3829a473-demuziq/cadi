"""Run with python3 -m unittest discover -s tests from the source tree."""
import contextlib
import io
import ipaddress
import json
import os
import socket
import stat
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cadi_guard as g


class ListenerTests(unittest.TestCase):
    def test_linux_decode(self):
        header = "sl local_address rem_address st"
        import struct
        raw = socket.inet_pton(socket.AF_INET6, "::ffff:127.0.0.1")
        encoded = "".join(f"{n:08X}" for n in struct.unpack("=IIII", raw))
        self.assertEqual(g.linux_tcp_table(header+"\n0: "+encoded+":2253 0 0A", 6),
                         [(str(ipaddress.ip_address(raw)), 8787)])
        self.assertEqual(g.ip_scope("::ffff:7f00:1"), "loopback")

    def test_unknown_or_partial(self):
        for bad in ("", "permission denied", "sl local_address rem_address st\ntruncated"):
            with self.assertRaises(ValueError):
                g.linux_tcp_table(bad, 4)
        rows, _ = g.listen_findings([("127.0.0.1", 22)], ["IPv6 unavailable"])
        self.assertEqual([x.status for x in rows], ["UNKNOWN"])

    def test_mac_listener_formats(self):
        raw = """Active Internet connections
Proto Recv-Q Send-Q Local Address Foreign Address (state)
tcp46 0 0 *.8787 *.* LISTEN
tcp6 0 0 fe80::1%en0.22 *.* LISTEN
tcp4 0 0 127.0.0.1.22 127.0.0.1.23944 ESTABLISHED"""
        res = g.mac_tcp_table(raw)
        findings, records = g.listen_findings(res, [])
        self.assertEqual([r["scope"] for r in records], ["all interfaces", "interface address"])
        self.assertEqual([x.status for x in findings], ["REVIEW", "REVIEW"])

    def test_windows_ports(self):
        raw = '[{"LocalAddress":"::","LocalPort":8788},{"LocalAddress":"127.0.0.2","LocalPort":5432}]'
        items, records = g.listen_findings(g.windows_tcp_table(raw), [])
        self.assertEqual(len(items), 1)
        self.assertIn("8788", items[0].title)
        self.assertNotIn("proxy", items[0].title.lower())
        self.assertEqual(records[1]["scope"], "loopback")
        with self.assertRaises(ValueError):
            g.windows_tcp_table("null")

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux kernel interface")
    def test_live_linux_listener(self):
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            sock.listen()
            seen, _ = g.listeners("Linux")
            self.assertIn(sock.getsockname(), seen)


class NativeChecks(unittest.TestCase):
    def test_mac_parses_known_states_only(self):
        for raw, key, expected in [
            ("Firewall is disabled. (State = 0)", "mac-firewall", "0"),
            ("Firewall is enabled. (State = 1)", "mac-firewall", "1"),
            ("Firewall is set to block all non-essential incoming connections. (State = 2)", "mac-firewall", "2"),
            ("Firewall stealth mode is on", "mac-stealth", "1"),
            ("Stealth mode disabled", "mac-stealth", "0"),
        ]:
            with patch.object(g, "execute", return_value=raw):
                self.assertEqual(g.mac_value(key), expected)
        for raw in ("Unexpected message", "Firewall is disabled. (State = 1)"):
            with patch.object(g, "execute", return_value=raw), self.assertRaises(g.Unavailable):
                g.mac_value("mac-firewall")

    def test_windows_effective_profiles_and_unknown(self):
        raw = '[{"Name":"Public","Active":"True"},{"Name":"Private","Active":"False"}]'
        with patch.object(g, "powershell", return_value=raw):
            self.assertEqual([x.status for x in g.win_firewall()], ["UNKNOWN", "REVIEW", "OK"])
        with patch.object(g, "powershell", return_value="NotConfigured"), self.assertRaises(g.Unavailable):
            g.win_smb_value()

    def test_linux_ufw(self):
        for raw, expected in [("Status: active\n", "1"), ("Status: inactive", "0")]:
            with patch.object(g, "execute", return_value=raw):
                self.assertEqual(g.ufw_value(), expected)
        with patch.object(g, "execute", return_value=""), self.assertRaises(g.Unavailable):
            g.ufw_value()

    def test_ssh_and_permissive_ufw_refused(self):
        with patch.dict(os.environ, {"SSH_TTY":"/dev/test"}), self.assertRaises(g.Unavailable):
            g.local_console()
        with patch.dict(os.environ, {}, clear=True), patch.object(Path, "read_text", return_value='DEFAULT_INPUT_POLICY="ACCEPT"'), self.assertRaises(g.Unavailable):
            g.ufw_preview()

    def test_managed_public_profile_refused(self):
        ctrl = g.platform_controls("Windows")["windows-public-firewall"]
        with patch.object(g, "local_console"), patch.object(g.ctypes, "windll", create=True) as win, patch.object(g, "win_bool", return_value="1"):
            win.shell32.IsUserAnAdmin.return_value = 1
            with self.assertRaises(g.Unavailable):
                ctrl.ready()

    def test_windows_control_is_fixed(self):
        ctrl = g.platform_controls("Windows")["windows-smb-signing"]
        with patch.object(g, "powershell") as ps:
            ctrl.write()
            ps.assert_called_once_with("Set-SmbServerConfiguration -RequireSecuritySignature $true -Confirm:$false", privileged=True)


class ChangeTests(unittest.TestCase):
    def setUp(self):
        self.enterContext_compat(contextlib.redirect_stdout(io.StringIO()))

    def enterContext_compat(self, cm):
        cm.__enter__()
        self.addCleanup(cm.__exit__, None, None, None)

    def control(self, reads):
        return g.Control("setting", "impact", Mock(side_effect=reads), Mock(), "enable", "undo")

    def test_preview_never_writes(self):
        c = self.control(["0"])
        g.change(c, False)
        c.write.assert_not_called()

    def test_already_enabled_no_write(self):
        c = self.control(["1"])
        g.change(c, True)
        c.write.assert_not_called()

    def test_apply_verifies(self):
        c = self.control(["0", "0", "1"])
        with patch.object(g, "confirm"):
            g.change(c, True)
        c.write.assert_called_once()
        self.assertEqual(c.read.call_count, 3)

    def test_changed_during_prompt_or_unknown(self):
        for reads in (["0", "1"], ["2"]):
            c = self.control(reads)
            with patch.object(g, "confirm"), self.assertRaises(g.Unavailable):
                g.change(c, True)
            c.write.assert_not_called()

    def test_false_success_rejected(self):
        c = self.control(["0", "0", "0"])
        with patch.object(g, "confirm"), self.assertRaises(g.Unavailable):
            g.change(c, True)

    def test_piped_apply_stops_before_privileged_read(self):
        with patch.object(sys.stdin, "isatty", return_value=False), patch.object(g, "execute") as run, contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(g.main(["apply", "linux-ufw"]), 1)
            run.assert_not_called()

    def test_ordinary_cancel(self):
        with patch.object(sys.stdin, "isatty", return_value=True), patch("builtins.input", return_value="no"), self.assertRaises(g.Unavailable):
            g.confirm()


@unittest.skipIf(os.name == "nt", "POSIX permissions")
class FileTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.file = self.root / "config.json"
        self.file.write_text("PRIVATE-TEST-SENTINEL")
        self.file.chmod(0o640)

    def test_only_permissions_change(self):
        with contextlib.redirect_stdout(io.StringIO()) as output, patch.object(g, "confirm"):
            g.restrict_file(self.root, "config.json", False)
            self.assertEqual(stat.S_IMODE(self.file.stat().st_mode), 0o640)
            g.restrict_file(self.root, "config.json", True)
            g.restrict_file(self.root, "config.json", True)
        self.assertEqual(stat.S_IMODE(self.file.stat().st_mode), 0o600)
        self.assertIn("chmod 0640", output.getvalue())
        self.assertNotIn("PRIVATE-TEST-SENTINEL", output.getvalue())
        self.assertEqual(self.file.read_text(), "PRIVATE-TEST-SENTINEL")

    def test_refs_refused(self):
        for hard in (False, True):
            target = self.root / "alternate"
            (os.link if hard else os.symlink)(self.file, target)
            with self.assertRaises((g.Unavailable, OSError)):
                with g.owned_file(self.root, "alternate"):
                    self.fail("linked file accepted")
            target.unlink()
        self.root.chmod(0o770)
        with self.assertRaises(g.Unavailable):
            with g.owned_file(self.root, "config.json"):
                self.fail("group-writable deployment accepted")

    def test_replaced_path_aborts(self):
        def replace():
            self.file.rename(self.root / "old")
            self.file.write_text("replacement")
        with contextlib.redirect_stdout(io.StringIO()), patch.object(g, "confirm", side_effect=replace), self.assertRaises(g.Unavailable):
            g.restrict_file(self.root, "config.json", True)
        self.assertEqual(stat.S_IMODE((self.root / "old").stat().st_mode), 0o640)

    def test_keys_symlink_not_traversed(self):
        sub = self.root / "outside"
        sub.mkdir()
        (sub / "jwt.key").write_text("PRIVATE-TEST-SENTINEL")
        (self.root / "keys").symlink_to(sub, target_is_directory=True)
        findings = g.secret_findings(self.root, "Linux")
        self.assertEqual([x.status for x in findings if x.id == "cadi-keys"], ["REVIEW"])
        self.assertFalse(any(x.id.endswith("jwt.key") for x in findings))
        self.assertNotIn("PRIVATE-TEST-SENTINEL", json.dumps([vars(x) for x in findings]))


if __name__ == "__main__":
    unittest.main()
