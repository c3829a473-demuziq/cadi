import importlib.util,sys,pathlib,subprocess,unittest,json
from unittest.mock import patch
path=pathlib.Path(__file__).resolve().parents[1] / 'cadi_guard.py'
spec=importlib.util.spec_from_file_location('guard',path)
g=importlib.util.module_from_spec(spec);sys.modules['guard']=g;spec.loader.exec_module(g)
real_run = subprocess.run
class HardeningTests(unittest.TestCase):
 def simulate(self,fw,stealth,selected,mode='success'):
  state={'mac-firewall':fw,'mac-stealth':stealth};calls=[]
  def admin(argv,**kwargs):
   self.assertEqual(argv[:2],['/usr/bin/osascript','-e'])
   self.assertTrue(argv[2].endswith(' with administrator privileges'))
   source=json.loads(argv[2][len('do shell script '):-len(' with administrator privileges')]);calls.append(source)
   self.assertEqual(real_run(['/bin/sh','-n'],input=source,text=True).returncode,0)
   if mode=='cancel':return subprocess.CompletedProcess(argv,1,b'',b'cancelled (-128)')
   if '--setglobalstate on' in source:state['mac-firewall']='1'
   if '--setstealthmode on' in source and mode!='partial':state['mac-stealth']='1'
   return subprocess.CompletedProcess(argv,0,b'',b'')
  with patch.object(g,'mac_value',side_effect=state.__getitem__),patch.object(g.subprocess,'run',side_effect=admin):
   return g.desktop_harden(selected),calls
 def test_all_enabled_requires_no_admin(self):
  text,calls=self.simulate('1','1',['mac-firewall','mac-stealth']);self.assertFalse(calls);self.assertIn('already enabled',text)
 def test_enable_both_then_verify(self):
  text,calls=self.simulate('0','0',['mac-firewall','mac-stealth']);self.assertEqual(len(calls),1);self.assertEqual(text.count('is now enabled'),2);self.assertEqual(text.count('To restore'),2)
 def test_preserve_block_all(self):
  text,calls=self.simulate('2','0',['mac-firewall','mac-stealth']);self.assertNotIn('--setglobalstate on',calls[0]);self.assertIn('Application firewall was already',text);self.assertIn('stealth mode is now',text)
 def test_stealth_needs_firewall(self):
  with self.assertRaisesRegex(g.Unavailable,'Select the application firewall'): self.simulate('0','0',['mac-stealth'])
 def test_cancel(self):
  with self.assertRaisesRegex(g.Unavailable,'cancelled'): self.simulate('1','0',['mac-stealth'],'cancel')
 def test_partial_change_is_reported(self):
  with self.assertRaisesRegex(g.Unavailable,'(?s)Application firewall is now enabled.*stealth mode is still off'): self.simulate('0','0',['mac-firewall','mac-stealth'],'partial')
 @unittest.skipIf(sys.platform == "darwin", "non-macOS CLI guard")
 def test_nonmac_blocked(self):
  r=subprocess.run([sys.executable,'-I',str(path),'desktop-harden','mac-firewall'],capture_output=True,text=True);self.assertIn('requires macOS',r.stderr);self.assertNotEqual(r.returncode,0)
if __name__=='__main__':unittest.main()
