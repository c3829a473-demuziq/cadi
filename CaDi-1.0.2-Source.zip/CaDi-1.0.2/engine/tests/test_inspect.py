import importlib.util
import json
import os
from pathlib import Path
import plistlib
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

path = Path(__file__).resolve().parents[1] / "cadi_inspect.py"
spec = importlib.util.spec_from_file_location("inspect_engine", path)
inspect = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inspect)


class KernelTests(unittest.TestCase):
    def test_mac_versions_and_unknown_branch(self):
        for version, status in [("13.6.4", "REVIEW"), ("13.6.5", "CHECKED"), ("13.7", "CHECKED"),
                                ("14.3.1", "REVIEW"), ("15.1", "UNKNOWN"), ("?", "UNKNOWN")]:
            self.assertIn(status, inspect.mac_advisory(version))

    def test_windows_revision_boundaries(self):
        for build, rev, status in [(19045, 4528, "REVIEW"), (22631, 3737, "CHECKED"),
                                    (99999, 100, "UNKNOWN"), (19045, None, "UNKNOWN")]:
            self.assertIn(status, inspect.win_advisory(build, rev))

    def test_windows_update_partial_is_unknown(self):
        with patch.object(inspect, "ps", return_value=json.dumps({"status": 3, "updates": []})):
            self.assertIn("UNKNOWN", inspect.windows_updates())

    def test_software_update_output(self):
        with patch.object(inspect, "run", side_effect=["* Label: macOS Example", "No new software available.", ""]):
            self.assertIn("REVIEW", inspect.mac_updates())
            self.assertIn("offered no updates", inspect.mac_updates())
            self.assertIn("UNKNOWN", inspect.mac_updates())

    def test_linux_cpu_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            for name, val in [("a", "Vulnerable"), ("b", "Not affected"), ("c", "Unknown")]:
                (root/name).write_text(val)
            text = inspect.linux_mitigations(root)
            for word in ["[REVIEW] a", "[INFO] b", "[UNKNOWN] c"]:
                self.assertIn(word, text)

    def test_debian_running_kernel_identity(self):
        osr = {"ID": "debian", "VERSION_CODENAME": "trixie"}
        pkg = "ii |linux-image-6.12-test|6.12.43-1|"
        with patch.object(inspect, "run", return_value=pkg), patch.object(Path, "read_text", return_value="Debian 6.12.40-1 (2025-01-01)"):
            self.assertIn("UNKNOWN", inspect.deb_advisory(osr, "6.12-test"))
        with patch.object(inspect, "run", return_value=pkg), patch.object(Path, "read_text", return_value="Debian 6.12.43-1 (2025-08-01)"), patch.object(subprocess,"run", return_value=subprocess.CompletedProcess([],1)):
            self.assertIn("CHECKED", inspect.deb_advisory(osr, "6.12-test"))
