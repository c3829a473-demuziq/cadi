"""CaDi background connection alerts. Runs as the signed-in user, without elevated rights."""
import argparse
import datetime as dt
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import platform
import plistlib
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request

PORTS = {22:"SSH", 3389:"Remote Desktop", 5900:"Screen Sharing/VNC", 3283:"Remote Management"}
SCRIPT = Path(__file__).resolve()
LABEL = "org.cadi.connectionwatch"


def location():
    if os.name=="nt": return Path(os.environ["LOCALAPPDATA"])/"CaDi"/"watch"
    if sys.platform=="darwin": return Path.home()/"Library/Application Support/CaDi/watch"
    return Path(os.environ.get("XDG_CONFIG_HOME",Path.home()/".config"))/"cadi/watch"


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def read(path, default):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError: return default


def write(path, obj):
    path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile("w",dir=path.parent,prefix=".cadi-",delete=False,encoding="utf-8") as f:
        name=Path(f.name)
        try:
            json.dump(obj,f,ensure_ascii=True)
            f.flush()
            os.fsync(f.fileno())
        except BaseException:
            name.unlink(missing_ok=True)
            raise
    try: os.replace(name,path)
    finally: name.unlink(missing_ok=True)


def native_powershell(code, **kwargs):
    import ctypes
    buf=ctypes.create_unicode_buffer(32768)
    if not ctypes.windll.kernel32.GetSystemDirectoryW(buf,len(buf)): raise OSError("Cannot find Windows PowerShell")
    ps=Path(buf.value)/"WindowsPowerShell/v1.0/powershell.exe"
    env=os.environ.copy()
    env.update(kwargs.pop("env",{}),PSModulePath=str(ps.parent/"Modules"))
    return subprocess.check_output([str(ps),"-NoProfile","-NonInteractive","-Command",
        "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new(); "+code],
        text=True,encoding="utf-8",errors="replace",timeout=18,env=env,creationflags=0x08000000,**kwargs)


def proc_address(value):
    raw,port=value.rsplit(":",1)
    buf=bytes.fromhex(raw)
    packed=b"".join(int.from_bytes(buf[i:i+4],"big").to_bytes(4,sys.byteorder) for i in range(0,len(buf),4))
    return str(ipaddress.ip_address(packed)),int(port,16)


def connections(system):
    rows=[]
    if system=="Linux":
        sources=0
        for file in (Path("/proc/net/tcp"),Path("/proc/net/tcp6")):
            try: lines=file.read_text().splitlines()[1:]
            except FileNotFoundError: continue
            sources+=1
            for line in lines:
                f=line.split()
                if len(f)>3 and f[3]=="01":
                    local,port=proc_address(f[1]);peer,rport=proc_address(f[2])
                    rows.append((local,port,peer,rport))
        if not sources:raise ValueError("No Linux TCP inventory available")
    elif system=="Darwin":
        data=subprocess.check_output(["/usr/sbin/netstat","-an","-p","tcp"],timeout=12,text=True)
        for line in data.splitlines():
            cols=line.split()
            if len(cols)>=6 and cols[0].startswith("tcp") and cols[5]=="ESTABLISHED":
                local,port=cols[3].rsplit(".",1);peer,rport=cols[4].rsplit(".",1)
                rows.append((local,int(port),peer,int(rport)))
    elif system=="Windows":
        raw=native_powershell("""$r=@(Get-NetTCPConnection -ErrorAction Stop | Where-Object {$_.State -eq 'Established'} |
ForEach-Object {@{l=$_.LocalAddress;p=$_.LocalPort;r=$_.RemoteAddress;q=$_.RemotePort}})
if(!(Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue)){throw 'TCP inventory unavailable'}
ConvertTo-Json -InputObject $r -Compress""")
        rows=[(r["l"],int(r["p"]),r["r"],int(r["q"])) for r in json.loads(raw)]
    else:raise ValueError("Unsupported platform")
    result={}
    for local,port,peer,rport in rows:
        if port not in PORTS:continue
        addr=ipaddress.ip_address(peer.split("%")[0])
        addr=getattr(addr,"ipv4_mapped",None) or addr
        if addr.is_loopback:continue
        result[f"{local}|{port}|{peer}|{rport}"]={"service":PORTS[port],"local":local,"port":port,"peer":peer,"peer_port":rport}
    return result


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args): return None


def endpoint(url, local):
    v=urllib.parse.urlsplit(url)
    if not v.hostname or v.username or v.password or v.fragment or v.query:
        raise ValueError("Enter an endpoint without credentials, query or fragment.")
    if local:
        if v.scheme!="http" or v.hostname not in ("127.0.0.1","::1") or v.port is None or v.path not in ("","/","/v1","/v1/"):
            raise ValueError("Use an on-device model server such as http://127.0.0.1:11434/v1.")
        return urllib.parse.urlunsplit((v.scheme,v.netloc,"/v1/chat/completions","",""))
    if v.scheme!="https" or not v.path.strip("/"):
        raise ValueError("Use a private HTTPS ntfy topic URL.")
    return url


def post(url, data, headers):
    client=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    request=urllib.request.Request(url,data=data,headers=headers,method="POST")
    with client.open(request,timeout=9) as response:
        raw=response.read(32769)
        if len(raw)>32768:raise ValueError("Response too large")
        return raw


def local_notice(system, count):
    msg=f"Review {count} newly observed remote connection(s) in CaDi v1."
    if system=="Darwin":
        subprocess.run(["/usr/bin/osascript","-e",'on run argv\n display notification (item 1 of argv) with title "CaDi v1"\nend run',msg],check=True,timeout=6,capture_output=True)
    elif system=="Windows":
        native_powershell("""Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing
$n=New-Object Windows.Forms.NotifyIcon; $n.Icon=[Drawing.SystemIcons]::Information; $n.Visible=$true
$n.ShowBalloonTip(3500,'CaDi v1','Review a newly observed remote connection in CaDi.',[Windows.Forms.ToolTipIcon]::Info)
Start-Sleep -Seconds 4; $n.Dispose()""")
    elif Path("/usr/bin/notify-send").is_file():
        subprocess.run(["/usr/bin/notify-send","CaDi v1",msg],timeout=5,check=True,capture_output=True)
    else:raise ValueError("No desktop notification service")


def observe(folder, system, inventory, notify=local_notice):
    policy=read(folder/"config.json",{})
    state=read(folder/"events.json",{})
    now=stamp(); previous=set(state.get("current",[]))
    new=[event for k,event in inventory.items() if k not in previous]
    events=state.get("events",[])
    record={"time":now,"type":"New remote connection","connections":new[:40],"count":len(new)}
    if new:events.append(record)
    state.update(current=list(inventory),events=events[-150:],last_check=now,problem="")
    if new:
        # Persist the local observation before optional, interruptible notifications.
        write(folder/"events.json",state)
        try: notify(system,len(new))
        except (OSError,ValueError,subprocess.SubprocessError):
            record["local_notice"]="Recorded locally. A desktop notification was unavailable."
        if policy.get("phone"):
            try: post(endpoint(policy["phone"],False),b"CaDi v1 observed a new remote connection. Review the local incident log.",{})
            except (OSError,ValueError): record["phone"]="Delivery unconfirmed. See local log."
        if policy.get("model") and time.time()-state.get("last_model",0)>=600:
            state["last_model"]=time.time()
            try:
                body={"model":policy["model"],"stream":False,"max_tokens":160,"messages":[
                    {"role":"system","content":"Explain this network observation in two short sentences. It is not evidence of successful authentication. Suggest one local verification. You cannot take actions."},
                    {"role":"user","content":"New established connections on these local service ports: "+", ".join(sorted({x["service"] for x in new}))}]}
                result=json.loads(post(endpoint(policy["url"],True),json.dumps(body).encode(),{"Content-Type":"application/json"}))
                note=result["choices"][0]["message"]["content"]
                if isinstance(note,str):record["model_note"]=note[:1200]
            except (OSError,ValueError,IndexError,KeyError,TypeError):
                record["model_note"]="The on-device model was unavailable."
    write(folder/"events.json",state)
    return state


def monitor_loop(folder):
    folder.mkdir(mode=0o700,parents=True,exist_ok=True)
    with (folder/"worker.lock").open("a+b") as lock:
        try:
            if os.name=="nt":
                import msvcrt
                lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:return
        while (folder/"enabled").is_file():
            try: observe(folder,platform.system(),connections(platform.system()))
            except (OSError,ValueError,subprocess.SubprocessError) as e:
                try:state=read(folder/"events.json",{})
                except ValueError: state={}
                state.update(problem="The connection check could not finish: "+str(e)[:220],last_attempt=stamp())
                write(folder/"events.json",state)
            for _ in range(15):
                if not (folder/"enabled").is_file():return
                time.sleep(1)


def registration(folder, enable):
    system=platform.system()
    folder.mkdir(mode=0o700,parents=True,exist_ok=True)
    marker=folder/"enabled"
    if enable: marker.touch(mode=0o600)
    else: marker.unlink(missing_ok=True)
    cmd=[sys.executable,"-I","-B",str(SCRIPT),"loop"]
    try:
        if system=="Darwin":
            plist=Path.home()/"Library/LaunchAgents"/(LABEL+".plist")
            domain=f"gui/{os.getuid()}"
            if enable:
                plist.parent.mkdir(parents=True,exist_ok=True)
                data=plistlib.dumps({"Label":LABEL,"ProgramArguments":cmd,"RunAtLoad":True,"KeepAlive":{"SuccessfulExit":False},"ThrottleInterval":15})
                with tempfile.NamedTemporaryFile(dir=plist.parent,delete=False) as f:f.write(data);temp=Path(f.name)
                os.replace(temp,plist)
                subprocess.run(["/bin/launchctl","bootout",domain+"/"+LABEL],capture_output=True,timeout=12)
                subprocess.run(["/bin/launchctl","bootstrap",domain,str(plist)],check=True,capture_output=True,timeout=15)
            else:
                subprocess.run(["/bin/launchctl","bootout",domain+"/"+LABEL],capture_output=True,timeout=12)
                plist.unlink(missing_ok=True)
        elif system=="Linux":
            unit=Path(os.environ.get("XDG_CONFIG_HOME",Path.home()/".config"))/"systemd/user/cadi-watch.service"
            if enable:
                unit.parent.mkdir(parents=True,exist_ok=True)
                def quote(x):
                    if any(ord(c)<32 for c in x):raise ValueError("Unsupported installation path")
                    return '"'+x.replace('\\','\\\\').replace('"','\\"').replace('%','%%').replace('$','$$')+'"'
                text="[Unit]\nDescription=CaDi local connection monitor\n[Service]\nExecStart="+" ".join(map(quote,cmd))+"\nRestart=on-failure\nRestartSec=15\n[Install]\nWantedBy=default.target\n"
                with tempfile.NamedTemporaryFile("w",dir=unit.parent,delete=False) as f:f.write(text);temp=Path(f.name)
                os.replace(temp,unit)
                subprocess.run(["/usr/bin/systemctl","--user","daemon-reload"],check=True,capture_output=True,timeout=15)
                subprocess.run(["/usr/bin/systemctl","--user","enable","--now",unit.name],check=True,capture_output=True,timeout=15)
                subprocess.run(["/usr/bin/systemctl","--user","restart",unit.name],check=True,capture_output=True,timeout=15)
            else:
                subprocess.run(["/usr/bin/systemctl","--user","disable","--now",unit.name],capture_output=True,timeout=15)
                unit.unlink(missing_ok=True)
                subprocess.run(["/usr/bin/systemctl","--user","daemon-reload"],capture_output=True,timeout=15)
        elif system=="Windows":
            shortcut=Path(os.environ["APPDATA"])/"Microsoft/Windows/Start Menu/Programs/Startup/CaDi Watch.lnk"
            if enable:
                cmd[0]=str(Path(sys.executable).with_name("pythonw.exe"))
                native_powershell("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:CADI_LINK); $s.TargetPath=$env:CADI_EXE; $s.Arguments=$env:CADI_ARGS; $s.Save()",env={
                    "CADI_LINK":str(shortcut),"CADI_EXE":cmd[0],"CADI_ARGS":subprocess.list2cmdline(cmd[1:])})
                subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                                 creationflags=0x08000000 | 0x00000200,close_fds=True)
            else:shortcut.unlink(missing_ok=True)
    except (OSError,subprocess.SubprocessError,ValueError) as e:
        if enable:marker.unlink(missing_ok=True)
        raise ValueError("Background registration could not finish. Check that a user login session and startup service are available.") from e
    return "Background monitoring enabled for this login and future logins." if enable else "Background monitoring disabled."


def report(folder):
    state=read(folder/"events.json",{})
    mode="Enabled for this user" if (folder/"enabled").exists() else "Off"
    rows=[f"Background monitoring: {mode}", "Last successful sample (UTC): "+str(state.get("last_check","none yet")),
          "Response: local alert and incident log. An established connection does not prove a successful login."]
    if state.get("problem"):rows.append("[UNKNOWN] "+state["problem"])
    for event in reversed(state.get("events",[])[-20:]):
        rows.append("\n"+event["time"]+" · "+event["type"]+f' ({event["count"]})')
        for item in event["connections"]: rows.append(f'  {item["service"]} · peer {item["peer"]}:{item["peer_port"]} → local port {item["port"]}')
        for key in ("local_notice","phone","model_note"):
            if event.get(key):rows.append("  "+event[key])
    if not state.get("events"):rows.append("No recorded connection alerts.")
    return "\n".join(rows)


def main(args=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=("enable","disable","events","loop","phone","model"))
    p.add_argument("values",nargs="*")
    a=p.parse_args(args);folder=location()
    if a.action=="loop":monitor_loop(folder);return
    if a.action in ("enable","disable"):print(registration(folder,a.action=="enable"))
    elif a.action=="events":print(report(folder));return
    else:
        cfg=read(folder/"config.json",{})
        if a.action=="phone":
            cfg["phone"]=endpoint(a.values[0],False) if a.values and a.values[0] else ""
        else:
            if a.values and any(a.values):
                if len(a.values)!=2 or not a.values[1].strip():raise ValueError("Enter the loopback URL and a local model ID.")
                endpoint(a.values[0],True);cfg.update(url=a.values[0],model=a.values[1].strip())
            else:cfg.update(model="",url="")
        write(folder/"config.json",cfg)
        print("Notification preferences saved.")
    print(report(folder))


if __name__=="__main__":
    try:main()
    except (OSError,ValueError,subprocess.SubprocessError) as exc:sys.exit(str(exc))
