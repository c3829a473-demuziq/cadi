"""CaDi v1. Offline, local host audit and opt-in hardening."""
import argparse
import concurrent.futures
import selectors
import socket
import threading
import time
import contextlib
import ctypes
import datetime as dt
import ipaddress
import json
import os
from pathlib import Path
import platform
import re
import shlex
import stat
import struct
import subprocess
import sys
from typing import Callable, Optional, Tuple
from dataclasses import asdict, dataclass

VERSION = "1.0.2"
ALF = "/usr/libexec/ApplicationFirewall/socketfilterfw"
SYSCTL = "/usr/sbin/sysctl"
UFW = "/usr/sbin/ufw"
NETSTAT = "/usr/sbin/netstat"
KERNEL_CONTROLS = {
    "linux-syn-cookies": ("net.ipv4.tcp_syncookies", "TCP SYN backlog protection",
        "Enable SYN cookies when the pending connection queue overflows."),
    "linux-broadcast-echo": ("net.ipv4.icmp_echo_ignore_broadcasts", "Broadcast echo protection",
        "Ignore IPv4 broadcast and multicast echo and timestamp requests."),
}
PORTS = {
    22: "SSH", 445: "SMB file sharing", 2375: "Docker API", 2376: "Docker TLS API",
    3389: "Remote Desktop", 5037: "ADB host server", 5555: "legacy ADB over TCP", 5432: "PostgreSQL", 5900: "screen sharing",
    5985: "WinRM", 5986: "WinRM over TLS", 11434: "Ollama API",
}
ADMIN_PORTS = {2375, 5432, 11434}
SECRET_FILES = {".env": "file", "config.json": "file", "keys": "directory",
                "keys/jwt.key": "file", "keys/secret.key": "file"}


class Unavailable(Exception):
    """A check could not obtain trustworthy evidence."""


@dataclass
class Finding:
    id: str
    status: str
    title: str
    evidence: str
    next_step: str = ""


def execute(argv, *, privileged=False, bounded=False):
    """Run a fixed native utility. Only sudo and the mutating command can prompt."""
    windows = os.name == "nt"
    env = os.environ.copy() if windows else {
        "PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C",
        "TERM": os.environ.get("TERM", "dumb"),
    }
    if privileged and not windows and os.geteuid() != 0:
        argv = ["/usr/bin/sudo", "--", *argv]
    if windows:
        # Restrict PowerShell module resolution to the OS module directory.
        system = win_system_dir()
        env["PSModulePath"] = str(system / "WindowsPowerShell/v1.0/Modules")
        env["PATH"] = str(system) + os.pathsep + str(system / "wbem")
    try:
        if bounded:
            return bounded_output(argv,env,str(win_system_dir()) if windows else "/")
        result = subprocess.run(argv, stdin=None if privileged else subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=None if privileged else subprocess.PIPE,
            timeout=120 if privileged else 20, env=env,
            cwd=str(win_system_dir()) if windows else "/", check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise Unavailable("Native command unavailable or timed out: " + Path(argv[0]).name) from exc
    if result.returncode:
        raise Unavailable(f"{Path(argv[0]).name} returned exit {result.returncode}. Check permissions and availability.")
    return result.stdout.decode("utf-8-sig", errors="replace").strip()


def win_system_dir():
    buf = ctypes.create_unicode_buffer(32768)
    length = ctypes.windll.kernel32.GetSystemDirectoryW(buf, len(buf))
    if not 0 < length < len(buf):
        raise Unavailable("Windows system directory unavailable.")
    return Path(buf.value)


def powershell(code, *, privileged=False):
    exe = win_system_dir() / "WindowsPowerShell/v1.0/powershell.exe"
    preamble = "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; " \
               "[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false); "
    return execute([str(exe), "-NoLogo", "-NoProfile", "-NonInteractive", "-Command",
                    preamble + code], privileged=privileged)


def ip_scope(address):
    if address == "*":
        return "all interfaces"
    ip = ipaddress.ip_address(address.split("%", 1)[0])
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
        ip = ip.ipv4_mapped
    if ip.is_loopback:
        return "loopback"
    if ip.is_unspecified:
        return "all interfaces"
    return "interface address"


def linux_tcp_table(data, version):
    lines = data.splitlines()
    if not lines or "local_address" not in lines[0] or "st" not in lines[0].split():
        raise ValueError("unrecognized kernel table")
    listeners = []
    for line in lines[1:]:
        parts = line.split()
        if len(parts) < 4:
            raise ValueError("short kernel record")
        if parts[3] != "0A":
            continue
        address, port = parts[1].split(":")
        if len(address) != (8 if version == 4 else 32) or len(port) != 4:
            raise ValueError("bad endpoint")
        # Each 32-bit word in /proc/net/tcp* is in host byte order.
        raw = b"".join(struct.pack("=I", int(address[i:i+8], 16))
                       for i in range(0, len(address), 8))
        listeners.append((str(ipaddress.ip_address(raw)), int(port, 16)))
    return listeners


def mac_tcp_table(data):
    if "Local Address" not in data or "Foreign Address" not in data:
        raise ValueError("unrecognized netstat output")
    result = []
    for line in data.splitlines():
        parts = line.split()
        if parts and parts[0].startswith("tcp") and "LISTEN" in parts:
            address, port = parts[3].rsplit(".", 1)
            ip_scope(address)
            result.append((address, int(port)))
    return result


def windows_tcp_table(data):
    rows = json.loads(data)
    if not isinstance(rows, list):
        raise ValueError("unrecognized connection table")
    result = []
    for row in rows:
        address, port = row["LocalAddress"], row["LocalPort"]
        ip_scope(address)
        if type(port) is not int or not 0 < port <= 65535:
            raise ValueError("invalid TCP port")
        result.append((address, port))
    return result


def listeners(system):
    result, gaps = [], []
    if system == "Linux":
        for version, path in [(4, "/proc/net/tcp"), (6, "/proc/net/tcp6")]:
            try:
                result.extend(linux_tcp_table(Path(path).read_text(encoding="ascii"), version))
            except (OSError, ValueError) as exc:
                gaps.append(f"IPv{version} TCP table unavailable ({type(exc).__name__}).")
    elif system == "Darwin":
        try:
            result = mac_tcp_table(execute([NETSTAT, "-anW", "-p", "tcp"]))
        except (Unavailable, IndexError, ValueError) as exc:
            gaps.append(f"macOS TCP table unavailable ({exc}).")
    else:
        try:
            result = windows_tcp_table(powershell(
                "$rows=@(Get-NetTCPConnection | Where-Object { $_.State -eq 'Listen' } | "
                "Select-Object LocalAddress,LocalPort); ConvertTo-Json -InputObject $rows -Compress"))
        except (Unavailable, ValueError, TypeError, KeyError, AttributeError) as exc:
            gaps.append(f"Windows TCP table unavailable ({exc}).")
    return sorted(set(result), key=lambda x: (x[1], x[0])), gaps


def listen_findings(endpoints, gaps):
    findings, records = [], []
    for address, port in endpoints:
        scope = ip_scope(address)
        hint = PORTS.get(port, "")
        records.append(dict(address=address, port=port, scope=scope, common_use=hint))
        if scope == "loopback":
            continue
        where = f"[{address}]:{port}" if ":" in address else f"{address}:{port}"
        title = f"Non-loopback TCP listener on port {port}"
        if hint:
            title += f" ({hint} is a common use)"
        if port in (5037,5555):
            step = "Verify the process is Android Debug Bridge. Keep its host server on loopback; disable legacy network debugging when idle and review paired devices."
        elif port == 22:
            step = "Confirm the SSH process and bind address, the OS route to your intended peer, and the allowed host access policy. A listener alone does not show an authenticated session."
        elif port in ADMIN_PORTS:
            step = ("Identify the owning service. If it is local-only, bind it to 127.0.0.1 or ::1. "
                    "If shared intentionally, restrict its permitted peers and check authentication.")
        else:
            step = ("Confirm the owning service and permitted clients. For SSH or remote desktop, "
                    "check your working remote-access path before changing any rule.")
        findings.append(Finding(f"tcp-{address}-{port}", "REVIEW", title, where + " / " + scope, step))
    for i, gap in enumerate(gaps):
        findings.append(Finding(f"tcp-coverage-{i}", "UNKNOWN", "Listener inventory is incomplete", gap))
    if not findings:
        findings.append(Finding("tcp-bindings", "OK", "No non-loopback TCP listeners found",
            f"{len(records)} visible listening endpoints in this host context."))
    return findings, records


def linux_value(control):
    key = KERNEL_CONTROLS[control][0]
    raw = Path("/proc/sys", *key.split(".")).read_text(encoding="ascii").strip()
    if raw not in ({"0", "1", "2"} if control == "linux-syn-cookies" else {"0", "1"}):
        raise Unavailable("Unrecognized kernel value.")
    return raw


def mac_value(control):
    arg = "--getglobalstate" if control == "mac-firewall" else "--getstealthmode"
    raw = execute([ALF, arg])
    if control == "mac-firewall":
        m = re.fullmatch(r"Firewall is (disabled|enabled|set to block all[^\r\n(]*)[. ]*\(State = ([012])\)[. ]*", raw, re.I)
        if m:
            label, value = m.group(1).lower(), m.group(2)
            if (value == "0") == (label == "disabled"):
                return value
    else:
        m = re.fullmatch(r"(?:Firewall )?stealth mode (?:is )?(enabled|disabled|on|off)\.?", raw, re.I)
        if m:
            return "1" if m.group(1).lower() in ("on", "enabled") else "0"
    raise Unavailable("Unrecognized response from the macOS firewall utility.")


def win_bool(expression):
    value = powershell("[string]"+expression)
    if value not in ("True", "False"):
        raise Unavailable("Windows returned an unrecognized policy value.")
    return "1" if value == "True" else "0"


def win_smb_value():
    return win_bool("(Get-SmbServerConfiguration).RequireSecuritySignature")


def ufw_value(privileged=False):
    status = execute([UFW, "status"], privileged=privileged)
    first = status.splitlines()[0] if status else ""
    if first in ("Status: active", "Status: inactive"):
        return "1" if first == "Status: active" else "0"
    raise Unavailable("Unrecognized UFW status.")


def local_console():
    if any(os.environ.get(key) for key in ("SSH_CONNECTION", "SSH_CLIENT", "SSH_TTY")):
        raise Unavailable("Use the device's local console for firewall activation.")


def ufw_preview():
    policy = Path("/etc/default/ufw").read_text(encoding="utf-8").splitlines()
    incoming = [line.split("=", 1)[1].strip().strip(chr(34)).strip(chr(39))
                for line in policy if line.startswith("DEFAULT_INPUT_POLICY=")]
    if incoming not in (["DROP"], ["REJECT"]):
        raise Unavailable("Review the UFW default input policy first. An explicit DROP or REJECT is required.")
    print("UFW will load its existing rules. Review these before proceeding.", flush=True)
    print(execute([UFW, "show", "added"], privileged=True) or "(no added UFW rules listed)")


def system_protection(system):
    if system == "Windows":
        raw = powershell("(Get-MpComputerStatus).RealTimeProtectionEnabled")
        states = {"True": "OK", "False": "REVIEW"}
        return Finding("windows-defender", states.get(raw, "UNKNOWN"), "Microsoft Defender real-time protection",
            "RealTimeProtectionEnabled = " + raw,
            "Check the active antivirus provider in Windows Security." if raw != "True" else "")
    if system == "Darwin":
        raw = execute(["/usr/bin/csrutil", "status"])
        state = {"System Integrity Protection status: enabled.": "OK",
                 "System Integrity Protection status: disabled.": "REVIEW"}.get(raw, "UNKNOWN")
        return Finding("mac-sip", state, "System Integrity Protection", raw,
            "Review the boot security configuration." if state != "OK" else "")
    raw = Path("/sys/module/apparmor/parameters/enabled").read_text(encoding="ascii").strip()
    return Finding("linux-apparmor", {"Y":"OK","N":"REVIEW"}.get(raw, "UNKNOWN"),
        "AppArmor kernel module", "Kernel enabled flag = " + raw,
        "Use aa-status to review which profiles enforce policy.")


def win_firewall():
    rows = json.loads(powershell(
        "$rows=@(Get-NetFirewallProfile -PolicyStore ActiveStore | Select-Object Name,"
        "@{n='Active';e={[string]$_.Enabled}}); ConvertTo-Json -InputObject $rows -Compress"))
    states = {row["Name"]: row["Active"] for row in rows}
    result = []
    for name in ("Domain", "Private", "Public"):
        raw = states.get(name)
        status = {"True": "OK", "False": "REVIEW"}.get(raw, "UNKNOWN")
        key = "windows-public-firewall" if name == "Public" else f"windows-firewall-{name.lower()}"
        step = "Review Windows Security > Firewall & network protection." if status != "OK" else ""
        if name == "Public" and status == "REVIEW":
            step = "Preview activation with: cadi-guard plan windows-public-firewall"
        result.append(Finding(key, status, f"{name} firewall profile",
            f"Effective Enabled value = {raw or 'unavailable'}", step))
    return result


def secret_findings(directory, system):
    base = Path(directory)
    if system == "Windows":
        return [Finding("cadi-acls", "UNKNOWN", "CaDi file access rules",
            "Windows ACL analysis is outside this check.", "Inspect the Security tab for config.json, .env and keys.")]
    try:
        root = base.lstat()
        if not stat.S_ISDIR(root.st_mode):
            raise Unavailable("Deployment root must be a real directory.")
    except (OSError, Unavailable) as exc:
        return [Finding("cadi-directory", "UNKNOWN", "CaDi deployment directory", str(exc))]
    found = []
    for name, kind in SECRET_FILES.items():
        if name.startswith("keys/"):
            try:
                # Do not traverse a redirected keys directory.
                if not stat.S_ISDIR((base / "keys").lstat().st_mode):
                    continue
            except FileNotFoundError:
                continue
            except OSError:
                continue  # The keys directory already has a separate finding.
        try:
            info = (base / name).lstat()
        except FileNotFoundError:
            continue
        except OSError as exc:
            found.append(Finding("cadi-"+name, "UNKNOWN", "CaDi "+name, str(exc)))
            continue
        valid = stat.S_ISDIR(info.st_mode) if kind == "directory" else stat.S_ISREG(info.st_mode)
        mode = stat.S_IMODE(info.st_mode)
        status = "OK" if valid and mode & 0o077 == 0 else "REVIEW"
        actual = stat.filemode(info.st_mode)
        found.append(Finding("cadi-"+name, status, "CaDi "+name,
            f"POSIX mode {mode:04o} ({actual}). Expected {kind} with owner-only mode bits. ACLs require separate review.",
            "Confirm the service account owns this path, then restrict group and other access. Inspect ACLs separately."
            if status == "REVIEW" else ""))
    if not found:
        found.append(Finding("cadi-files", "INFO", "CaDi deployment files",
            "None of the five recognized paths was found at the supplied location."))
    return found


@dataclass
class Control:
    title: str
    impact: str
    read: Callable[[], str]
    write: Callable[[], object]
    command: str
    undo: str
    desired: Tuple[str, ...] = ("1",)
    ready: Optional[Callable[[], None]] = None
    preview: Optional[Callable[[], None]] = None
    prerequisite: Optional[Callable[[], None]] = None


def platform_controls(system, for_change=False):
    if system == "Linux":
        controls = {}
        for key, (setting, title, desc) in KERNEL_CONTROLS.items():
            def set_live(name=setting):
                execute([SYSCTL, "-w", name+"=1"], privileged=True)
            controls[key] = Control(title, desc + " Changes the running kernel until reboot or a policy reload.",
                lambda k=key: linux_value(k), set_live,
                f"sudo {SYSCTL} -w {setting}=1", f"sudo {SYSCTL} -w {setting}=0")
        controls["linux-ufw"] = Control("UFW host firewall",
            "Activates UFW now and at boot, using existing rules. This can drop SSH, VPN, game or file-sharing connections and affect custom firewall chains. Use your local console on a host where UFW manages the firewall.",
            lambda: ufw_value(privileged=for_change), lambda: execute([UFW, "--force", "enable"], privileged=True),
            "sudo /usr/sbin/ufw --force enable", "sudo /usr/sbin/ufw disable", ready=local_console, preview=ufw_preview)
        return controls
    if system == "Darwin":
        def needs_firewall():
            if mac_value("mac-firewall") not in ("1", "2"):
                raise Unavailable("Enable the macOS firewall before enabling stealth mode.")
        controls = {}
        for key, title, effect, option, ready in [
            ("mac-firewall", "macOS application firewall",
             "Turns on the application firewall. Incoming connections to remote access, games or shared apps may be blocked. Use the local console and review allowed apps.",
             "--setglobalstate", local_console),
            ("mac-stealth", "macOS firewall stealth mode",
             "Suppresses responses to ping and probes of closed ports. Network diagnostics may time out.",
             "--setstealthmode", needs_firewall),
        ]:
            controls[key] = Control(title, effect, lambda k=key: mac_value(k),
                lambda opt=option: execute([ALF, opt, "on"], privileged=True),
                f"sudo {ALF} {option} on", f"sudo {ALF} {option} off",
                ("1", "2") if key == "mac-firewall" else ("1",),
                ready=ready if key == "mac-firewall" else None,
                prerequisite=ready if key == "mac-stealth" else None)
        return controls
    cmd = "Set-SmbServerConfiguration -RequireSecuritySignature "
    def windows_admin():
        if not ctypes.windll.shell32.IsUserAnAdmin():
            raise Unavailable("Open a terminal as Administrator to apply this setting.")
    def public_active():
        return win_bool("(Get-NetFirewallProfile -Name Public -PolicyStore ActiveStore).Enabled")

    def public_ready():
        local_console()
        windows_admin()
        if win_bool("(Get-NetFirewallProfile -Name Public -PolicyStore PersistentStore).Enabled") != "0":
            raise Unavailable("Local Public profile is not explicitly disabled. Review the applied policy in Windows Security.")

    fw = "Set-NetFirewallProfile -Name Public -PolicyStore PersistentStore -Enabled "
    return {"windows-public-firewall": Control("Enable the Public firewall profile",
        "Enables the Windows firewall for networks classified Public. Remote access and game servers using this profile may need an inbound rule. Make this change from the local console.",
        public_active, lambda: powershell(fw+"True", privileged=True),
        fw+"True", fw+"False", ready=public_ready),
        "windows-smb-signing": Control("Require signing for inbound SMB file sharing",
        "Requires clients connecting to this PC's SMB shares to sign messages. Older or guest-only clients may lose access.",
        win_smb_value, lambda: powershell(cmd+"$true -Confirm:$false", privileged=True),
        cmd+"$true -Confirm:$false", cmd+"$false -Confirm:$false", ready=windows_admin)}


@contextlib.contextmanager
def owned_file(directory, name):
    """Bind the mode change to the checked regular file inside the selected directory."""
    rootfd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        base = os.fstat(rootfd)
        if base.st_uid != os.geteuid() or base.st_mode & 0o022:
            raise Unavailable("The deployment directory must belong to the current user and reject group/other writes.")
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=rootfd)
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_nlink != 1:
                raise Unavailable("Only a regular, singly linked file owned by the current user can be changed.")
            if stat.S_IMODE(info.st_mode) & 0o7000:
                raise Unavailable("Special permission bits require manual review.")
            yield fd
        finally:
            os.close(fd)
    finally:
        os.close(rootfd)


def restrict_file(directory, name, apply):
    path = Path(directory) / name
    with owned_file(directory, name) as fd:
        initial = stat.S_IMODE(os.fstat(fd).st_mode)
        desired = initial & 0o700
        print(f"{path}: mode {initial:04o} -> {desired:04o}. Removes group/other POSIX mode bits. Inspect ACLs separately. "
              "Confirm that the owner is the account running CaDi.")
        if initial == desired:
            print("Owner-only POSIX mode is already set.")
            return
        print(f"To undo on this host: chmod {initial:04o} {shlex.quote(str(path.absolute()))}", flush=True)
        if not apply:
            return
        confirm()
        if not os.path.samestat(os.lstat(path), os.fstat(fd)):
            raise Unavailable("The path changed during review. Run the plan again.")
        if stat.S_IMODE(os.fstat(fd).st_mode) != initial:
            raise Unavailable("The mode changed during review. Run the plan again.")
        os.fchmod(fd, desired)
        if not os.path.samestat(os.lstat(path), os.fstat(fd)) or stat.S_IMODE(os.fstat(fd).st_mode) != desired:
            raise Unavailable("The requested file mode could not be verified. Inspect the path before retrying.")
        print(f"Verified mode {desired:04o}.")


def confirm():
    if not sys.stdin.isatty():
        raise Unavailable("Apply requires an interactive terminal.")
    try:
        answer = input("Type APPLY to make this one change: ")
    except EOFError:
        answer = ""
    if answer != "APPLY":
        raise Unavailable("Cancelled before changing the setting.")


def change(control, apply):
    before = control.read()
    print(control.title)
    if before in control.desired:
        if control.prerequisite:
            control.prerequisite()
        print(f"Already enabled (value {before}).")
        return
    if before != "0":
        raise Unavailable(f"Value {before!r} requires individual review.")
    print(control.impact)
    print("Planned command:", control.command)
    print("To restore the observed setting:", control.undo, flush=True)
    if control.prerequisite:
        control.prerequisite()
    if control.preview:
        control.preview()
    if not apply:
        return
    confirm()
    if control.ready:
        control.ready()
    if control.read() != before:
        raise Unavailable("The setting changed during review. Run the plan again.")
    try:
        control.write()
        after = control.read()
    except (Unavailable, OSError, ValueError) as exc:
        raise Unavailable(f"Change was not verified. Re-run the audit before retrying. {exc}") from exc
    if after not in control.desired:
        raise Unavailable(f"Verification returned value {after!r}. Review the effective policy.")
    print(f"Verified enabled (value {after}).")


def audit(system, deployment=None):
    results = []
    controls = platform_controls(system)
    for key, control in controls.items():
        if key == "windows-public-firewall":
            continue  # Collected with all three effective profiles below.
        try:
            raw = control.read()
            status = "OK" if raw in control.desired else "REVIEW"
            step = "" if status == "OK" else "Preview the change with: cadi-guard plan " + key
            if key == "linux-syn-cookies" and raw == "2":
                step = "Unconditional test mode is active. Review the kernel setting with the host administrator."
            evidence = f"Current value = {raw}"
            if key == "linux-ufw" and raw == "0":
                step = "UFW is inactive. Check for another firewall manager before using cadi-guard plan linux-ufw."
            if key == "mac-stealth" and raw == "1" and mac_value("mac-firewall") == "0":
                status, step = "REVIEW", "Enable the application firewall for stealth mode to take effect."
            results.append(Finding(key, status, control.title, evidence, step))
        except (OSError, ValueError, Unavailable) as exc:
            results.append(Finding(key, "UNKNOWN", control.title, str(exc),
                "On Mint/Ubuntu, check sudo ufw status verbose. Other firewall backends require separate review."
                if key == "linux-ufw" else ""))
    try:
        results.append(system_protection(system))
    except (OSError, Unavailable) as exc:
        name = {"Windows":"Microsoft Defender real-time protection", "Darwin":"System Integrity Protection",
                "Linux":"AppArmor kernel module"}[system]
        results.append(Finding("host-protection", "UNKNOWN", name, str(exc)))
    if system == "Windows":
        try:
            results.extend(win_firewall())
        except (Unavailable, ValueError, KeyError, TypeError) as exc:
            results.append(Finding("windows-firewall", "UNKNOWN", "Windows firewall profiles", str(exc),
                "Inspect the profiles in Windows Security."))
    endpoints, gaps = listeners(system)
    ff, records = listen_findings(endpoints, gaps)
    results.extend(ff)
    if deployment:
        results.extend(secret_findings(deployment, system))
    return {"tool": "CaDi v1", "version": VERSION,
            "time_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "platform": system,
            "findings": [asdict(item) for item in results], "tcp_listeners": records}


def render_report(report):
    print(f"CaDi v1 | {report['platform']} | {report['time_utc']}\n")
    counts = {}
    for row in report["findings"]:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
        print("[{status}] {title} ({id})\n  {evidence}".format(**row))
        if row["next_step"]:
            print("  "+row["next_step"])
    print("\nTCP listeners")
    for row in report["tcp_listeners"]:
        print("  {address}  TCP/{port}  {scope}  {common_use}".format(**row).rstrip())
    if not report["tcp_listeners"]:
        print("  No entries returned. See coverage findings above.")
    print("\n"+" | ".join(f"{s} {counts.get(s, 0)}" for s in ("REVIEW", "UNKNOWN", "OK", "INFO")))
    print("Bindings show where the OS listens. Reachability also depends on firewalls, forwarding, containers and VPN policy.")


def bounded_output(argv, env, cwd, timeout=15, limit=4*1024*1024, stop=None, child_report=False):
    """Limit child output before decoding it; kill a blocked producer at deadline."""
    with subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL, env=env, cwd=cwd) as proc:
        done=threading.Event()
        def watchdog():
            end=time.monotonic()+timeout
            while time.monotonic()<end and not (stop and stop.is_set()):
                remaining=max(0,end-time.monotonic())
                if done.wait(min(0.25,remaining) if stop else remaining): return
            if proc.poll() is None:
                with contextlib.suppress(OSError): proc.kill()
        timer=threading.Thread(target=watchdog,daemon=True)
        timer.start()
        try:
            data = proc.stdout.read(limit + 1)
            if len(data) > limit:
                raise Unavailable("Local utility exceeded the output budget.")
            if proc.wait() != 0:
                if child_report:
                    try:
                        detail=json.loads(data)
                        if isinstance(detail,dict) and isinstance(detail.get("error"),str):
                            raise Unavailable(detail["error"][:400])
                    except (ValueError,UnicodeError):
                        pass
                raise Unavailable(f"{Path(argv[0]).name} did not return usable data.")
            return data.decode("utf-8-sig", errors="strict").strip()
        finally:
            done.set()
            if proc.poll() is None:
                proc.kill()


def raw_ospf_count(data, version):
    lines = data.splitlines()
    if not lines or "local_address" not in lines[0] or "st" not in lines[0].split():
        raise ValueError("Unrecognized raw socket header.")
    count = 0
    pattern = r"[0-9a-fA-F]{%d}:([0-9a-fA-F]{4})" % (8 if version==4 else 32)
    for line in lines[1:]:
        fields = line.split()
        match = re.fullmatch(pattern, fields[1]) if len(fields)>=4 else None
        if not match:
            raise ValueError("Incomplete raw socket table.")
        count += int(match[1], 16) == 89
    return count


def frr_flags(data):
    flags = {}
    for line in data.splitlines():
        code = line.partition("#")[0].strip()
        match = re.fullmatch(r"(ospfd|ospf6d)\s*=\s*['\"]?(yes|no)['\"]?", code)
        if match:
            flags[match[1]] = match[2]
    return {d:flags.get(d,"unspecified") for d in ("ospfd","ospf6d")}


def small_file(path, cap=1024*1024):
    # Read fixed local paths. Reject special files and unbounded inputs.
    if not stat.S_ISREG(path.stat().st_mode):
        raise Unavailable("Expected a regular file.")
    with path.open("rb") as src:
        raw = src.read(cap+1)
    if len(raw) > cap:
        raise Unavailable("File exceeds the audit size limit.")
    return raw.decode("utf-8")


def saved_ospf_v2_defaults(text):
    # FRR integrated generated config has unindented context headings. Values
    # and identifiers from arbitrary configuration lines never enter the report.
    defaults=[]
    current=None
    for raw in text.splitlines():
        line=raw.strip()
        if not line or line.startswith(("!","#")): continue
        if not raw[:1].isspace():
            current=None
            if re.fullmatch(r"router ospf(?:\s+.*)?",line):
                defaults.append(False)
                current=len(defaults)-1
            continue
        if line == "exit":
            current=None
        if current is not None and line in ("passive-interface default","no passive-interface default"):
            defaults[current]=(line=="passive-interface default")
    return {"ospfv2_router_stanzas":len(defaults),"explicit_passive_default":sum(defaults),
            "coverage":"Saved OSPFv2 router defaults only. Check per-interface overrides and running policy on the router."}


def frr_advisory():
    ref = "https://security-tracker.debian.org/tracker/CVE-2026-119776"
    result = {"advisory":"CVE-2026-119776", "component":"FRRouting OSPFv3", "source":ref}
    try:
        val = execute(["/usr/bin/dpkg-query","-W","-f=${db:Status-Status} ${Version}", "frr"], bounded=True)
        parts = val.split()
        if len(parts)!=2 or parts[0]!="installed":
            raise Unavailable("No installed FRR package record.")
        version = parts[1]
        release = {}
        for line in small_file(Path("/etc/os-release")).splitlines():
            k, sep, v = line.partition("=")
            if sep and k in ("ID","VERSION_CODENAME"):
                release[k] = v.strip('"').strip("'")
        result.update(installed_version=version, distribution=release.get("ID"), release=release.get("VERSION_CODENAME"))
        table = {("bookworm","8.4.4-1.1~deb12u2"):"REVIEW",("trixie","10.3-3+deb13u1"):"REVIEW",
                 ("forky","10.7.1-7"):"INFO",("sid","10.7.1-7"):"INFO"}
        status = table.get((result["release"],version),"UNKNOWN") if result["distribution"]=="debian" else "UNKNOWN"
        assessment = {"REVIEW":"Exact distribution release/version matches a Debian tracker row listed as vulnerable. Confirm package origin and OSPFv3 use.",
                      "INFO":"Exact release/version matches a Debian tracker row listed as fixed. Confirm package origin.",
                      "UNKNOWN":"Check the distributor's advisory for this exact build. Kali and other derivatives can carry different patches."}[status]
    except (Unavailable, OSError, UnicodeError):
        status, assessment = "UNKNOWN", "Installed distribution/package version unavailable."
    return dict(result,status=status,assessment=assessment)


def ospf_report():
    result = {"check":"Local OSPF", "raw_socket_counts":{}, "coverage_notes":[]}
    for version, name in ((4,"raw"),(6,"raw6")):
        try:
            count = raw_ospf_count(small_file(Path("/proc/net",name)),version)
        except (OSError, ValueError, Unavailable):
            count = None
            result["coverage_notes"].append(f"IPv{version} raw socket table unavailable.")
        result["raw_socket_counts"]["ipv"+str(version)] = count
    try:
        result["frr_startup"] = frr_flags(small_file(Path("/etc/frr/daemons")))
    except FileNotFoundError:
        result["frr_startup"] = "No /etc/frr/daemons file at the default path."
    except (OSError, ValueError, Unavailable):
        result["frr_startup"] = "Unknown; daemon configuration unreadable."
    try:
        result["saved_policy"]=saved_ospf_v2_defaults(small_file(Path("/etc/frr/frr.conf")))
    except FileNotFoundError:
        result["saved_policy"]="Default integrated FRR configuration absent."
    except (OSError,ValueError,Unavailable):
        result["saved_policy"]="Integrated FRR configuration unreadable."
    result["advisory"] = frr_advisory()
    result["scope"] = ("IP protocol 89 sockets in this network namespace and saved FRR startup flags. "
                       "Confirm intended router role, passive interfaces, authentication and live neighbors on the routing device. "
                       "A socket or a startup flag alone does not establish an adjacency.")
    return result


def interface_counts(name):
    for line in small_file(Path("/proc/net/dev")).splitlines()[2:]:
        iface, sep, rest = line.rpartition(":")
        if sep and iface.strip() == name:
            parts = rest.split()
            if len(parts) != 16:
                raise Unavailable("Unrecognized interface counters.")
            return {key:int(parts[i]) for i,key in ((0,"rx_bytes"),(1,"rx_packets"),(8,"tx_bytes"),(9,"tx_packets"))}
    raise Unavailable("Interface not visible in this network namespace.")


def observe_headers(iface, seconds):
    # Protocol zero prevents all-interface capture before binding. Each socket gets
    # just one EtherType; the ten copied bytes are wholly inside an IP base header.
    counts = {"rx":{}, "tx":{}}
    kinds = {1:"ICMP",6:"TCP",17:"UDP",41:"IPv6 encapsulation",47:"GRE",50:"ESP",
             51:"AH",58:"ICMPv6",89:"OSPF"}
    with contextlib.ExitStack() as stack:
        sel = stack.enter_context(selectors.DefaultSelector())
        for ethertype, version in ((0x0800,4),(0x86dd,6)):
            sock = stack.enter_context(socket.socket(socket.AF_PACKET, socket.SOCK_DGRAM, 0))
            sock.setsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF,65536)
            sock.bind((iface,ethertype))
            sock.setblocking(False)
            sel.register(sock,selectors.EVENT_READ,version)
        end = time.monotonic()+seconds
        while time.monotonic()<end:
            for key,_ in sel.select(max(0,end-time.monotonic())):
                try:
                    prefix, address = key.fileobj.recvfrom(10)
                except BlockingIOError:
                    continue
                if len(prefix)<10 or prefix[0]>>4 != key.data:
                    continue
                proto = prefix[9] if key.data==4 else prefix[6]
                label = kinds.get(proto,"other/extension")
                direction = "tx" if address[2]==socket.PACKET_OUTGOING else "rx"
                counts[direction][label] = counts[direction].get(label,0)+1
    return counts


def traffic_report(iface, seconds, headers):
    if not iface or len(iface.encode())>15 or not re.fullmatch(r"[A-Za-z0-9_.:@-]+",iface):
        raise Unavailable("Supply the name of one local Linux interface.")
    try:
        initial_index=socket.if_nametoindex(iface)
    except OSError:
        initial_index=None
    before = interface_counts(iface)
    start = time.monotonic()
    result = {"check":"Interface traffic","interface":iface}
    if headers:
        try:
            result["ip_header_samples"] = observe_headers(iface,seconds)
        except OSError as exc:
            result["header_note"] = "Header sampling unavailable ("+type(exc).__name__+"); interface counters still collected."
    left = seconds - (time.monotonic()-start)
    if left>0:
        time.sleep(left)
    after = interface_counts(iface)
    if initial_index is not None and socket.if_nametoindex(iface)!=initial_index:
        raise Unavailable("Interface was replaced during sampling.")
    result["elapsed_seconds"] = round(time.monotonic()-start,2)
    result["deltas"] = {k:after[k]-v if after[k]>=v else None for k,v in before.items()}
    result["scope"] = ("Interface totals include all traffic. Optional sampled counts classify the first IP protocol field; "
                       "extensions and encrypted inner traffic may hide protocols. No packet payloads are copied or saved.")
    return result


def available_mib(system):
    try:
        if system == "Linux":
            data = small_file(Path("/proc/meminfo"))
            value = int(re.search(r"^MemAvailable:\s+(\d+) kB", data, re.M)[1])*1024
            # v2 or v1 limits may be lower than host memory, including parents.
            try:
                groups = small_file(Path("/proc/self/cgroup")).splitlines()
            except OSError:
                groups=[]
            for line in groups:
                _, controllers, rel = line.split(":",2)
                if controllers and "memory" not in controllers.split(","):
                    continue
                root = Path("/sys/fs/cgroup/memory" if controllers else "/sys/fs/cgroup")
                safe_parts = [p for p in rel.split("/") if p and p not in (".","..")]
                node = root.joinpath(*safe_parts)
                limit, used = ("memory.limit_in_bytes","memory.usage_in_bytes") if controllers else ("memory.max","memory.current")
                while True:
                    try:
                        cap = (node/limit).read_text().strip()
                        if cap.isdigit():
                            value = min(value,max(0,int(cap)-int((node/used).read_text())))
                    except (OSError,ValueError):
                        pass
                    if node==root:
                        break
                    node=node.parent
            return value//(1024**2)
        if system=="Windows":
            class MemoryStatus(ctypes.Structure):
                _fields_ = [("length",ctypes.c_uint32),("load",ctypes.c_uint32)]+[(k,ctypes.c_uint64) for k in
                    ("total","available","page_total","page_available","virtual_total","virtual_available","extended")]
            row=MemoryStatus()
            row.length=ctypes.sizeof(row)
            return row.available//(1024**2) if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(row)) else None
        data=execute(["/usr/bin/vm_stat"],bounded=True)
        page=int(re.search(r"page size of (\d+) bytes",data)[1])
        free=int(re.search(r"Pages free:\s*(\d+)",data)[1])
        inactive=int(re.search(r"Pages inactive:\s*(\d+)",data)[1])
        return page*(free+inactive)//(1024**2)
    except (OSError, ValueError, TypeError, AttributeError, Unavailable):
        return None


def worker_limit(mib, cpus):
    if mib is not None and mib<128:
        return 0
    return 2 if mib is not None and mib>=2048 and cpus>=2 else 1


def entry_args():
    return [sys.executable,"-I",str(Path(__file__).resolve())]


def shell_command(argv, system):
    if system=="Windows":
        return "& "+" ".join("'"+x.replace("'","''")+"'" for x in argv)
    return shlex.join(argv)


def sample_seconds(value):
    n=int(value)
    if not 1<=n<=60:
        raise ValueError("Sample duration must be between 1 and 60 seconds.")
    return n


def worker_choices(system):
    return ["ospf", "traffic"] if system == "Linux" else []


def check_job_args(checks, system, iface, seconds):
    if not checks or any(i not in worker_choices(system) for i in checks):
        raise Unavailable("Select a supported check.")
    sample_seconds(seconds)
    if "traffic" in checks and (not iface or not re.fullmatch(r"[A-Za-z0-9_.:@-]{1,15}",iface)):
        raise Unavailable("Choose a local interface for the traffic worker.")


def job_command(job, seconds, iface):
    args=entry_args()+[job,"--json"]
    if job == "traffic":
        args+=["--seconds",str(seconds)]
    if job=="traffic":
        args+=["--interface",iface]
    return args


def run_workers(system, checks, seconds, iface):
    check_job_args(checks,system,iface,seconds)
    waiting=list(dict.fromkeys(checks))
    results, running, modes={}, {}, []
    # A fixed pool feeds bounded subprocesses. Each job gets its own interpreter.
    cpus=len(os.sched_getaffinity(0)) if hasattr(os,"sched_getaffinity") else (os.cpu_count() or 1)
    stop=threading.Event()
    def job(name):
        raw=bounded_output(job_command(name,seconds,iface),None,None,timeout=seconds+50,
                           limit=128*1024,stop=stop,child_report=True)
        return json.loads(raw)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        try:
            while waiting or running:
                if waiting:
                    capacity=worker_limit(available_mib(system),cpus)
                    if not modes or modes[-1]!=capacity:
                        modes.append(capacity)
                    if capacity==0:
                        for name in waiting:
                            results[name]={"status":"SKIPPED","reason":"Less than 128 MiB available."}
                        waiting.clear()
                    while waiting and len(running)<capacity:
                        name=waiting.pop(0)
                        running[pool.submit(job,name)]=name
                if running:
                    done,_=concurrent.futures.wait(running,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
                    for f in done:
                        name=running.pop(f)
                        try:
                            results[name]={"status":"COMPLETED","report":f.result()}
                        except (OSError, ValueError, Unavailable, MemoryError) as exc:
                            results[name]={"status":"UNAVAILABLE","reason":str(exc) or "Insufficient memory."}
        except KeyboardInterrupt:
            stop.set()
            raise
    return {"check":"Defensive workers","capacity_history":modes,"results":results}


PANEL_HTML = r'''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; base-uri 'none'; form-action 'none'">
<title>CaDi v1 · Workers</title>
<style>
:root{color-scheme:dark;font:16px/1.5 Inter,"Segoe UI",sans-serif;color:#e9f0ee;background:#101817}
*{box-sizing:border-box}body{margin:0}main{max-width:850px;margin:0 auto;padding:36px 24px 60px}
header{display:flex;align-items:center;gap:12px;padding-bottom:21px;border-bottom:1px solid #435450;font-weight:650}
.mark{display:grid;place-items:center;background:#a9e8cc;color:#10261d;border-radius:7px;width:30px;height:30px}
h1{font-size:clamp(29px,5vw,45px);line-height:1.1;margin:30px 0 8px;letter-spacing:-.04em}
p{color:#aec3bb;margin:6px 0 18px}fieldset,section{margin:18px 0;padding:18px 20px;border:1px solid #435450;border-radius:10px;background:#16211e}
legend,h2{font:650 17px/1.4 Inter,"Segoe UI",sans-serif}legend{padding:0 7px}h2{margin:0 0 8px}
.option{display:flex;gap:12px;align-items:start;padding:9px 0}.option input{width:18px;height:18px;margin-top:4px;accent-color:#a9e8cc}
small{display:block;color:#adc1b9}.fields{display:flex;flex-wrap:wrap;gap:14px;margin:14px 0}
.fields label{flex:1 1 160px;font-size:14px;font-weight:600}input:not([type=checkbox]),textarea{width:100%;margin-top:5px;color:#eff6f2;border:1px solid #546963;border-radius:6px;background:#0c1512;padding:9px}
textarea{font:14px/1.45 "IBM Plex Mono",monospace;resize:vertical}button{border-radius:6px;border:1px solid #a9e8cc;background:#a9e8cc;color:#10261d;padding:10px 15px;font:600 15px Inter,"Segoe UI",sans-serif;cursor:pointer}
button.secondary{background:transparent;color:#c9ead9;border-color:#6b9583}.actions{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
button:focus-visible,input:focus-visible,textarea:focus-visible{outline:3px solid #ffdc97;outline-offset:3px}
[hidden]{display:none!important}#message{color:#f4daa3;min-height:24px}
</style><main><header><span class="mark" aria-hidden="true">C</span>CaDi v1</header>
<h1>Defensive workers</h1><p>Choose the evidence to collect on this device. Copy the command and run it in your terminal.</p>
<fieldset><legend>Checks</legend>
<label class="option linux"><input type="checkbox" value="ospf" checked><span>OSPF routing<small>Protocol-89 sockets, saved FRRouting settings, and package version.</small></span></label>
<label class="option linux"><input type="checkbox" value="traffic"><span>Interface traffic<small>Received and transmitted bytes and packets over the sample window.</small></span></label></fieldset>
<div class="fields"><label>Sample duration (seconds)<input id="seconds" type="number" min="1" max="60" value="5"></label>
<label class="linux">Traffic interface<input id="iface" value="lo" autocomplete="off"></label></div>
<section><h2>Worker command</h2><textarea id="command" aria-label="Worker command" rows="3" readonly></textarea>
<div class="actions"><button id="copy">Copy worker command</button></div></section>
<section><h2>AI connector</h2><p>Add the generated entry to your Hermes MCP settings to make these checks available to your assistant.</p>
<button class="secondary" id="hermes">Copy Hermes configuration</button>
<textarea hidden id="config" aria-label="Hermes configuration" rows="5" readonly></textarea></section><p id="message" role="status"></p></main>
<script>
const cfg=__GUARD_BOOT__;
const el=id=>document.getElementById(id);
const linux=cfg.system==="Linux";
if(!linux)document.querySelectorAll(".linux").forEach(item=>{item.hidden=true;const box=item.querySelector("input[type=checkbox]");if(box)box.checked=false});
const shell=x=>cfg.system==="Windows"?"'"+x.replace(/'/g,"''")+"'":/^[a-zA-Z0-9_@%+=:,./-]+$/.test(x)?x:"'"+x.replace(/'/g,"'\"'\"'")+"'";
function update(){
 const jobs=[...document.querySelectorAll(".option input:checked")].map(c=>c.value);
 const n=Number(el("seconds").value),iface=el("iface").value.trim();
 let error="";
 if(!jobs.length)error="Choose at least one check.";
 else if(!Number.isInteger(n)||n<1||n>60)error="Choose a sample duration from 1 to 60 seconds.";
 else if(jobs.includes("traffic")&&!/^[A-Za-z0-9_.:@-]{1,15}$/.test(iface))error="Enter a local Linux interface name.";
 const args=[...cfg.argv,"workers","--checks",...jobs,"--seconds",String(n)];
 if(jobs.includes("traffic"))args.push("--interface",iface);
 el("command").value=error?"":(cfg.system==="Windows"?"& ":"")+args.map(shell).join(" ");
 el("copy").disabled=!!error;el("message").textContent=error;
}
async function copy(box,label){
 box.hidden=false;
 try{await navigator.clipboard.writeText(box.value);el("message").textContent=label+" copied."}
 catch{box.focus();box.select();let done=false;try{done=document.execCommand("copy")}catch{}el("message").textContent=done?label+" copied.":"Text selected. Use your system copy shortcut."}
}
el("config").value=cfg.hermes;
document.querySelectorAll("input").forEach(n=>n.addEventListener("input",update));
el("copy").addEventListener("click",()=>copy(el("command"),"Worker command"));
el("hermes").addEventListener("click",()=>copy(el("config"),"Hermes configuration"));update();
</script></html>
'''


def panel_html(system):
    if system != "Linux":
        raise Unavailable("The diagnostic command builder requires Linux.")
    config = {"system":system, "argv":entry_args(), "hermes":hermes_config()}
    # Escape script delimiters in install paths before placing JSON in HTML.
    boot = json.dumps(config).replace("<", "\\u003c")
    return PANEL_HTML.replace("__GUARD_BOOT__", boot)


def control_panel(system):
    import tempfile
    import webbrowser
    # An ordinary local file avoids a network listener and a browser backend.
    folder = Path.home() / ".cadi"
    folder.mkdir(mode=0o700, exist_ok=True)
    if folder.is_symlink() or (os.name!="nt" and
        (folder.stat().st_uid!=os.geteuid() or folder.stat().st_mode & 0o022)):
        raise Unavailable("The private command-panel directory has unsafe ownership or permissions.")
    dest = folder / "workers.html"
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=folder, delete=False) as tmp:
        temp_path=Path(tmp.name)
        try:
            tmp.write(panel_html(system))
        except BaseException:
            temp_path.unlink(missing_ok=True)
            raise
    try:
        os.replace(temp_path,dest)
    finally:
        temp_path.unlink(missing_ok=True)
    print("Open the local worker panel:",dest,flush=True)
    webbrowser.open(dest.as_uri())


def hermes_config():
    args=entry_args()+["connector"]
    return "mcp_servers:\n  cadi_guard:\n    command: "+json.dumps(args[0])+"\n    args: "+json.dumps(args[1:])


def connector_tools(system):
    def tool(name, description, props=None, required=None):
        return {"name":name,"description":description,
                "inputSchema":{"type":"object","properties":props or {},"required":required or [],"additionalProperties":False},
                "annotations":{"readOnlyHint":True,"destructiveHint":False,"openWorldHint":False}}
    duration={"type":"integer","minimum":1,"maximum":30,"default":5}
    result=[tool("host_audit","Read this host's protection status and local TCP bindings."),
            tool("hardening_plan","List supported settings or describe a selected setting and its impact. Application stays in the interactive CLI.",
                 {"control":{"type":"string","enum":list(platform_controls(system))}})]
    if system == "Linux":
        result.append(tool("run_workers","Run one bounded batch of local diagnostic workers and return each outcome.",
        {"checks":{"type":"array","minItems":1,"maxItems":2,"uniqueItems":True,
                   "items":{"type":"string","enum":worker_choices(system)}},
         "seconds":duration,"interface":{"type":"string"}},["checks"]))
    if system=="Linux":
        result.extend([tool("ospf_review","Review visible protocol-89 sockets, saved FRR daemon flags and the installed FRR package."),
                       tool("interface_sample","Measure packet and byte deltas on one local Linux interface.",
                           {"interface":{"type":"string","pattern":"^[A-Za-z0-9_.:@-]{1,15}$"},"seconds":duration},["interface"])])
    return result


def connector_call(system,name,args):
    specs={item["name"]:item["inputSchema"] for item in connector_tools(system)}
    if name not in specs or not isinstance(args,dict):
        raise ValueError("Unknown tool or invalid arguments.")
    spec=specs[name]
    if set(args)-set(spec["properties"]) or set(spec["required"])-set(args):
        raise ValueError("Unknown or missing tool arguments.")
    for key,val in args.items():
        field=spec["properties"][key]
        if field["type"]=="string" and (type(val) is not str or len(val)>128):
            raise ValueError("Invalid string argument.")
        if key=="seconds" and (type(val) is not int or not 1<=val<=30):
            raise ValueError("Sample seconds must be 1 to 30.")
        if "enum" in field and val not in field["enum"]:
            raise ValueError("Unsupported selection.")
    if name=="run_workers":
        checks=args["checks"]
        if not isinstance(checks,list) or not 1<=len(checks)<=2 or any(type(x) is not str or x not in worker_choices(system) for x in checks) or len(set(checks))!=len(checks):
            raise ValueError("Invalid diagnostic job selection.")
        return run_workers(system,checks,args.get("seconds",5),args.get("interface"))
    if name=="hardening_plan":
        controls=platform_controls(system)
        k=args.get("control")
        if k is None: return {"controls":{n:c.title for n,c in controls.items()}}
        item=controls[k]
        return {"setting":k,"impact":item.impact,"preview_command":"cadi-guard plan "+k,
                "apply_command":"cadi-guard apply "+k,"approval":"Interactive on-device confirmation required."}
    if worker_limit(available_mib(system),1)==0:
        raise Unavailable("Insufficient free memory to start a check.")
    action={"host_audit":"audit","interface_sample":"traffic","ospf_review":"ospf"}[name]
    seconds=args.get("seconds",5)
    iface=args.get("interface")
    if iface is not None and not re.fullmatch(r"[A-Za-z0-9_.:@-]{1,15}",iface):
        raise ValueError("Invalid interface.")
    raw=bounded_output(job_command(action,seconds,iface),None,None,timeout=seconds+60,limit=128*1024,child_report=True)
    return json.loads(raw)


def mcp_server(system, source=None, sink=None):
    source=source if source is not None else sys.stdin.buffer
    sink=sink if sink is not None else sys.stdout.buffer
    initialized=False
    protocols=("2025-11-25","2025-06-18","2025-03-26","2024-11-05")
    def write(obj):
        sink.write((json.dumps(obj,separators=(",",":"))+"\n").encode("utf-8"))
        sink.flush()
    while True:
        raw=source.readline(65537)
        if not raw: return
        if len(raw)>65536:
            write({"jsonrpc":"2.0","id":None,"error":{"code":-32600,"message":"Request too large."}})
            return
        try: msg=json.loads(raw)
        except (ValueError,UnicodeError,RecursionError):
            write({"jsonrpc":"2.0","id":None,"error":{"code":-32700,"message":"Invalid JSON."}})
            continue
        if not isinstance(msg,dict) or msg.get("jsonrpc")!="2.0" or not isinstance(msg.get("method"),str):
            write({"jsonrpc":"2.0","id":None,"error":{"code":-32600,"message":"Invalid JSON-RPC request."}})
            continue
        if "id" not in msg: continue
        req=msg["id"]
        if type(req) not in (int,str):
            write({"jsonrpc":"2.0","id":None,"error":{"code":-32600,"message":"Invalid request ID."}})
            continue
        method,params=msg["method"],msg.get("params",{})
        reply={"jsonrpc":"2.0","id":req}
        try:
            if not isinstance(params,dict): raise ValueError("Invalid parameters.")
            if method=="initialize":
                version=params.get("protocolVersion")
                if not isinstance(version,str): raise ValueError("Missing MCP protocol version.")
                reply["result"]={"protocolVersion":version if version in protocols else protocols[0],
                    "capabilities":{"tools":{"listChanged":False}},
                    "serverInfo":{"name":"cadi","version":VERSION}}
                initialized=True
            elif method=="ping": reply["result"]={}
            elif not initialized: raise ValueError("Initialize the connector first.")
            elif method=="tools/list": reply["result"]={"tools":connector_tools(system)}
            elif method=="tools/call":
                try:
                    data=connector_call(system,params.get("name"),params.get("arguments",{}))
                    reply["result"]={"content":[{"type":"text","text":json.dumps(data)}],"isError":False}
                except (Unavailable,OSError,MemoryError) as exc:
                    reply["result"]={"content":[{"type":"text","text":str(exc) or "Resource limit reached."}],"isError":True}
            else: reply["error"]={"code":-32601,"message":"Method not found."}
        except (ValueError,TypeError,KeyError,RecursionError):
            reply["error"]={"code":-32602,"message":"Unsupported or invalid arguments."}
        write(reply)


def print_network_result(result, as_json):
    if as_json:
        print(json.dumps(result,indent=2))
        return
    print(result["check"])
    if "deltas" in result:
        print(f"  {result['interface']} | {result['elapsed_seconds']} s | "+", ".join(f"{k}={v}" for k,v in result["deltas"].items()))
        if "ip_header_samples" in result: print("  First IP protocol samples:",json.dumps(result["ip_header_samples"]))
        if "header_note" in result: print(result["header_note"])
    if "raw_socket_counts" in result:
        print("  Protocol-89 sockets:",json.dumps(result["raw_socket_counts"]))
        print("  FRR daemon startup:",json.dumps(result["frr_startup"]))
        print("  Saved FRR policy:",json.dumps(result["saved_policy"]))
        for note in result["coverage_notes"]: print(note)
    if "advisory" in result:
        a=result["advisory"]
        print(f"  [{a['status']}] {a['advisory']}  {a.get('installed_version','')}  {a['assessment']}")
        if "condition" in a: print("  Applicability:",a["condition"])
        print(" ",a["source"])
    if "results" in result:
        print("  Worker capacity during this run:",result["capacity_history"])
        for name,job in result["results"].items():
            print(f"\n{name}  [{job['status']}]")
            if "report" in job: print_network_result(job["report"],False)
            else: print(" ",job["reason"])
    if "scope" in result: print(result["scope"])



def desktop_harden(selected):
    """Apply named macOS settings using a native administrator authorization dialog."""
    keys = [k for k in ("mac-firewall", "mac-stealth") if k in selected]
    if not keys:
        raise Unavailable("Select at least one protection.")
    before = {key: mac_value(key) for key in keys}
    firewall = before["mac-firewall"] if "mac-firewall" in before else mac_value("mac-firewall")
    if "mac-stealth" in keys and firewall == "0" and "mac-firewall" not in keys:
        raise Unavailable("Select the application firewall too, or enable it before stealth mode.")
    allowed = {"mac-firewall": ("1", "2"), "mac-stealth": ("1",)}
    names = {"mac-firewall": "Application firewall", "mac-stealth": "Firewall stealth mode"}
    switch = {"mac-firewall": "--setglobalstate", "mac-stealth": "--setstealthmode"}
    drift = [key for key in keys if before[key] not in allowed[key]]
    failure = ""
    if drift:
        # Re-read under authorization to preserve an existing block-all policy.
        # Only fixed Apple binaries and literal checks enter the privileged program.
        get_firewall = 'state=$(/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate)'
        active = '*"State = 1)"*|*"State = 2)"*'
        commands = ["set -e", "export LC_ALL=C", get_firewall]
        if "mac-firewall" in drift:
            commands.append('case "$state" in ' + active + ') : ;; *"State = 0)"*) /usr/libexec/ApplicationFirewall/socketfilterfw --setglobalstate on ;; *) exit 12 ;; esac')
        if "mac-stealth" in drift:
            commands.extend([get_firewall, 'case "$state" in ' + active + ') : ;; *) exit 12 ;; esac',
                             '/usr/libexec/ApplicationFirewall/socketfilterfw --setstealthmode on'])
        source = "do shell script " + json.dumps("\n".join(commands)) + " with administrator privileges"
        try:
            proc = subprocess.run(["/usr/bin/osascript", "-e", source], stdin=subprocess.DEVNULL,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=105)
            if proc.returncode:
                failure = ("Authorization was cancelled." if b"-128" in proc.stderr else
                           "The administrator request did not complete.")
        except (OSError, subprocess.TimeoutExpired):
            failure = "The administrator request was unavailable or timed out."
    lines = []
    verified = True
    for key in keys:
        try:
            now = mac_value(key)
            if key == "mac-stealth" and now == "1" and mac_value("mac-firewall") not in ("1", "2"):
                verified = False
                lines.append("[REVIEW] Stealth mode is on, but the application firewall is off.")
                continue
            if now in allowed[key]:
                lines.append("[OK] " + names[key] + (" was already enabled." if key not in drift else " is now enabled."))
                if key in drift and before[key] == "0":
                    lines.append("  To restore the previous setting: sudo " + ALF + " " + switch[key] + " off")
            else:
                verified = False
                lines.append("[REVIEW] " + names[key] + " is still off.")
        except (Unavailable, OSError, ValueError):
            verified = False
            lines.append("[UNKNOWN] Could not verify " + names[key] + ".")
    if failure:
        lines.append(failure)
    text = "\n".join(lines)
    if not verified or failure:
        raise Unavailable(text)
    return text


def main(argv=None):
    parser = argparse.ArgumentParser(prog="cadi-guard", description=__doc__)
    parser.add_argument("--version", action="version", version=f"CaDi v1 {VERSION}")
    sub = parser.add_subparsers(dest="operation")
    parser.add_argument("--desktop-time", action="store_true", help=argparse.SUPPRESS)
    au = sub.add_parser("audit", help="Inspect this device (default)")
    au.add_argument("--json", action="store_true", help="Print the local report as JSON")
    au.add_argument("--cadi-dir", metavar="DIR", help="Inspect deployment file permissions in DIR")
    for name in ("plan", "apply"):
        part = sub.add_parser(name, help="Preview one setting" if name == "plan" else "Confirm and verify one change")
        part.add_argument("control", metavar="CONTROL", nargs="?", help="Omit to list available controls")
        part.add_argument("--cadi-dir", metavar="DIR", help="CaDi deployment for file permission controls")
    for name,desc in (("traffic","Sample one Linux interface"),
                      ("ospf","Review Linux OSPF evidence"),("workers","Run bounded diagnostic workers")):
        subp=sub.add_parser(name,help=desc)
        subp.add_argument("--json",action="store_true")
        if name in ("traffic","workers"):
            subp.add_argument("--seconds",type=sample_seconds,default=5)
        if name in ("traffic","workers"): subp.add_argument("--interface",required=name=="traffic")
        if name=="traffic": subp.add_argument("--headers",action="store_true",help="Include passive IP base-header protocol counts")
        if name=="workers": subp.add_argument("--checks",nargs="+",required=True,choices=["ospf","traffic"])
    if platform.system() == "Linux":
        sub.add_parser("console", help="Open the local diagnostic command builder")
    sub.add_parser("connector-config",help="Print local Hermes MCP settings")
    sub.add_parser("connector",help="Serve read-only MCP tools over standard input/output")
    sub.add_parser("kernel", help="Check kernel protections and published fixes on this OS")
    watch = sub.add_parser("watch", help="Manage local background connection alerts")
    watch.add_argument("watch_args", nargs=argparse.REMAINDER)
    for op in ("backup","restore"):
        part=sub.add_parser(op, help="Save or restore an individual file")
        part.add_argument("file");part.add_argument("folder")
    sub.add_parser("processes", help="Compare two local process inventories")
    quitproc = sub.add_parser("quit-process", help="Request that one reviewed user app quit")
    quitproc.add_argument("id")
    quitproc.add_argument("--confirm", action="store_true", required=True)
    protect = sub.add_parser("desktop-harden", help="Apply and verify selected macOS firewall settings")
    protect.add_argument("controls", nargs="+", choices=("mac-firewall", "mac-stealth"))
    args = parser.parse_args(argv)
    system = platform.system()
    if system not in ("Darwin", "Linux", "Windows"):
        parser.error("This build targets Windows, macOS and Linux.")
    try:
        stamp = "Scan time (UTC) " + dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
        if args.desktop_time and args.operation in ("plan", "desktop-harden"):
            print(stamp)
        if args.operation in ("watch","backup","restore"):
            import runpy
            if args.operation=="watch":
                mod=runpy.run_path(str(Path(__file__).resolve().with_name("cadi_watch.py")))
                mod["main"](args.watch_args or ["events"])
            else:
                mod=runpy.run_path(str(Path(__file__).resolve().with_name("cadi_recovery.py")))
                print(mod["save" if args.operation=="backup" else "restore"](args.file,args.folder))
            return 0
        if args.operation in ("kernel", "processes", "quit-process"):
            import runpy
            inspect = runpy.run_path(str(Path(__file__).resolve().with_name("cadi_inspect.py")))
            if args.operation == "kernel":
                print(stamp + "\n" + inspect["kernel"](system))
            elif args.operation in ("processes", "quit-process"):
                proc = runpy.run_path(str(Path(__file__).resolve().with_name("cadi_process.py")))
                if args.operation == "processes":
                    report = proc["scan"](system, inspect["ps"])
                    report["notes"].insert(0,stamp)
                    print(json.dumps(report, indent=2))
                else:
                    print(proc["stop"](system, args.id, inspect["ps"]))
            return 0
        if args.operation == "desktop-harden":
            if system != "Darwin":
                raise Unavailable("This protection profile requires macOS.")
            print(desktop_harden(args.controls))
            return 0
        if args.operation in (None, "audit"):
            report = audit(system, getattr(args, "cadi_dir", None))
            if getattr(args, "json", False):
                print(json.dumps(report, indent=2))
            else:
                render_report(report)
            return 0
        if args.operation=="connector-config":
            print(hermes_config())
            return 0
        if args.operation=="connector":
            mcp_server(system)
            return 0
        if args.operation=="console":
            control_panel(system)
            return 0
        if args.operation in ("traffic", "ospf", "workers"):
            if system != "Linux":
                raise Unavailable("This check requires Linux.")
            if args.operation == "traffic":
                result=traffic_report(args.interface,args.seconds,args.headers)
            elif args.operation=="ospf": result=ospf_report()
            else: result=run_workers(system,args.checks,args.seconds,args.interface)
            print_network_result(result,args.json)
            if "results" in result and any(j["status"]!="COMPLETED" for j in result["results"].values()):
                return 1
            return 0
        controls = platform_controls(system, for_change=True)
        files = {"cadi-config": "config.json", "cadi-env": ".env"} if system != "Windows" else {}
        if not args.control:
            for name, control in controls.items():
                print(f"{name:24} {control.title}")
            for name, target in files.items():
                print(f"{name:24} Restrict {target} to its owner (requires --cadi-dir)")
            return 0
        if args.operation == "apply" and not sys.stdin.isatty():
            raise Unavailable("Apply requires an interactive terminal.")
        if args.control in files and args.cadi_dir:
            restrict_file(args.cadi_dir, files[args.control], args.operation == "apply")
        elif args.control in files:
            parser.error("A deployment file change requires --cadi-dir DIR.")
        elif args.control in controls and not args.cadi_dir:
            change(controls[args.control], args.operation == "apply")
        else:
            parser.error("Unknown control or incompatible option. Run 'cadi-guard plan' to list controls.")
        return 0
    except (Unavailable, OSError, ValueError, MemoryError, subprocess.SubprocessError) as exc:
        if getattr(args,"json",False): print(json.dumps({"error":str(exc) or "Insufficient memory."}))
        else: print("CaDi v1:", exc, file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nInterrupted. Re-run the audit to confirm current settings.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
