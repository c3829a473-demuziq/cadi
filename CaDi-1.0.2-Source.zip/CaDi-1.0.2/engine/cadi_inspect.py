"""CaDi local kernel checks. Requires Python 3.9+."""
import argparse
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys

APPLE = "https://support.apple.com/en-us/100100"
MSRC = "https://msrc.microsoft.com/update-guide/vulnerability/CVE-2024-30088"
DEBIAN = "https://security-tracker.debian.org/tracker/"
FIXES = {"13": ("13.6.5", "https://support.apple.com/en-us/120886"),
         "14": ("14.4", "https://support.apple.com/en-us/120895")}
WIN_FIX = {19044: 4529, 19045: 4529, 22621: 3737, 22631: 3737}
DEB_FIX = {"bullseye": ("5.10.209-2", "CVE-2024-1086"), "bookworm": ("6.1.76-1", "CVE-2024-1086"),
           "trixie": ("6.12.43-1", "CVE-2025-38686")}


def run(argv, timeout=20, codes=(0,), include_stderr=False):
    env = os.environ.copy()
    if os.name != "nt":
        env.update(LC_ALL="C", PATH="/usr/bin:/bin:/usr/sbin:/sbin")
    elif Path(argv[0]).name.lower() == "powershell.exe":
        psdir = Path(argv[0]).parent
        env["PSModulePath"] = str(psdir / "Modules")
        env["PATH"] = str(psdir.parents[1]) + os.pathsep + str(psdir.parents[1] / "wbem")
    try:
        p = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT if include_stderr else subprocess.PIPE,
                           timeout=timeout, env=env, creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))

    except (OSError, subprocess.TimeoutExpired) as error:
        raise ValueError(f"{Path(argv[0]).name} unavailable or timed out") from error
    if p.returncode not in codes:
        raise ValueError(f"{Path(argv[0]).name} returned {p.returncode}. Check permissions or open the system tool.")
    return p.stdout.decode("utf-8-sig", "replace").strip()


def ps(code, timeout=30):
    # Ask Windows for its system directory; do not resolve PowerShell via PATH.
    import ctypes
    buf = ctypes.create_unicode_buffer(32768)
    if not ctypes.windll.kernel32.GetSystemDirectoryW(buf, len(buf)):
        raise ValueError("Windows system directory unavailable")
    exe = Path(buf.value) / "WindowsPowerShell/v1.0/powershell.exe"
    return run([str(exe), "-NoProfile", "-NonInteractive", "-Command",
                "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new(); " + code], timeout)


def checked(fn):
    try:
        return fn()
    except (ValueError, OSError, TypeError, KeyError, subprocess.SubprocessError) as e:
        return "[UNKNOWN] " + str(e)


def level(fixed, older, advisory):
    return (("[REVIEW] Installed version is below the vendor fix " if older else
             "[CHECKED] Installed version is at or above the vendor fix ") + fixed + " for " + advisory)


def mac_advisory(version):
    if not re.fullmatch(r"\d+\.\d+(?:\.\d+)?", version):
        return "[UNKNOWN] Unrecognized macOS version."
    fix = FIXES.get(version.split(".")[0])
    if not fix:
        return "[UNKNOWN] No bundled kernel advisory comparison for this macOS release."
    numbers = lambda v: tuple(int(x) for x in (v + ".0.0").split(".")[:3])
    return level(fix[0], numbers(version) < numbers(fix[0]), "CVE-2024-23225") + "\n  " + fix[1]


def mac_updates():
    out = run(["/usr/sbin/softwareupdate", "--list"], 65, include_stderr=True)
    labels = [l.strip() for l in out.splitlines() if re.match(r"\s*\*\s+(?:Label: )?", l)]
    if labels:
        return "[REVIEW] Apple offers these software updates\n  " + "\n  ".join(labels[:30])
    if "No new software available" in out:
        return "[INFO] Apple Software Update offered no updates to this Mac."
    return "[UNKNOWN] Could not verify the Software Update result. Open Software Update in Settings."


def win_advisory(build, revision):
    if build not in WIN_FIX or not isinstance(revision, int) or revision < 0:
        return "[UNKNOWN] No bundled comparison for this Windows build."
    return level(f"{build}.{WIN_FIX[build]}", revision < WIN_FIX[build], "CVE-2024-30088") + "\n  " + MSRC


def windows_build():
    import winreg
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion",
                        0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
        build = int(winreg.QueryValueEx(k, "CurrentBuildNumber")[0])
        revision = winreg.QueryValueEx(k, "UBR")[0]
    return f"Windows installed build {build}.{revision}\n" + win_advisory(build, revision)


def windows_updates():
    reply = json.loads(ps("""$s=(New-Object -ComObject Microsoft.Update.Session).CreateUpdateSearcher()
$r=$s.Search("IsInstalled=0 and IsHidden=0 and Type='Software'")
@{status=[int]$r.ResultCode;updates=@($r.Updates | ForEach-Object {$_.Title})} | ConvertTo-Json -Compress""", 65))
    if reply["status"] != 2:
        return "[UNKNOWN] Windows Update could not complete its search."
    titles = reply["updates"]
    return ("[REVIEW] Windows Update offers\n  " + "\n  ".join(titles[:30]) if titles
            else "[INFO] Windows Update offered no software updates from the configured source.")


def os_release():
    data = {}
    for line in Path("/etc/os-release").read_text().splitlines():
        if "=" in line:
            key, val = line.split("=", 1)
            data[key] = val.strip('"')
    return data


def deb_advisory(release, kernel):
    fix = DEB_FIX.get(release.get("VERSION_CODENAME"))
    if release.get("ID") != "debian" or not fix:
        return "[UNKNOWN] No bundled kernel advisory comparison for this distribution release."
    fix, advisory = fix
    package = run(["/usr/bin/dpkg-query", "-W", "-f=${db:Status-Abbrev}|${Package}|${Version}|${Built-Using}",
                   "linux-image-" + kernel])
    fields = package.split("|")
    if len(fields) != 4 or not fields[0].startswith("ii") or fields[1] != "linux-image-" + kernel:
        return "[UNKNOWN] No installed package matching the running kernel."
    # Debian embeds the source revision in the running kernel banner. The image on disk may be newer.
    banner = Path("/proc/version").read_text()
    hit = re.search(r"\bDebian (\d[\w.+~:-]*) \(", banner)
    if not hit or hit.group(1) != fields[2] or "~bpo" in fields[2]:
        return "[UNKNOWN] Cannot match the running Debian source revision to a standard installed kernel package."
    cmd = ["/usr/bin/dpkg", "--compare-versions", fields[2], "lt", fix]
    comparison = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, timeout=5)
    if comparison.returncode not in (0, 1):
        raise ValueError("Debian version comparison failed")
    return level(fix, comparison.returncode == 0, advisory) + "\n  " + DEBIAN + advisory


def linux_mitigations(folder=Path("/sys/devices/system/cpu/vulnerabilities")):
    rows = []
    for f in sorted(folder.iterdir()):
        value = checked(lambda: f.read_text().strip())
        flag = "REVIEW" if re.search(r"\bvulnerable\b", value, re.I) and "not vulnerable" not in value.lower() else "INFO"
        if "unknown" in value.lower() or not value:
            flag = "UNKNOWN"
        rows.append(f"[{flag}] {f.name}: {value}")
    return "\n".join(rows) or "[UNKNOWN] The kernel published no CPU vulnerability entries."


def linux_updates():
    if not Path("/usr/bin/apt").is_file():
        return "[UNKNOWN] Check kernel updates with this distribution's package manager."
    packages = run(["/usr/bin/apt", "list", "--upgradable"])
    lines = [s for s in packages.splitlines() if re.match(r"linux-(image|generic|virtual|oem|aws|azure|cloud|kbuild)[^/]*/", s)]
    return ("[REVIEW] Kernel-related updates in the local APT cache\n  " + "\n  ".join(lines[:30]) if lines
            else "[INFO] No kernel update listed in the local APT cache. Its package lists may be old.")


def kernel(system):
    running = platform.version() if system == "Windows" else platform.release()
    rows = [f"{system} kernel {running} · {platform.machine()}"]
    if system == "Darwin":
        version = checked(lambda: run(["/usr/bin/sw_vers", "-productVersion"]))
        rows += ["macOS " + version + " · build " + checked(lambda: run(["/usr/bin/sw_vers", "-buildVersion"])),
                 mac_advisory(version), checked(lambda: run(["/usr/bin/csrutil", "status"])),
                 checked(mac_updates), APPLE]
    elif system == "Windows":
        rows += [checked(windows_build), checked(lambda: ps(
            "$v=Get-CimInstance -Namespace root/Microsoft/Windows/DeviceGuard -ClassName Win32_DeviceGuard; "
            "if($null -eq $v.SecurityServicesRunning){throw 'No Device Guard report'}; "
            "if(2 -in $v.SecurityServicesRunning){'Memory integrity is running'}else{'[REVIEW] Memory integrity is not running'}")),
            checked(windows_updates)]
    elif system == "Linux":
        rows += [checked(lambda: deb_advisory(os_release(), platform.release())), checked(linux_updates),
                 checked(linux_mitigations)]
        if Path("/var/run/reboot-required").exists():
            rows.append("[REVIEW] The OS has requested a restart.")
    else:
        raise ValueError("Supported systems are macOS, Windows and Linux.")
    rows += ["This read-only check covers selected published fixes and the protections your OS reports. "
             "It cannot tell whether someone has already used a flaw."]
    return "\n\n".join(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("kernel")
    args = parser.parse_args()
    system = platform.system()
    if args.command == "kernel":
        print(kernel(system))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
