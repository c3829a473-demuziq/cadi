"""Save a selected regular file and restore a verified copy to a new file."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
import uuid
import zipfile

LIMIT=512*1024*1024


def copy_stream(src,dst):
    digest=hashlib.sha256();size=0
    while True:
        data=src.read(1024*1024)
        if not data:break
        size+=len(data)
        if size>LIMIT:raise ValueError("Choose a file of 512 MiB or less.")
        digest.update(data);dst.write(data)
    return digest.hexdigest()


def save(source, folder):
    src=Path(source).expanduser(); folder=Path(folder).expanduser()
    if not src.is_absolute() or not folder.is_absolute() or not folder.is_dir():
        raise ValueError("Enter a full file path and an existing backup folder.")
    if not stat.S_ISREG(src.lstat().st_mode) or src.is_symlink():
        raise ValueError("Choose a regular file.")
    dest=folder/("CaDi-"+uuid.uuid4().hex+".cadi")
    try:
        with src.open("rb") as f:
            before=os.fstat(f.fileno())
            if not stat.S_ISREG(before.st_mode) or before.st_size>LIMIT:raise ValueError("Choose a regular file of 512 MiB or less.")
            with dest.open("xb") as output:
                with zipfile.ZipFile(output,"w",zipfile.ZIP_STORED) as z:
                    with z.open("contents","w") as stream:sha=copy_stream(f,stream)
                    if before.st_mtime_ns != os.fstat(f.fileno()).st_mtime_ns:
                        raise ValueError("The file changed during backup. Try again.")
                    z.writestr("manifest.json",json.dumps(dict(name=src.name,sha256=sha,utc=dt.datetime.now(dt.timezone.utc).isoformat())))
                output.flush();os.fsync(output.fileno())
    except FileExistsError:raise
    except BaseException:
        dest.unlink(missing_ok=True);raise
    return "Backup saved. Keep it on a separate trusted drive.\n"+str(dest)


def restore(archive,folder):
    path=Path(archive).expanduser();folder=Path(folder).expanduser()
    if not path.is_absolute() or not folder.is_absolute() or path.is_symlink() or not path.is_file() or not folder.is_dir():
        raise ValueError("Enter a CaDi backup path and an existing recovery folder.")
    try:
        with zipfile.ZipFile(path) as z:
            if sorted(z.namelist())!=["contents","manifest.json"] or z.getinfo("manifest.json").file_size>12000 or z.getinfo("contents").file_size>LIMIT:
                raise ValueError("Unrecognized or oversized backup.")
            meta=json.loads(z.read("manifest.json"))
            name=meta["name"]
            if not isinstance(name,str) or name in (".","..","") or any(c in name for c in ("/","\\",":","\0")):
                raise ValueError("Invalid backup filename.")
            # A random prefix avoids reserved device filenames and existing files.
            target=folder/("Recovered-"+uuid.uuid4().hex[:8]+"-"+name)
            with tempfile.TemporaryFile(dir=folder) as tmp:
                with z.open("contents") as original:hashed=copy_stream(original,tmp)
                if hashed!=meta["sha256"]:raise ValueError("Backup verification failed.")
                tmp.seek(0)
                with target.open("xb") as writer:
                    try:copy_stream(tmp,writer);writer.flush();os.fsync(writer.fileno())
                    except BaseException:
                        writer.close();target.unlink(missing_ok=True);raise
        return "Restored and verified a new copy.\n"+str(target)
    except (zipfile.BadZipFile,KeyError,TypeError) as e:raise ValueError("Damaged or unrecognized CaDi backup.") from e
