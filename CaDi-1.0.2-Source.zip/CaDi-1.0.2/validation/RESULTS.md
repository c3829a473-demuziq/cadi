# CaDi 1.0.2 verification

The replacement Debian 13 x86-64 build was compiled with the locked Rust dependencies in a Debian 13 container. These results apply to 1.0.2; they are not inherited from older VM runs.

- 57 Python engine tests passed, including rejection of the removed entry points and checks that the connector and command builder do not expose them.
- 19 Rust tests passed, including rendering the desktop views. One optional test that requires a local model server was not run.
- The packaged executable opened a CaDi desktop window on a temporary X11 display with software OpenGL. The packaged command-line audit and process report both returned valid JSON.
- Native Intel macOS and Windows were not tested for this build.
