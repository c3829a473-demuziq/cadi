"""Exercise real systemd user-service registration inside the offline disposable QEMU guest."""
import json
import os
import pathlib
import pwd
import shutil
import socket
import subprocess
import sys
import time
import traceback


def cmd(*argv):
    p=subprocess.run(argv,check=False,capture_output=True,text=True,timeout=60)
    if p.returncode:raise RuntimeError(" ".join(argv)+" "+p.stderr[-1000:])
    return p.stdout


def main():
    assert cmd("systemd-detect-virt").strip()=="qemu" and socket.gethostname()=="cadi-validation" and os.listdir("/sys/class/net")==["lo"]
    cmd("useradd","-m","cadistart")
    acct=pwd.getpwnam("cadistart")
    home=pathlib.Path(acct.pw_dir)
    script=home/"cadi_watch.py";shutil.copyfile(pathlib.Path(__file__).with_name("cadi_watch.py"),script)
    cmd("loginctl","enable-linger","cadistart")
    runtime=f"/run/user/{acct.pw_uid}"
    for _ in range(120):
        if pathlib.Path(runtime,"bus").is_socket():break
        time.sleep(.25)
    prefix=["runuser","-u","cadistart","--","env","HOME="+str(home),"XDG_RUNTIME_DIR="+runtime,"DBUS_SESSION_BUS_ADDRESS=unix:path="+runtime+"/bus"]
    command=[*prefix,sys.executable,"-I","-B",str(script)]
    cmd(*command,"enable")
    assert cmd(*prefix,"systemctl","--user","is-active","cadi-watch.service").strip()=="active"
    state=home/".config/cadi/watch/events.json"
    for _ in range(80):
        if state.exists():break
        time.sleep(.25)
    assert json.loads(state.read_text())["last_check"]
    cmd(*command,"disable")
    assert not (state.parent/"enabled").exists()
    p=subprocess.run([*prefix,"systemctl","--user","is-active","cadi-watch.service"],capture_output=True)
    assert p.returncode!=0
    print('CADI_VM ["startup","PASS · Linux user service installed, sampled with linger and no GUI session, then disabled and removed."]',flush=True)


if __name__=="__main__":
    try:main()
    except Exception:traceback.print_exc();print('CADI_VM ["startup","FAIL"]',flush=True)
