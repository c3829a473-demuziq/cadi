"""Exercise a prepared, offline Debian QA guest. The seed supplies the engine, tests, and model."""
import errno
import hashlib
import json
import os
import platform
import pty
import select
import socket
import stat
import subprocess
import sys
import tempfile
import time
import traceback
import urllib.error
import urllib.request
from pathlib import Path


HERE = Path(__file__).resolve().parent
CLI = [sys.executable, "-I", "-B", str(HERE / "cadi_guard.py")]
KNOB = Path("/proc/sys/net/ipv4/icmp_echo_ignore_broadcasts")


def note(key, value):
    print("CADI_VM " + json.dumps([key, value]), flush=True)


def command(args, timeout=120, **kwargs):
    result = subprocess.run(args, text=True, capture_output=True, timeout=timeout, **kwargs)
    if result.returncode:
        raise RuntimeError(result.stdout[-2000:] + result.stderr[-2000:])
    return result.stdout + result.stderr


def confirm_change(args, answer):
    master, slave = pty.openpty()
    process = subprocess.Popen(CLI + ["apply"] + args, stdin=slave, stdout=slave, stderr=slave)
    os.close(slave)
    output = bytearray()
    sent = False
    try:
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            if not select.select([master], [], [], 0.5)[0]:
                if process.poll() is not None:
                    break
                continue
            try:
                chunk = os.read(master, 8192)
            except OSError as exc:
                if exc.errno == errno.EIO:
                    break
                raise
            if not chunk:
                break
            output.extend(chunk)
            if not sent and b"Type APPLY" in output:
                os.write(master, (answer + "\n").encode())
                sent = True
        return process.wait(timeout=3), output.decode(errors="replace")
    finally:
        os.close(master)
        if process.poll() is None:
            process.kill()
            process.wait()


def audit(directory):
    return json.loads(command(CLI + ["audit", "--cadi-dir", str(directory), "--json"]))


def file_check(directory):
    config = directory / "config.json"
    original = b'{"purpose":"disposable VM fixture"}\n'
    config.write_bytes(original)
    config.chmod(0o644)
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        port = listener.getsockname()[1]
        result = audit(directory)
        assert result["platform"] == "Linux"
        assert any(row["port"] == port for row in result["tcp_listeners"])
        note("audit", {"listener_detected": True, "findings": len(result["findings"])})
    args = ["cadi-config", "--cadi-dir", str(directory)]
    command(CLI + ["plan"] + args)
    assert stat.S_IMODE(config.stat().st_mode) == 0o644
    rc, text = confirm_change(args, "CANCEL")
    assert rc != 0 and "Cancelled" in text, text
    assert stat.S_IMODE(config.stat().st_mode) == 0o644
    note("cancelled_change", {"mode": "0644", "preserved": True})
    rc, text = confirm_change(args, "APPLY")
    assert rc == 0 and stat.S_IMODE(config.stat().st_mode) == 0o600, text
    assert config.read_bytes() == original
    note("file_hardening", {"before": "0644", "after": "0600", "contents_unchanged": True})


def kernel_check(directory):
    before = KNOB.read_text()
    try:
        KNOB.write_text("0\n")
        command(CLI + ["plan", "linux-broadcast-echo"])
        assert KNOB.read_text().strip() == "0"
        rc, text = confirm_change(["linux-broadcast-echo"], "APPLY")
        assert rc == 0 and KNOB.read_text().strip() == "1", text
        rc, text = confirm_change(["linux-broadcast-echo"], "APPLY")
        assert rc == 0 and "Already enabled" in text, text
        control = next(row for row in audit(directory)["findings"] if row["id"] == "linux-broadcast-echo")
        assert control["status"] == "OK", control
        note("kernel_hardening", {"before": 0, "after": 1, "audit": "OK", "repeat": "already enabled"})
    finally:
        KNOB.write_text(before)


def model_check():
    binary = HERE / "rust-tests"
    runner = HERE / "llama/llama-server"
    url = "http://127.0.0.1:18891"
    args = [str(runner), "-m", str(HERE / "smoke.gguf"), "--host", "127.0.0.1",
            "--port", "18891", "--alias", "local-test", "--chat-template", "chatml",
            "-t", "1", "-c", "256", "-n", "24", "-np", "1"]
    env = dict(os.environ, LD_LIBRARY_PATH=str(runner.parent))
    with tempfile.TemporaryFile(mode="w+") as log:
        process = subprocess.Popen(args, env=env, stdout=log, stderr=log)
        try:
            for _ in range(180):
                if process.poll() is not None:
                    log.seek(0)
                    raise RuntimeError(log.read()[-1500:])
                try:
                    with urllib.request.urlopen(url + "/health", timeout=2) as response:
                        if response.status == 200:
                            break
                except (OSError, urllib.error.URLError):
                    pass
                time.sleep(0.5)
            else:
                raise RuntimeError("The model server did not become ready.")
            result = command([str(binary), "real_local_inference", "--ignored"], timeout=150,
                             env=dict(os.environ, CADI_LOCAL_TEST_URL=url + "/v1"))
            assert "1 passed" in result, result
            note("local_ai", {"server": "llama.cpp", "model": "TinyStories 15M Q4_0",
                              "models_listed": True, "model_returned_text": True})
        finally:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


def main():
    virtualization = command(["systemd-detect-virt"]).strip()
    interfaces = sorted(os.listdir("/sys/class/net"))
    if virtualization != "qemu" or socket.gethostname() != "cadi-validation" or interfaces != ["lo"]:
        raise RuntimeError("This scenario requires the isolated cadi-validation QEMU guest.")
    note("guest", {"os": platform.freedesktop_os_release()["PRETTY_NAME"], "kernel": platform.release(),
                   "machine": platform.machine(), "virtualization": virtualization, "interfaces": interfaces})
    note("engine_sha256", hashlib.sha256((HERE / "cadi_guard.py").read_bytes()).hexdigest())
    kernel_report = command([sys.executable, "-I", "-B", str(HERE / "cadi_guard.py"), "kernel"])
    assert platform.release() in kernel_report and "CVE-2025-38686" in kernel_report, kernel_report
    assert "spectre" in kernel_report.lower(), kernel_report
    note("kernel_review", kernel_report)
    note("inspect_sha256", hashlib.sha256((HERE/"cadi_inspect.py").read_bytes()).hexdigest())
    with tempfile.TemporaryDirectory(dir="/root") as directory:
        file_check(Path(directory))
        kernel_check(Path(directory))
    # These checks run only after the standalone guest, hostname and interface guard above.
    import shutil
    import runpy
    import pwd
    monitor = runpy.run_path(str(HERE/"cadi_watch.py"))
    with tempfile.TemporaryDirectory(dir="/root") as work:
        folder=Path(work)
        (folder/"enabled").touch()
        command(["ip","addr","add","192.0.2.1/32","dev","lo"])
        command(["ip","addr","add","192.0.2.2/32","dev","lo"])
        try:
            with socket.socket() as listener, socket.socket() as client:
                listener.bind(("192.0.2.1",5900));listener.listen()
                client.bind(("192.0.2.2",0));client.connect(listener.getsockname())
                conn,_=listener.accept()
                with conn:
                    worker=subprocess.Popen([sys.executable,"-I","-B","-c",
                        "import runpy,pathlib,sys;runpy.run_path(sys.argv[1])['monitor_loop'](pathlib.Path(sys.argv[2]))",
                        str(HERE/"cadi_watch.py"),str(folder)])
                    try:
                        for _ in range(60):
                            if (folder/"events.json").exists():break
                            time.sleep(.25)
                        log=monitor["report"](folder)
                        assert "192.0.2.2" in log and "5900" in log,log
                        client.sendall(b"up");assert conn.recv(2)==b"up"
                    finally:
                        (folder/"enabled").unlink();worker.wait(timeout=15)
        finally:
            command(["ip","addr","del","192.0.2.1/32","dev","lo"])
            command(["ip","addr","del","192.0.2.2/32","dev","lo"])
        sample=folder/"audio.txt";sample.write_text("original audio notes")
        archive=command([*CLI,"backup",str(sample),str(folder)]).strip().splitlines()[-1]
        sample.unlink()
        restored=command([*CLI,"restore",archive,str(folder)]).strip().splitlines()[-1]
        assert Path(restored).read_text()=="original audio notes"
    note("incident_response","A separate background worker observed a real established TCP/5900 connection in the VM. It wrote a local incident without a model or external network. The connection remained usable.")
    note("recovery","A saved fixture was deleted inside the VM and restored byte-for-byte to a new file.")
    command(["useradd","-m","cadiqa"])
    home=Path(pwd.getpwnam("cadiqa").pw_dir)
    app=home/"optional-sleep";shutil.copy2("/bin/sleep",app);shutil.chown(app,user="cadiqa",group="cadiqa")
    # Run the test as a regular user with a private copy of the packaged engine.
    for name in ("cadi_guard.py","cadi_inspect.py","cadi_process.py"):
        shutil.copy2(HERE/name,home/name)
    process=subprocess.Popen(["runuser","-u","cadiqa","--",str(app),"180"])
    try:
        time.sleep(1)
        scan=json.loads(command(["runuser","-u","cadiqa","--",sys.executable,"-I","-B",str(home/"cadi_guard.py"),"processes"]))
        choices=[x for x in scan["items"] if x["detail"]==str(app) and x["id"]]
        assert len(choices)==1,choices
        ack=command(["runuser","-u","cadiqa","--",sys.executable,"-I","-B",str(home/"cadi_guard.py"),"quit-process",choices[0]["id"],"--confirm"])
        assert "Quit requested" in ack
        process.wait(timeout=10)
        assert not Path("/proc/"+choices[0]["id"].split("-")[0]).exists()
    finally:
        if process.poll() is None:process.terminate();process.wait()
    note("process_review","A regular test user selected its own disposable process. The identity-checked quit request terminated that process. The PID was independently checked afterward.")
    tests = command([sys.executable, "-B", "-m", "unittest", "discover", "-s", str(HERE / "tests")])
    assert "Ran 66 tests" in tests and "OK" in tests, tests
    note("engine_tests", "66 passed")
    rust = command([str(HERE / "rust-tests"), "--test-threads=1"], timeout=300)
    assert "20 passed; 0 failed" in rust, rust
    note("rust_tests", "20 passed")
    model_check()
    note("result", "PASS")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        note("result", "FAIL")
        sys.exit(1)
