use eframe::egui;
use serde::Deserialize;

#[derive(Clone, Deserialize)]
struct Item {
    id: String,
    name: String,
    detail: String,
    action: String,
}
#[derive(Default, Deserialize)]
struct Scan {
    notes: Vec<String>,
    items: Vec<Item>,
}
#[derive(Default)]
pub struct ProcessView {
    scan: Option<Scan>,
    choice: Option<Item>,
    request: Option<String>,
    pub removing: bool,
    pub rescan: bool,
    notice: String,
    filter: String,
}
impl ProcessView {
    pub fn summary(&self) -> Option<String> {
        let scan = self.scan.as_ref()?;
        let mut lines = scan.notes.clone();
        if let Some(item) = &self.choice {
            lines.push(format!("Selected: {} · {}", item.name, item.detail));
        }
        for item in scan.items.iter().take(40) {
            lines.push(item.name.clone());
        }
        if scan.items.len() > 40 {
            lines.push(format!("Showing 40 of {} entries.", scan.items.len()));
        }
        Some(lines.join("\n"))
    }
    pub fn args(&mut self) -> Vec<String> {
        if let Some(id) = self.request.take() {
            self.removing = true;
            return vec![
                "quit-process".into(),
                id,
                "--confirm".into(),
            ];
        }
        self.choice = None;
        self.scan = None;
        vec!["processes".into()]
    }
    pub fn finish(&mut self, result: &Result<String, String>) {
        if self.removing {
            self.removing = false;
            self.choice = None;
            self.notice = match result {
                Ok(s) | Err(s) => s.trim().to_owned(),
            };
            self.rescan = true;
        } else if let Ok(raw) = result {
            match serde_json::from_str(raw) {
                Ok(s) => self.scan = Some(s),
                Err(_) => {
                    self.notice = "CaDi could not read the report. Run the scan again.".into()
                }
            }
        }
    }
    pub fn show(
        &mut self,
        ui: &mut egui::Ui,
        available: bool,
        error: Option<&str>,
    ) -> bool {
        let mut start = ui
            .add_enabled(
                available,
                egui::Button::new("Check running processes"),
            )
            .clicked();
        if let Some(e) = error {
            ui.colored_label(ui.visuals().error_fg_color, e);
        }
        if !self.notice.is_empty() {
            ui.label(&self.notice);
            if ui.small_button("Copy result").clicked() {
                ui.ctx().copy_text(self.notice.clone());
            }
        }
        if let Some(scan) = &self.scan {
            egui::ScrollArea::vertical().id_salt("process-list").show(ui, |ui| {
                ui.heading("Process visibility");
                for line in &scan.notes { ui.add(egui::Label::new(line).wrap().selectable(true)); }
                ui.add_space(8.);
                ui.heading("Processes in this scan");
                ui.label("Review a PID to inspect its path. Eligible user apps have a quit button. Save open work first.");
                if let Some(item) = self.choice.clone() {
                    ui.strong(&item.name);
                    ui.label(&item.detail);
                    ui.horizontal_wrapped(|ui| {
                        if !item.action.is_empty() && ui.add_enabled(available,egui::Button::new(&item.action)).clicked(){
                            self.request=Some(item.id.clone()); start=true;
                        }
                        if ui.add_enabled(available,egui::Button::new("Back")).clicked(){self.choice=None;}
                    });
                }
                if self.choice.is_some() { return; }
                if scan.items.is_empty(){ ui.label("No processes were listed.");return; }
                ui.add(egui::TextEdit::singleline(&mut self.filter).hint_text("Filter by PID or name"));
                let query=self.filter.to_lowercase();
                for item in &scan.items {
                    if item.name.to_lowercase().contains(&query) {
                        ui.horizontal_wrapped(|ui| {
                            if ui.add_enabled(available,egui::Button::new("Review")).clicked(){self.choice=Some(item.clone());}
                            ui.label(&item.name);
                        });
                    }
                }
            });
        }
        start
    }
}
