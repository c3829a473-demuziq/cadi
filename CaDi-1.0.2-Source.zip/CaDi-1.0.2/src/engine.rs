use std::{
    fs,
    io::{self, Read},
    path::{Path, PathBuf},
    process::{Command, Stdio},
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc,
    },
    thread,
    time::{Duration, Instant},
};

#[derive(Clone)]
pub struct Engine {
    pub python: PathBuf,
    pub script: PathBuf,
}

impl Engine {
    pub fn bundled(executable: &Path) -> Result<Self, String> {
        let dir = executable
            .parent()
            .ok_or("The application folder is incomplete.")?;
        let (resources, python) = if cfg!(target_os = "macos") {
            let res = dir
                .parent()
                .ok_or("The Mac application is incomplete.")?
                .join("Resources");
            (res.clone(), res.join("runtime/bin/python3.12"))
        } else if cfg!(windows) {
            (dir.join("engine"), dir.join("runtime/python.exe"))
        } else {
            (dir.join("engine"), PathBuf::from("/usr/bin/python3"))
        };
        let engine = Self {
            python,
            script: resources.join("cadi_guard.py"),
        };
        if !engine.python.is_file()
            || !engine.script.is_file()
            || !resources.join("cadi_inspect.py").is_file()
        {
            return Err("CaDi needs its engine files and Python. Extract the entire download before opening the app. On Linux, install Python 3.9 or newer.".into());
        }
        Ok(engine)
    }
    pub fn command_text(&self, args: &[&str]) -> String {
        let parts = std::iter::once(self.python.to_string_lossy().into_owned())
            .chain([
                "-I".to_string(),
                "-B".to_string(),
                self.script.to_string_lossy().into_owned(),
            ])
            .chain(args.iter().map(|s| s.to_string()))
            .map(|s| {
                if cfg!(windows) {
                    return format!("'{}'", s.replace('\'', "''"));
                }
                if !s.is_empty()
                    && s.bytes()
                        .all(|b| b.is_ascii_alphanumeric() || b"/._-".contains(&b))
                {
                    s
                } else {
                    format!("'{}'", s.replace('\'', "'\\''"))
                }
            })
            .collect::<Vec<_>>()
            .join(" ");
        if cfg!(windows) {
            format!("& {parts}")
        } else {
            parts
        }
    }
    pub fn run(&self, args: &[String], stop: Arc<AtomicBool>) -> Result<String, String> {
        let mut command = Command::new(&self.python);
        #[cfg(windows)]
        {
            use std::os::windows::process::CommandExt;
            command.creation_flags(0x08000000);
        }
        let mut child = command
            .args(["-I", "-B", "-X", "utf8"])
            .arg(&self.script)
            .arg("--desktop-time")
            .args(args)
            .current_dir(self.script.parent().unwrap_or(Path::new(".")))
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|e| format!("Could not start the bundled audit engine. {e}"))?;
        let stdout = child.stdout.take().unwrap();
        let stderr = child.stderr.take().unwrap();
        let out_reader = thread::spawn(move || read_report(stdout));
        let err_reader = thread::spawn(move || read_report(stderr));
        let deadline = Instant::now() + Duration::from_secs(150);
        loop {
            if stop.load(Ordering::Relaxed) || Instant::now() >= deadline {
                let _ = child.kill();
                let _ = child.wait();
                return Err("The check was cancelled or exceeded its time limit.".into());
            }
            match child.try_wait() {
                Ok(Some(status)) => {
                    let read = |reader: thread::JoinHandle<io::Result<String>>| {
                        reader
                            .join()
                            .map_err(|_| "Report reader stopped.".to_string())?
                            .map_err(|e| e.to_string())
                    };
                    let out = read(out_reader)?;
                    let err = read(err_reader)?;
                    if status.success() {
                        return Ok(out);
                    }
                    let explanation = if err.trim().is_empty() {
                        out.trim()
                    } else {
                        err.trim()
                    };
                    return Err(if explanation.is_empty() {
                        format!("The engine exited with {status}.")
                    } else {
                        serde_json::from_str::<serde_json::Value>(explanation)
                            .ok()
                            .and_then(|v| v.get("error")?.as_str().map(str::to_owned))
                            .unwrap_or_else(|| explanation.to_owned())
                    });
                }
                Ok(None) => thread::sleep(Duration::from_millis(60)),
                Err(e) => {
                    let _ = child.kill();
                    let _ = child.wait();
                    return Err(e.to_string());
                }
            }
        }
    }
}
fn read_report(reader: impl Read) -> io::Result<String> {
    const LIMIT: u64 = 4 * 1024 * 1024;
    let mut bytes = Vec::new();
    reader.take(LIMIT + 1).read_to_end(&mut bytes)?;
    if bytes.len() as u64 > LIMIT {
        return Err(io::Error::other("Report exceeded 4 MiB."));
    }
    Ok(String::from_utf8_lossy(&bytes).into_owned())
}
pub fn discover() -> Result<Engine, String> {
    let path = std::env::current_exe()
        .and_then(fs::canonicalize)
        .map_err(|e| e.to_string())?;
    Engine::bundled(&path)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn shell_copy_preserves_quotes() {
        let e = Engine {
            python: "/A B/bin/python".into(),
            script: "/Sample's/Mac.py".into(),
        };
        assert_eq!(
            e.command_text(&["apply", "mac-firewall"]),
            "'/A B/bin/python' -I -B '/Sample'\\''s/Mac.py' apply mac-firewall"
        );
    }
    #[test]
    fn incomplete_bundle_is_reported() {
        assert!(Engine::bundled(Path::new("/missing/App/Contents/MacOS/CaDi")).is_err());
    }
    #[test]
    fn child_exit_and_stderr_are_handled() {
        let e = Engine {
            python: "/usr/bin/false".into(),
            script: "/missing".into(),
        };
        assert!(e.run(&[], Arc::new(AtomicBool::new(false))).is_err());
    }
}
