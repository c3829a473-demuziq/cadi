use crate::preferences;
use serde::{Deserialize, Serialize};
#[derive(Clone, Copy, Serialize, Deserialize)]
pub struct Protection {
    pub firewall: bool,
    pub stealth: bool,
    pub on_launch: bool,
}
impl Default for Protection {
    fn default() -> Self {
        Self {
            firewall: true,
            stealth: true,
            on_launch: false,
        }
    }
}
impl Protection {
    pub fn read() -> Result<Self, String> {
        preferences::load(&preferences::directory()?.join("protections.json"))
    }
    pub fn save(&self) -> Result<(), String> {
        preferences::update::<Self>(&preferences::directory()?.join("protections.json"), |p| {
            *p = *self
        })
        .map(|_| ())
    }
    pub fn args(&self) -> Result<Vec<String>, String> {
        let mut a = vec!["desktop-harden".into()];
        if self.firewall {
            a.push("mac-firewall".into())
        }
        if self.stealth {
            a.push("mac-stealth".into())
        }
        if a.len() == 1 {
            return Err("Select a protection first.".into());
        }
        Ok(a)
    }
}
