use super::{
    conversation::Conversation,
    engine::Engine,
    preferences,
    provider::{self, Auth, Format, Operation, Profile, Reply, PRESETS},
};
use eframe::egui::{self, RichText};
use serde::{Deserialize, Serialize};
use std::{path::PathBuf, sync::mpsc, thread, time::Duration};

#[derive(Clone, Default, Serialize, Deserialize)]
struct Profiles {
    items: Vec<Profile>,
    last: String,
}
fn file() -> Result<PathBuf, String> {
    Ok(preferences::directory()?.join("providers.json"))
}
pub(crate) fn edit_menu(mut output: egui::text_edit::TextEditOutput, text: &str) {
    let response = output.response;
    let selection_id = response.id.with("selection-before-menu");
    let right_press = response.hovered()
        && response
            .ctx
            .input(|i| i.pointer.button_pressed(egui::PointerButton::Secondary));
    if right_press {
        // TextEdit moves its caret even on a secondary click. Keep the prior selection for the menu.
        if let Some(range) = response
            .ctx
            .data(|d| d.get_temp::<egui::text::CCursorRange>(selection_id))
        {
            if !range.is_empty() && range.as_sorted_char_range().end <= text.chars().count() {
                output.state.cursor.set_char_range(Some(range));
                output.state.clone().store(&response.ctx, response.id);
            }
        }
    } else if response.has_focus() && !response.context_menu_opened() {
        if let Some(range) = output.state.cursor.char_range() {
            response
                .ctx
                .data_mut(|d| d.insert_temp(selection_id, range));
        }
    }
    response.context_menu(|ui| {
        if ui
            .add_enabled(!text.is_empty(), egui::Button::new("Copy"))
            .clicked()
        {
            let selection = output
                .state
                .cursor
                .char_range()
                .filter(|range| !range.is_empty());
            let value = selection.map(|range| range.slice_str(text)).unwrap_or(text);
            ui.ctx().copy_text(value.to_owned());
            ui.close();
        }
        if ui.button("Paste").clicked() {
            ui.close();
            response.request_focus();
            ui.ctx()
                .send_viewport_cmd(egui::ViewportCommand::RequestPaste);
        }
    });
}

pub struct Connector {
    plan: crate::chatgpt_ui::PlanPanel,
    use_plan: bool,
    profiles: Profiles,
    edit: Profile,
    key: String,
    models: Vec<String>,
    chat: Conversation,
    status: String,
    error: bool,
    running: Option<(Operation, mpsc::Receiver<Result<Reply, String>>)>,
    mcp_yaml: bool,
}
impl Default for Connector {
    fn default() -> Self {
        let result = file().and_then(|f| preferences::load::<Profiles>(&f));
        let error = result.is_err();
        let status = result.as_ref().err().cloned().unwrap_or_default();
        let profiles = result.unwrap_or_default();
        let edit = profiles
            .items
            .iter()
            .find(|p| p.name == profiles.last)
            .cloned()
            .unwrap_or_else(|| Profile::preset(0));
        let use_plan = preferences::directory()
            .and_then(|dir| preferences::load::<bool>(&dir.join("chatgpt-mode.json")))
            .unwrap_or(false);
        Self {
            plan: Default::default(),
            use_plan,
            profiles,
            edit,
            key: String::new(),
            models: vec![],
            chat: Default::default(),
            status,
            error,
            running: None,
            mcp_yaml: false,
        }
    }
}
impl Connector {
    fn select(&mut self, p: Profile) {
        self.edit = p;
        self.key.clear();
        self.models.clear();
        self.status.clear();
        self.chat = Default::default();
        self.error = false;
    }
    fn save(&mut self) -> Result<(), String> {
        self.edit.name = self.edit.name.trim().into();
        if self.edit.name.is_empty() {
            return Err("Enter a profile name.".into());
        }
        let loc = file()?;
        let account = self.edit.key_id()?;
        let key = provider::clean_key(&self.key)?;
        if !key.is_empty() {
            provider::vault::set(&account, key)?;
        }
        let p = &self.edit;
        self.profiles = preferences::update::<Profiles>(&loc, |s| {
            s.items.retain(|a| a.name != p.name);
            s.items.push(p.clone());
            s.items.sort_by(|a, b| a.name.cmp(&b.name));
            s.last = p.name.clone();
        })?;
        self.key.clear();
        Ok(())
    }
    fn launch(&mut self, ctx: &egui::Context, op: Operation, audit: Option<&str>) {
        self.status.clear();
        self.error = false;
        let p = self.edit.clone();
        let account = match p.key_id() {
            Ok(account) => account,
            Err(reason) => {
                self.status = reason;
                self.error = true;
                return;
            }
        };
        if op != Operation::Models && p.model.trim().is_empty() {
            self.error = true;
            self.status = "Select or type a model ID first.".into();
            return;
        }
        let temp = self.key.clone();
        let messages = if op == Operation::Ask {
            match self.chat.begin(audit) {
                Ok(m) => m,
                Err(e) => {
                    self.status = e;
                    self.error = true;
                    return;
                }
            }
        } else {
            Vec::new()
        };
        let (tx, rx) = mpsc::channel();
        self.running = Some((op, rx));
        let ctx = ctx.clone();
        thread::spawn(move || {
            let result = (|| {
                let key = if temp.trim().is_empty() {
                    provider::vault::get(&account)?
                } else {
                    temp
                };
                provider::request(&p, &key, op, &messages)
            })();
            let _ = tx.send(result);
            ctx.request_repaint();
        });
    }
    fn poll(&mut self) {
        let Some((op, rx)) = &self.running else {
            return;
        };
        let r = match rx.try_recv() {
            Ok(r) => r,
            Err(mpsc::TryRecvError::Empty) => return,
            Err(_) => Err("The provider worker stopped.".into()),
        };
        self.error = r.is_err();
        match r {
            Ok(Reply::Models(ids)) => {
                self.status = format!("{} models available.", ids.len());
                self.edit.select_listed_model(&ids);
                if self.edit.model.trim().is_empty() {
                    self.status
                        .push_str(" Choose a text model for your project.");
                }
                self.models = ids
            }
            Ok(Reply::Text(_)) if *op == Operation::Test => {
                self.status = format!("Connected. {} returned text.", self.edit.model)
            }
            Ok(Reply::Text(t)) => {
                self.chat.finish(Ok(t));
                self.status.clear()
            }
            Err(e) if *op == Operation::Ask => {
                self.chat.finish(Err(e));
                self.status.clear();
            }
            Err(e) => self.status = e,
        }
        self.running = None;
    }
    fn profile_picker(&mut self, ui: &mut egui::Ui) {
        ui.horizontal_wrapped(|ui| {
            egui::ComboBox::from_id_salt("preset")
                .selected_text("Choose a provider…")
                .show_ui(ui, |ui| {
                    for (index, (label, ..)) in PRESETS.iter().enumerate() {
                        let label = if *label == "OpenAI" {
                            "OpenAI (ChatGPT models)"
                        } else {
                            label
                        };
                        if ui.button(label).clicked() {
                            self.select(Profile::preset(index));
                            ui.close();
                        }
                    }
                });
            if self.profiles.items.is_empty() {
                return;
            }
            let mut selection = None;
            egui::ComboBox::from_id_salt("profiles")
                .selected_text("Saved profiles…")
                .show_ui(ui, |ui| {
                    for profile in &self.profiles.items {
                        if ui.button(&profile.name).clicked() {
                            selection = Some(profile.clone());
                            ui.close();
                        }
                    }
                });
            if let Some(profile) = selection {
                self.select(profile);
            }
        });
    }

    fn profile_fields(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        let original = self.edit.clone();
        egui::Grid::new("provider-identity")
            .num_columns(2)
            .spacing([10., 8.])
            .show(ui, |ui| {
                ui.label("Profile name");
                let name = egui::TextEdit::singleline(&mut self.edit.name)
                    .desired_width(280.)
                    .show(ui);
                edit_menu(name, &self.edit.name);
                ui.end_row();
                ui.label("API base URL");
                let base = egui::TextEdit::singleline(&mut self.edit.base)
                    .desired_width(310.)
                    .hint_text("https://your-provider.example/v1")
                    .show(ui);
                edit_menu(base, &self.edit.base);
                ui.end_row();
                ui.label("API format");
                egui::ComboBox::from_id_salt("protocol")
                    .selected_text(self.edit.format.label())
                    .show_ui(ui, |ui| {
                        for format in [Format::Chat, Format::Responses, Format::Anthropic] {
                            ui.selectable_value(&mut self.edit.format, format, format.label());
                        }
                    });
                ui.end_row();
                ui.label("Authentication");
                egui::ComboBox::from_id_salt("auth")
                    .selected_text(self.edit.auth.label())
                    .show_ui(ui, |ui| {
                        for auth in [Auth::Bearer, Auth::XApiKey, Auth::ApiKey] {
                            ui.selectable_value(&mut self.edit.auth, auth, auth.label());
                        }
                    });
                ui.end_row();
            });
        if original != self.edit {
            self.key.clear();
            self.models.clear();
            self.status.clear();
            self.chat = Default::default();
        }
        egui::Grid::new("model-key")
            .num_columns(2)
            .spacing([10., 8.])
            .show(ui, |ui| {
                ui.label("API key");
                ui.horizontal(|ui| {
                    let field = ui.add(
                        egui::TextEdit::singleline(&mut self.key)
                            .password(true)
                            .desired_width(260.)
                            .hint_text("Enter a key or use a saved key"),
                    );
                    if field.changed() {
                        self.chat = Conversation::default();
                    }
                    field.context_menu(|ui| {
                        if ui.button("Paste key").clicked() {
                            self.paste_key();
                            ui.close();
                        }
                    });
                    if ui.button("Paste key").clicked() {
                        self.paste_key();
                    }
                });
                ui.end_row();
                ui.label("Model ID");
                ui.horizontal_wrapped(|ui| {
                    let old_model = self.edit.model.clone();
                    let model = egui::TextEdit::singleline(&mut self.edit.model)
                        .desired_width(155.)
                        .hint_text("Type a model ID")
                        .show(ui);
                    edit_menu(model, &self.edit.model);
                    if ui.button("List models").clicked() {
                        self.launch(ctx, Operation::Models, None);
                    }
                    if !self.models.is_empty() {
                        egui::ComboBox::from_id_salt("model-list")
                            .selected_text("Select…")
                            .show_ui(ui, |ui| {
                                for id in &self.models {
                                    ui.selectable_value(&mut self.edit.model, id.clone(), id);
                                }
                            });
                    }
                    if self.edit.model != old_model {
                        self.status.clear();
                        self.chat = Default::default();
                    }
                });
                ui.end_row();
            });
    }

    fn paste_key(&mut self) {
        let result = arboard::Clipboard::new()
            .and_then(|mut clipboard| clipboard.get_text())
            .map_err(|_| "Could not read clipboard text. Copy the key and try again.".to_owned())
            .and_then(|text| {
                let key = provider::clean_key(&text)?;
                if key.is_empty() {
                    return Err("The clipboard is empty. Copy the API key first.".into());
                }
                if self.key != key {
                    self.chat = Conversation::default();
                }
                self.key = key.to_owned();
                Ok(())
            });
        self.error = result.is_err();
        self.status = result
            .err()
            .unwrap_or_else(|| "Key pasted. Click Test model to connect.".into());
    }

    fn mcp_export(&mut self, ui: &mut egui::Ui, ctx: &egui::Context, engine: Option<&Engine>) {
        ui.collapsing("Connect an external assistant via MCP", |ui| {
            ui.label("Keep the app in its final folder before copying its configuration.");
            ui.horizontal(|ui| {
                ui.selectable_value(&mut self.mcp_yaml, false, "JSON");
                ui.selectable_value(&mut self.mcp_yaml, true, "YAML (Hermes)");
            });
            let Some(engine) = engine else { ui.label("The bundled audit engine is unavailable."); return; };
            let args = serde_json::json!(["-I","-B",engine.script,"connector"]);
            let text = if self.mcp_yaml {
                format!("mcp_servers:\n  cadi_guard:\n    command: {}\n    args: {}", serde_json::json!(engine.python), args)
            } else {
                let config = serde_json::json!({"mcpServers":{"cadi_guard":{"command":engine.python,"args":args}}});
                serde_json::to_string_pretty(&config).expect("JSON object can be serialized")
            };
            if ui.button("Copy configuration").clicked() { ctx.copy_text(text.clone()); }
            ui.add(egui::Label::new(RichText::new(text).monospace()).wrap().selectable(true));
        });
    }

    pub fn prepare_report(&mut self, explain: bool) {
        if self.use_plan {
            self.plan.prepare_report(explain)
        } else {
            self.chat.prepare_report(explain)
        }
    }
    pub fn show(
        &mut self,
        ui: &mut egui::Ui,
        ctx: &egui::Context,
        engine: Option<&Engine>,
        audit: Option<&str>,
    ) {
        self.poll();
        if self.running.is_some() {
            ctx.request_repaint_after(Duration::from_millis(200));
        }
        let scroll = egui::ScrollArea::vertical().id_salt("provider-scroller");
        scroll.show(ui, |ui| {
            let old = self.use_plan;
            ui.add_enabled_ui(self.running.is_none() && !self.plan.busy(), |ui| {
                ui.horizontal_wrapped(|ui| {
                    ui.selectable_value(&mut self.use_plan, false, "API key or local model");
                    ui.selectable_value(&mut self.use_plan, true, "ChatGPT subscription");
                });
            });
            if self.use_plan != old {
                let result = preferences::directory().and_then(|dir| {
                    preferences::update(&dir.join("chatgpt-mode.json"), |mode| {
                        *mode = self.use_plan
                    })
                });
                if let Err(reason) = result {
                    self.status = reason;
                    self.error = true;
                }
            }
            ui.add_space(8.);
            if self.use_plan {
                self.plan.show(ui, ctx, audit);
                return;
            }

            ui.add_enabled_ui(self.running.is_none(), |ui| {
                self.profile_picker(ui);
                ui.add_space(8.);
                self.profile_fields(ui, ctx);
                if self.edit.is_openai() {
                    ui.horizontal_wrapped(|ui| {
                        ui.hyperlink_to(
                            "Get an OpenAI API key",
                            "https://platform.openai.com/api-keys",
                        );
                        ui.label("API billing is separate from ChatGPT.");
                    });
                }
                ui.add_space(8.);
                ui.horizontal_wrapped(|ui| {
                    if ui.button("Save profile").clicked() {
                        let result = self.save();
                        self.error = result.is_err();
                        self.status = result.err().unwrap_or_else(|| "Profile saved.".into());
                    }
                    if ui
                        .button("Test model")
                        .on_hover_text("Send a short test prompt to this model.")
                        .clicked()
                    {
                        self.launch(ctx, Operation::Test, None);
                    }
                    if ui.small_button("Forget saved key").clicked() {
                        let result = self
                            .edit
                            .key_id()
                            .and_then(|id| provider::vault::forget(&id));
                        self.error = result.is_err();
                        self.status = result.err().unwrap_or_else(|| "Saved key removed.".into());
                        self.key.clear();
                        self.chat = Conversation::default();
                    }
                });
                ui.label(
                    RichText::new(if cfg!(target_os = "macos") {
                        "Save profile stores an entered key in macOS Keychain."
                    } else {
                        "API keys stay in memory for this session."
                    })
                    .size(14.)
                    .color(ui.visuals().weak_text_color()),
                );
            });
            if self.running.is_some() {
                ui.horizontal(|ui| {
                    ui.spinner();
                    ui.label("Contacting provider…");
                });
            }
            if !self.status.is_empty() {
                let color = if self.error {
                    ui.visuals().error_fg_color
                } else {
                    ui.visuals().hyperlink_color
                };
                ui.label(RichText::new(&self.status).color(color));
            }
            ui.add_space(10.);
            ui.separator();
            ui.add_space(6.);
            ui.push_id("provider-chat", |ui| {
                if self.chat.show(
                    ui,
                    !self.edit.model.trim().is_empty(),
                    self.running.is_some(),
                    audit.is_some(),
                ) {
                    self.launch(ctx, Operation::Ask, audit);
                }
            });
            ui.add_space(14.);
            self.mcp_export(ui, ctx, engine);
        });
    }
}
