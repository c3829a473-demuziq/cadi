#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]
mod appearance;
mod chatgpt;
mod chatgpt_ui;
mod process_view;
mod connector;
mod conversation;
mod engine;
mod hardening;
mod monitor;
mod preferences;
mod provider;
use appearance::Appearance;
use eframe::egui::{self, RichText, Stroke, Vec2};
use engine::Engine;
use std::{
    sync::{
        atomic::{AtomicBool, Ordering},
        mpsc, Arc,
    },
    thread,
    time::{Duration, Instant},
};

#[derive(Copy, Clone, PartialEq, Eq)]
enum View {
    Audit = 0,
    Plan,
    Connector,
    Harden,
    Kernel,
    Processes,
    Monitor,
}
const VIEWS: [View; 7] = [
    View::Harden,
    View::Audit,
    View::Plan,
    View::Connector,
    View::Kernel,
    View::Processes,
    View::Monitor,
];
impl View {
    fn title(self) -> &'static str {
        match self {
            Self::Audit => "Host audit",
            Self::Plan => "Hardening plan",
            Self::Connector => "Connector",
            Self::Kernel => "Kernel check",
            Self::Monitor => "Incident monitor",
            Self::Processes => "Processes",
            Self::Harden => "Harden Mac",
        }
    }
    fn explanation(self) -> &'static str {
        match self {
            Self::Monitor => "Review connection alerts and recover files from your backups.",
            Self::Processes => {
                "Compare two local process lists and review an app before asking it to quit."
            }
            Self::Kernel => {
                "Check the running system, selected published kernel fixes and available updates."
            }
            Self::Audit => "Check firewall settings, system protection and listening TCP ports.",
            Self::Plan => "Preview a change and its reversal before applying it on this device.",
            Self::Connector => "Connect a cloud provider or a local model server.",
            Self::Harden => "Apply selected protections and verify the settings on this Mac.",
        }
    }
    fn action(self) -> &'static str {
        match self {
            Self::Monitor => "Refresh incidents",
            Self::Processes => "Check running processes",
            Self::Kernel => "Run kernel check",
            Self::Audit => "Run host audit",
            Self::Plan => "Preview change",
            Self::Connector => "Save profile",
            Self::Harden => "Apply selected protections",
        }
    }
}
fn plan_controls() -> &'static [(&'static str, &'static str)] {
    if cfg!(target_os = "macos") {
        &[
            ("mac-firewall", "Application firewall"),
            ("mac-stealth", "Stealth mode"),
        ]
    } else if cfg!(windows) {
        &[
            ("windows-public-firewall", "Public firewall"),
            ("windows-smb-signing", "SMB signing"),
        ]
    } else {
        &[
            ("linux-syn-cookies", "TCP SYN protection"),
            ("linux-broadcast-echo", "Broadcast echo protection"),
            ("linux-ufw", "UFW firewall"),
        ]
    }
}
#[derive(Default)]
struct ResultPage {
    text: String,
    error: bool,
    completed: Option<Duration>,
    preview: Option<String>,
}
struct Job {
    worker: Option<thread::JoinHandle<()>>,
    view: View,
    rx: mpsc::Receiver<Result<String, String>>,
    started: Instant,
    cancel: Arc<AtomicBool>,
    plan: Option<String>,
}
struct Desktop {
    engine: Result<Engine, String>,
    view: View,
    appearance: Appearance,
    pages: [ResultPage; VIEWS.len()],
    monitor: monitor::Monitor,
    processes: process_view::ProcessView,
    report_choice: Option<(View, String)>,
    daily: bool,
    next_daily: Instant,
    connector: connector::Connector,
    protections: hardening::Protection,
    apply_on_start: bool,
    refresh_after_change: bool,
    pref_error: String,
    pending: Option<Job>,
    control: &'static str,
    copied: Option<(View, Instant)>,
}
impl Drop for Desktop {
    fn drop(&mut self) {
        if let Some(mut job) = self.pending.take() {
            job.cancel.store(true, Ordering::Relaxed);
            if let Some(worker) = job.worker.take() {
                let _ = worker.join();
            }
        }
    }
}
impl Desktop {
    fn new(ctx: &egui::Context, engine: Result<Engine, String>) -> Self {
        let appearance = preferences::directory()
            .and_then(|p| preferences::load::<Appearance>(&p.join("appearance.json")))
            .unwrap_or_default();
        appearance.apply(ctx);
        let loaded = hardening::Protection::read();
        let pref_error = loaded.as_ref().err().cloned().unwrap_or_default();
        let protections = loaded.unwrap_or_default();
        let mut s = Self {
            engine,
            view: View::Audit,
            appearance,
            pages: Default::default(),
            processes: Default::default(),
            monitor: Default::default(),
            report_choice: None,
            daily: preferences::directory()
                .and_then(|p| preferences::load::<bool>(&p.join("daily.json")))
                .unwrap_or(false),
            next_daily: Instant::now(),
            connector: Default::default(),
            protections,
            apply_on_start: cfg!(target_os = "macos") && protections.on_launch,
            refresh_after_change: false,
            pref_error,
            pending: None,
            control: plan_controls()[0].0,
            copied: None,
        };
        s.launch(ctx);
        s.view = if cfg!(target_os = "macos") {
            View::Harden
        } else {
            View::Audit
        };
        s
    }
    fn report(&self, view: View) -> Option<String> {
        if view == View::Processes {
            return self.processes.summary();
        }
        let p = &self.pages[view as usize];
        (!p.error && !p.text.is_empty()).then(|| p.text.clone())
    }
    fn launch(&mut self, ctx: &egui::Context) {
        if self.pending.is_some() {
            return;
        }
        let page = &mut self.pages[self.view as usize];
        *page = ResultPage::default();
        let args = match self.view {
            View::Audit => Ok(vec!["audit".into()]),
            View::Plan => Ok(vec!["plan".into(), self.control.into()]),
            View::Kernel => Ok(vec!["kernel".into()]),
            View::Processes => Ok(self.processes.args()),
            View::Monitor => Ok(if self.monitor.args.is_empty() {
                vec!["watch".into(), "events".into()]
            } else {
                std::mem::take(&mut self.monitor.args)
            }),
            View::Harden => self.protections.args(),
            View::Connector => return,
        };
        let (args, engine) = match args.and_then(|a| self.engine.clone().map(|e| (a, e))) {
            Ok(v) => v,
            Err(e) => {
                if self.view == View::Processes {
                    self.processes.removing = false;
                }
                page.error = true;
                page.text = e;
                return;
            }
        };
        let (tx, rx) = mpsc::channel();
        let cancel = Arc::new(AtomicBool::new(false));
        let stop = cancel.clone();
        let ctx = ctx.clone();
        let worker = thread::spawn(move || {
            let _ = tx.send(engine.run(&args, stop));
            ctx.request_repaint();
        });
        self.pending = Some(Job {
            worker: Some(worker),
            view: self.view,
            rx,
            started: Instant::now(),
            cancel,
            plan: (self.view == View::Plan).then(|| self.control.to_string()),
        });
    }
    fn poll(&mut self) {
        let Some(job) = &self.pending else {
            return;
        };
        let result = match job.rx.try_recv() {
            Ok(result) => result,
            Err(mpsc::TryRecvError::Empty) => return,
            Err(_) => Err("The diagnostic worker stopped before returning a result.".into()),
        };
        if job.view == View::Processes {
            self.processes.finish(&result);
        }
        let page = &mut self.pages[job.view as usize];
        page.error = result.is_err();
        page.text = result.unwrap_or_else(|err| err);
        page.completed = Some(job.started.elapsed());
        page.preview = job.plan.clone();
        if job.view == View::Harden {
            self.refresh_after_change = true;
            self.pref_error.clear();
        }
        self.pending = None;
    }
    fn frame(&mut self, ctx: &egui::Context) {
        self.poll();
        if self.processes.removing && ctx.input(|i| i.viewport().close_requested()) {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.view = View::Processes;
        }
        if ctx.input(|i| i.viewport().close_requested())
            && self
                .pending
                .as_ref()
                .is_some_and(|job| job.view == View::Harden)
        {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.view = View::Harden;
            self.pref_error =
                "Finish or cancel the macOS authorization request before closing.".into();
        }
        if self.pending.is_none() && (self.apply_on_start || self.refresh_after_change) {
            let old = self.view;
            self.view = if self.refresh_after_change {
                self.refresh_after_change = false;
                View::Audit
            } else {
                self.apply_on_start = false;
                View::Harden
            };
            self.launch(ctx);
            self.view = old;
        }
        if self.daily {
            ctx.request_repaint_after(
                self.next_daily
                    .saturating_duration_since(Instant::now())
                    .max(Duration::from_secs(1)),
            );
        }
        if self.pending.is_none() {
            let target = if self.processes.rescan {
                self.processes.rescan = false;
                Some(View::Processes)
            } else if self.daily && Instant::now() >= self.next_daily {
                self.next_daily = Instant::now() + Duration::from_secs(86400);
                Some(View::Kernel)
            } else {
                None
            };
            if let Some(view) = target {
                let old = self.view;
                self.view = view;
                self.launch(ctx);
                self.view = old;
            }
        }
        if self.pending.is_some() {
            ctx.request_repaint_after(Duration::from_millis(220));
        }
        let colors = self.appearance.colors();
        egui::SidePanel::left("navigation")
            .exact_width(200.)
            .resizable(false)
            .frame(egui::Frame::new().fill(colors.sidebar).inner_margin(17))
            .show(ctx, |ui| {
                ui.add_space(13.);
                ui.label(
                    RichText::new("CaDi v1")
                        .size(27.)
                        .strong()
                        .color(colors.accent),
                );
                ui.label(
                    RichText::new("Device security")
                        .size(17.)
                        .color(colors.text),
                );
                ui.add_space(if ctx.available_rect().height() < 560. {
                    8.
                } else {
                    20.
                });
                for view in VIEWS {
                    if view == View::Harden && !cfg!(target_os = "macos") {
                        continue;
                    }
                    let chosen = self.view == view;
                    let b =
                        egui::Button::new(RichText::new(view.title()).size(15.).color(if chosen {
                            colors.accent
                        } else {
                            colors.text
                        }))
                        .fill(if chosen {
                            colors.selected
                        } else {
                            colors.sidebar
                        })
                        .stroke(Stroke::NONE)
                        .corner_radius(6);
                    if ui
                        .add_sized(
                            [
                                ui.available_width(),
                                if ctx.available_rect().height() < 560. {
                                    27.
                                } else {
                                    36.
                                },
                            ],
                            b,
                        )
                        .clicked()
                    {
                        self.view = view;
                    }
                    ui.add_space(5.);
                }
                ui.with_layout(egui::Layout::bottom_up(egui::Align::Min), |ui| {
                    ui.add_space(3.);
                    ui.label(RichText::new("CaDi v1").size(14.).color(colors.secondary));
                    let before = self.appearance;
                    ui.horizontal(|ui| {
                        ui.selectable_value(&mut self.appearance, Appearance::Light, "Light");
                        ui.selectable_value(&mut self.appearance, Appearance::Dark, "Dark");
                    });
                    if before != self.appearance {
                        self.appearance.apply(ctx);
                        if let Err(e) = preferences::directory().and_then(|p| {
                            preferences::update(&p.join("appearance.json"), |mode| {
                                *mode = self.appearance
                            })
                        }) {
                            self.pref_error = e;
                        }
                    }
                });
            });
        egui::CentralPanel::default()
            .frame(egui::Frame::new().fill(colors.page).inner_margin(24))
            .show(ctx, |ui| {
                ui.label(RichText::new(self.view.title()).size(29.).strong());
                ui.add_space(3.);
                ui.label(
                    RichText::new(self.view.explanation())
                        .size(14.)
                        .color(colors.secondary),
                );
                ui.add_space(15.);
                if self.view==View::Kernel {
                    if ui.checkbox(&mut self.daily,"Check on launch and daily while CaDi is open").changed(){
                        if let Err(err)=preferences::directory().and_then(|p|preferences::update(&p.join("daily.json"),|v|*v=self.daily)){self.pref_error=err;}
                    }
                    if !self.pref_error.is_empty(){ui.colored_label(colors.error,&self.pref_error);}
                    ui.add_space(7.);
                }
                if self.view != View::Connector {
                    let report_ready=if self.view==View::Processes {self.processes.summary().is_some()}else{let page=&self.pages[self.view as usize];!page.error && !page.text.is_empty()};
                    if report_ready {
                        let mode=ui.horizontal_wrapped(|ui|{
                            if ui.button("Explain this scan").clicked(){Some(true)}
                            else if ui.button("Ask Connector").clicked(){Some(false)}else{None}
                        }).inner;
                        if let Some(explain)=mode {if let Some(report)=self.report(self.view){
                            self.report_choice=Some((self.view,report));self.connector.prepare_report(explain);self.view=View::Connector;
                        }}
                    }
                }
                if self.view==View::Processes {
                    if self.pending.is_some(){ui.horizontal(|ui|{ui.spinner();ui.label("Working…");});}
                    let p=&self.pages[self.view as usize];
                    if self.processes.show(ui,self.pending.is_none(),p.error.then_some(&p.text)){self.launch(ctx);}
                    return;
                }
                if self.view==View::Connector {
                    let current=self.report_choice.as_ref().map_or(View::Audit,|p|p.0);
                    egui::ComboBox::from_label("Report for this question").selected_text(current.title()).show_ui(ui,|ui|{
                        for view in [View::Audit,View::Kernel,View::Processes,View::Plan,View::Harden,View::Monitor]{
                            if let Some(report)=self.report(view){if ui.selectable_label(view==current,view.title()).clicked(){self.report_choice=Some((view,report));}}
                        }
                    });
                    let fallback=&self.pages[View::Audit as usize];
                    let data=self.report_choice.as_ref().map(|p|p.1.as_str()).or_else(||(!fallback.error && !fallback.text.is_empty()).then_some(fallback.text.as_str()));
                    if let Some(report)=data {ui.collapsing("Preview report to share",|ui|{
                        egui::ScrollArea::vertical().max_height(85.).id_salt("report-preview").show(ui,|ui|{ui.add(egui::Label::new(report).wrap().selectable(true));});
                    });}
                    self.connector.show(ui,ctx,self.engine.as_ref().ok(),data);return;
                }
                if self.view==View::Monitor {
                    egui::ScrollArea::vertical().id_salt("monitor-panel").show(ui,|ui|{
                        if self.monitor.show(ui,self.pending.is_none()){self.launch(ctx);}
                        if self.pending.is_some(){ui.spinner();}
                        let result=&self.pages[View::Monitor as usize];
                        if result.text.is_empty(){ui.label("Choose Refresh incidents to read the local log.");}else{
                            ui.separator();ui.add(egui::Label::new(&result.text).wrap().selectable(true));
                            if ui.small_button("Copy result").clicked(){ctx.copy_text(result.text.clone());}
                        }
                    });return;
                }
                if self.view==View::Harden {
                    let report=&self.pages[View::Audit as usize].text;
                    let unknown = if self.pending.as_ref().is_some_and(|job| job.view == View::Audit) {"Checking…"} else {"Unknown"};
                    let observed=|key:&str|report.lines().find(|s|s.contains(&format!("({key})"))).map(|l|if l.starts_with("[OK]"){"Enabled"}else if l.starts_with("[REVIEW]"){"Review"}else{"Unknown"}).unwrap_or(unknown);
                    let mut changed=false;
                    ui.add_enabled_ui(self.pending.is_none(),|ui|{
                        ui.horizontal(|ui|{changed |= ui.checkbox(&mut self.protections.firewall,"Application firewall").changed();ui.label(RichText::new(observed("mac-firewall")).color(colors.secondary));});
                        ui.horizontal(|ui|{changed |= ui.checkbox(&mut self.protections.stealth,"Firewall stealth mode").changed();ui.label(RichText::new(observed("mac-stealth")).color(colors.secondary));});
                        ui.add_space(6.);
                        ui.label("Enabling the firewall can affect incoming connections. Stealth mode can suppress ping replies.");
                        ui.add_space(5.);
                        let selected=self.protections.firewall || self.protections.stealth;
                        if !selected{self.protections.on_launch=false;}
                        changed |= ui.add_enabled(selected,egui::Checkbox::new(&mut self.protections.on_launch,"Apply these settings when CaDi opens")).changed();
                        if changed{self.pref_error=self.protections.save().err().unwrap_or_default();}
                        if !self.pref_error.is_empty(){ui.colored_label(colors.error,&self.pref_error);}
                        ui.label(RichText::new("macOS asks for administrator approval when a setting needs to change.").size(14.).color(colors.secondary));
                    });ui.add_space(10.);
                }
                let mut settings_changed = false;
                if self.view == View::Plan {
                    ui.add_enabled_ui(self.pending.is_none(), |ui| {
                        ui.horizontal(|ui| {
                            for (id,title) in plan_controls(){settings_changed |= ui.selectable_value(&mut self.control,*id,*title).changed();}
                        });
                    });
                    ui.add_space(10.);
                }
                if settings_changed { self.pages[self.view as usize]=ResultPage::default(); }
                ui.horizontal_wrapped(|ui| {
                    let action=egui::Button::new(RichText::new(self.view.action()).strong().color(colors.page))
                        .fill(colors.accent).min_size(Vec2::new(0.,34.));
                    let enabled=self.pending.is_none() && (self.view!=View::Harden || self.protections.firewall || self.protections.stealth);
                    if ui.add_enabled(enabled, action).clicked(){self.launch(ctx);}
                    if let Some(job)=&self.pending {ui.spinner();ui.label(format!("{} running · {}s",job.view.title(),job.started.elapsed().as_secs()));}
                    else {let page=&self.pages[self.view as usize];if page.error{ui.colored_label(colors.error,"Needs attention");}else if let Some(time)=page.completed{ui.label(format!("Completed in {:.1}s",time.as_secs_f32()));}}
                });
                ui.add_space(14.);
                let page=&self.pages[self.view as usize];
                ui.horizontal_wrapped(|ui|{
                    ui.heading("Results");
                    if !page.text.is_empty() && ui.small_button("Copy text").clicked(){ctx.copy_text(page.text.clone());self.copied=Some((self.view,Instant::now()));}
                    if self.copied.is_some_and(|(v,t)|v==self.view && t.elapsed()<Duration::from_secs(2)){ui.label("Copied");ctx.request_repaint_after(Duration::from_secs(2));}
                });
                if self.view==View::Plan && !page.error && page.preview.as_deref()==Some(self.control) {
                    if let Ok(engine)=&self.engine {
                        ui.horizontal_wrapped(|ui|{
                            if ui.small_button("Copy apply command").clicked(){ctx.copy_text(engine.command_text(&["apply",self.control]));self.copied=Some((View::Plan,Instant::now()));}
                            ui.label("Run in your terminal to review and confirm.");
                        });
                    }
                }
                let busy = self
                    .pending
                    .as_ref()
                    .is_some_and(|job| job.view == self.view);
                egui::Frame::new()
                    .fill(colors.card)
                    .stroke(Stroke::new(1., colors.border))
                    .corner_radius(8)
                    .inner_margin(14)
                    .show(ui, |ui| {
                        ui.set_min_height((ui.available_height() - 2.).max(40.));
                        ui.set_min_width(ui.available_width());
                        egui::ScrollArea::vertical()
                            .id_salt(("report", self.view as usize))
                            .auto_shrink([false, false])
                            .show(ui, |ui| {
                                if page.text.is_empty() {
                                    ui.label(
                                        RichText::new(if busy {
                                            "Collecting results…"
                                        } else {
                                            "Run the check to see its output here."
                                        })
                                        .color(colors.secondary),
                                    );
                                } else {
                                    for line in page.text.lines() {
                                        let color = if page.error || line.starts_with("[REVIEW]") {
                                            colors.warning
                                        } else if line.starts_with("[OK]") {
                                            colors.accent
                                        } else if line.starts_with("[UNKNOWN]") {
                                            colors.unknown
                                        } else {
                                            colors.text
                                        };
                                        ui.add(
                                            egui::Label::new(
                                                RichText::new(if line.is_empty() {
                                                    " "
                                                } else {
                                                    line
                                                })
                                                .monospace()
                                                .size(15.)
                                                .color(color),
                                            )
                                            .wrap()
                                            .selectable(true),
                                        );
                                    }
                                }
                            });
                    });
            });
    }
}
impl eframe::App for Desktop {
    fn update(&mut self, ctx: &egui::Context, _: &mut eframe::Frame) {
        self.frame(ctx);
    }
}
fn main() -> eframe::Result {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_icon(
                eframe::icon_data::from_png_bytes(include_bytes!("AppIcon.png"))
                    .expect("valid embedded CaDi icon"),
            )
            .with_inner_size([940., 640.])
            .with_min_inner_size([720., 480.]),
        ..Default::default()
    };
    eframe::run_native(
        "CaDi v1",
        options,
        Box::new(|cc| Ok(Box::new(Desktop::new(&cc.egui_ctx, engine::discover())))),
    )
}

#[cfg(test)]
mod gui_tests {
    use super::*;
    #[test]
    fn all_views_create_visible_controls_and_preserve_the_active_result() {
        let ctx = egui::Context::default();
        let mut ui = Desktop::new(&ctx, Err("Bundled engine missing".into()));
        assert!(ui.pages[0].error);
        for view in VIEWS {
            ui.view = view;
            let input = egui::RawInput {
                screen_rect: Some(egui::Rect::from_min_size(
                    egui::Pos2::ZERO,
                    egui::vec2(940., 640.),
                )),
                ..Default::default()
            };
            let frame = ctx.run(input, |ctx| ui.frame(ctx));
            let mut texts = Vec::new();
            for shape in &frame.shapes {
                if let egui::Shape::Text(text) = &shape.shape {
                    texts.push(text.galley.job.text.as_str());
                }
            }
            assert!(
                texts.contains(&view.action()),
                "Missing action {}",
                view.action()
            );
            assert!(texts.contains(&view.title()));
        }
        assert_eq!(ui.pages[0].text, "Bundled engine missing");
    }
    #[test]
    fn completed_work_is_delivered_to_its_own_view() {
        let ctx = egui::Context::default();
        let mut ui = Desktop::new(&ctx, Err("missing".into()));
        let (tx, rx) = mpsc::channel();
        ui.pending = Some(Job {
            worker: None,
            view: View::Plan,
            rx,
            started: Instant::now(),
            cancel: Arc::new(AtomicBool::new(false)),
            plan: Some("mac-firewall".into()),
        });
        ui.view = View::Monitor;
        tx.send(Ok("preview output".to_owned())).unwrap();
        ui.poll();
        assert!(ui.pending.is_none());
        assert_eq!(ui.pages[View::Plan as usize].text, "preview output");
        assert_eq!(
            ui.pages[View::Plan as usize].preview.as_deref(),
            Some("mac-firewall")
        );
        assert!(ui.pages[View::Monitor as usize].text.is_empty());
    }
}
