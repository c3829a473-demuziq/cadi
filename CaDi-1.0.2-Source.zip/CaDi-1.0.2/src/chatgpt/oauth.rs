use super::{JwtIdentity, ISSUER, RESOURCE};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD as B64, Engine};
use rsa::{
    pkcs1v15::{Signature, VerifyingKey},
    signature::Verifier,
    BigUint, RsaPublicKey,
};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    io::{BufRead, BufReader, Read, Write},
    net::{TcpListener, TcpStream},
    sync::atomic::{AtomicBool, Ordering},
    thread,
    time::{Duration, Instant},
};
use url::Url;

const INVALID: &str = "Could not verify the ChatGPT account identity. Start a new sign-in.";
pub(super) const DYNAMIC: &str = "dynamic_agent_client";
pub(super) const SCOPES: &str =
    "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct";

fn random<const N: usize>() -> Result<[u8; N], String> {
    let mut bytes = [0; N];
    getrandom::fill(&mut bytes).map_err(|_| "Could not create a secure sign-in request.")?;
    Ok(bytes)
}
pub(super) fn host_id() -> Result<String, String> {
    let mut b = random::<16>()?;
    b[6] = (b[6] & 15) | 64;
    b[8] = (b[8] & 63) | 128;
    let id: String = b.iter().map(|v| format!("{v:02x}")).collect();
    Ok(format!(
        "urn:uuid:{}-{}-{}-{}-{}",
        &id[..8],
        &id[8..12],
        &id[12..16],
        &id[16..20],
        &id[20..]
    ))
}

pub(super) struct Attempt {
    pub verifier: String,
    pub nonce: String,
    pub state: String,
    pub redirect: String,
}
impl Attempt {
    pub fn new(port: u16) -> Result<Self, String> {
        Ok(Self {
            verifier: B64.encode(random::<32>()?),
            nonce: B64.encode(random::<32>()?),
            state: B64.encode(random::<32>()?),
            redirect: format!("http://127.0.0.1:{port}/auth/callback"),
        })
    }
    pub fn authorize(&self, host: &str, issued: Option<&str>, reconsent: bool) -> Url {
        let mut url = Url::parse("https://auth.openai.com/api/accounts/authorize").unwrap();
        let mut params = url.query_pairs_mut();
        params.extend_pairs([
            ("client_id", issued.unwrap_or(DYNAMIC)),
            ("ext_agent_host_id", host),
            ("response_type", "code"),
            ("redirect_uri", &self.redirect),
            ("resource", RESOURCE),
            ("scope", SCOPES),
            ("state", &self.state),
            ("nonce", &self.nonce),
            ("code_challenge_method", "S256"),
            (
                "code_challenge",
                &B64.encode(Sha256::digest(self.verifier.as_bytes())),
            ),
        ]);
        if issued.is_none() {
            params.append_pair("agent_name_hint", "CaDi v1");
        }
        if reconsent {
            params.append_pair("prompt", "consent");
        }
        drop(params);
        url
    }
}

fn callback(
    stream: &mut TcpStream,
    attempt: &Attempt,
    known: Option<&str>,
) -> Option<Result<(String, String), String>> {
    stream.set_read_timeout(Some(Duration::from_secs(2))).ok()?;
    stream
        .set_write_timeout(Some(Duration::from_secs(2)))
        .ok()?;
    let expected = Url::parse(&attempt.redirect).ok()?;
    let mut input = BufReader::new(stream.take(16384));
    let mut first = String::new();
    input.read_line(&mut first).ok()?;
    let mut request = first.split_whitespace();
    if request.next() != Some("GET") {
        return None;
    }
    let target = request.next()?;
    if !target.starts_with("/auth/callback?") {
        return None;
    }
    let url = expected.join(target).ok()?;
    let mut host_ok = false;
    loop {
        let mut line = String::new();
        if input.read_line(&mut line).ok()? == 0 {
            return None;
        }
        if line == "\r\n" || line == "\n" {
            break;
        }
        if let Some((h, v)) = line.split_once(':') {
            if h.eq_ignore_ascii_case("host") {
                host_ok = v.trim() == format!("127.0.0.1:{}", expected.port()?);
            }
        }
    }
    if !host_ok {
        return None;
    }
    let mut fields = std::collections::HashMap::new();
    for (k, v) in url.query_pairs() {
        if fields.insert(k, v).is_some() {
            return None;
        }
    }
    if fields.get("state")?.as_ref() != attempt.state {
        return None;
    }
    if fields.contains_key("error") {
        return Some(Err(
            "Sign-in was declined or stopped in your browser.".into()
        ));
    }
    let code = fields.get("code").map(|v| v.as_ref()).unwrap_or("");
    let issued = fields
        .get("client_id")
        .map(|v| v.as_ref())
        .or(known)
        .unwrap_or("");
    if code.is_empty()
        || issued.is_empty()
        || issued == DYNAMIC
        || known.is_some_and(|id| id != issued)
    {
        return Some(Err(
            "The sign-in response did not match the selected registration. Try again.".into(),
        ));
    }
    Some(Ok((code.to_owned(), issued.to_owned())))
}

pub(super) fn wait(
    listener: TcpListener,
    attempt: &Attempt,
    known: Option<&str>,
    cancel: &AtomicBool,
) -> Result<(String, String), String> {
    listener
        .set_nonblocking(true)
        .map_err(|_| "Could not start the local sign-in listener.")?;
    let deadline = Instant::now() + Duration::from_secs(300);
    while Instant::now() < deadline && !cancel.load(Ordering::Relaxed) {
        match listener.accept() {
            Ok((mut stream, _)) => {
                let result = callback(&mut stream, attempt, known);
                let (status, message) = if result.is_some() {
                    ("200 OK", "Return to CaDi v1 to see your sign-in result.")
                } else {
                    (
                        "400 Bad Request",
                        "This request does not match a CaDi sign-in.",
                    )
                };
                let _=write!(stream,"HTTP/1.1 {status}\r\nContent-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nConnection: close\r\nContent-Length: {}\r\n\r\n{message}",message.len());
                if let Some(result) = result {
                    return result;
                }
            }
            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                thread::sleep(Duration::from_millis(75))
            }
            Err(_) => {
                return Err("The local sign-in listener stopped. Try signing in again.".into())
            }
        }
    }
    Err("Sign-in was cancelled or timed out. You can start it again.".into())
}

pub(super) fn identity(
    jwt: &str,
    jwks: &Value,
    client: &str,
    nonce: &str,
    now: u64,
) -> Result<JwtIdentity, String> {
    let mut parts = jwt.split('.');
    let (Some(head), Some(body), Some(sig), None) =
        (parts.next(), parts.next(), parts.next(), parts.next())
    else {
        return Err(INVALID.into());
    };
    let decode = |part: &str| -> Result<Value, String> {
        serde_json::from_slice(&B64.decode(part).map_err(|_| INVALID)?)
            .map_err(|_| INVALID.to_owned())
    };
    let header = decode(head)?;
    let kid = header["kid"].as_str().ok_or(INVALID)?;
    if header["alg"] != "RS256" || kid.is_empty() {
        return Err(INVALID.into());
    }
    let jwk = jwks["keys"]
        .as_array()
        .ok_or(INVALID)?
        .iter()
        .find(|k| {
            k["kid"] == kid
                && k["kty"] == "RSA"
                && (k["use"].is_null() || k["use"] == "sig")
                && (k["alg"].is_null() || k["alg"] == "RS256")
        })
        .ok_or(INVALID)?;
    let number = |name: &str| -> Result<BigUint, String> {
        Ok(BigUint::from_bytes_be(
            &B64.decode(jwk[name].as_str().ok_or(INVALID)?)
                .map_err(|_| INVALID)?,
        ))
    };
    let n = number("n")?;
    if !(2048..=8192).contains(&n.bits()) {
        return Err(INVALID.into());
    }
    let key = VerifyingKey::<Sha256>::new(RsaPublicKey::new(n, number("e")?).map_err(|_| INVALID)?);
    let signature = Signature::try_from(B64.decode(sig).map_err(|_| INVALID)?.as_slice())
        .map_err(|_| INVALID)?;
    key.verify(format!("{head}.{body}").as_bytes(), &signature)
        .map_err(|_| INVALID)?;
    let c = decode(body)?;
    let aud_ok = c["aud"] == client
        || c["aud"]
            .as_array()
            .is_some_and(|a| a.iter().any(|v| v == client) && (a.len() == 1 || c["azp"] == client));
    if !aud_ok
        || (!c["azp"].is_null() && c["azp"] != client)
        || c["iss"] != ISSUER
        || c["nonce"] != nonce
        || c["exp"].as_u64().unwrap_or(0) <= now
        || c["nbf"].as_u64().unwrap_or(0) > now + 60
        || c["iat"].as_u64().unwrap_or(0) > now + 60
    {
        return Err(INVALID.into());
    }
    let sub = c["sub"].as_str().filter(|s| !s.is_empty()).ok_or(INVALID)?;
    Ok(JwtIdentity {
        subject: sub.into(),
        label: c["email"]
            .as_str()
            .filter(|_| c["email_verified"] != false)
            .unwrap_or("ChatGPT account")
            .into(),
    })
}
