use super::*;
use base64::{engine::general_purpose::URL_SAFE_NO_PAD as B64, Engine};
use rsa::{
    pkcs1v15::SigningKey,
    signature::{SignatureEncoding, Signer},
    traits::PublicKeyParts,
    RsaPrivateKey,
};
use sha2::{Digest, Sha256};
use std::{
    collections::HashMap,
    io::{BufRead, BufReader, Write},
    sync::{Mutex, OnceLock},
    thread,
};
use url::Url;

fn signing_key() -> &'static RsaPrivateKey {
    static KEY: OnceLock<RsaPrivateKey> = OnceLock::new();
    KEY.get_or_init(|| RsaPrivateKey::new(&mut rsa::rand_core::OsRng, 2048).unwrap())
}
fn jwks() -> Value {
    let key = signing_key().to_public_key();
    json!({"keys":[{"kid":"fixture","alg":"RS256","kty":"RSA","use":"sig","n":B64.encode(key.n().to_bytes_be()),"e":B64.encode(key.e().to_bytes_be())}]})
}
fn signed(claims: Value) -> String {
    let data = format!(
        "{}.{}",
        B64.encode(br#"{"kid":"fixture","alg":"RS256"}"#),
        B64.encode(claims.to_string())
    );
    let sig = SigningKey::<Sha256>::new(signing_key().clone()).sign(data.as_bytes());
    format!("{data}.{}", B64.encode(sig.to_bytes()))
}
fn claims(nonce: &str) -> Value {
    json!({"iss":ISSUER,"sub":"test-subject","aud":"oaiapp_fixture","nonce":nonce,"exp":now()+3600,"iat":now(),"email":"test@example.invalid"})
}
#[test]
fn identity_checks_signature_issuer_audience_nonce_and_expiry() {
    let key = jwks();
    let token = signed(claims("nonce"));
    let check = |jwt: &str, client: &str, nonce: &str| {
        oauth::identity(jwt, &key, client, nonce, now()).is_ok()
    };
    assert!(check(&token, "oaiapp_fixture", "nonce"));
    assert!(!check(&token, "other", "nonce"));
    assert!(!check(&token, "oaiapp_fixture", "wrong"));
    let mut tampered = token.into_bytes();
    let i = tampered.iter().rposition(|x| *x == b'.').unwrap() + 1;
    tampered[i] = if tampered[i] == b'A' { b'B' } else { b'A' };
    assert!(!check(
        std::str::from_utf8(&tampered).unwrap(),
        "oaiapp_fixture",
        "nonce"
    ));
    for (field, value) in [
        ("iss", json!("https://irrelevant.invalid")),
        ("exp", json!(now() - 10)),
        ("sub", json!("")),
        ("azp", json!("other")),
    ] {
        let mut c = claims("nonce");
        c[field] = value;
        assert!(!check(&signed(c), "oaiapp_fixture", "nonce"));
    }
}
#[test]
fn subscription_needs_a_terminal_success_even_after_receiving_text() {
    let delta = "data: {\"type\":\"response.output_text.delta\",\"delta\":\"hello\"}\n\n";
    assert!(stream_text(delta).is_err());
    let failure="data: {\"type\":\"response.failed\",\"response\":{\"error\":{\"code\":\"subscription_sharing_usage_limit_exceeded\"}}}\n\n";
    assert!(stream_text(&format!("{delta}{failure}"))
        .unwrap_err()
        .contains("plan usage limit"));
    let incomplete = "data: {\"type\":\"response.incomplete\"}\n\n";
    assert!(stream_text(&format!("{delta}{incomplete}")).is_err());
}
#[test]
fn local_browser_sign_in_catalog_reply_refresh_and_sign_out() {
    let dir = tempfile::tempdir().unwrap();
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let base = format!("http://{}", listener.local_addr().unwrap());
    let client = Client {
        file: dir.path().join("accounts.json"),
        http: ureq::agent(),
        issuer: base.clone(),
        api: format!("{base}/v1"),
    };
    let authorization = Arc::new(Mutex::new(HashMap::<String, String>::new()));
    let server_state = authorization.clone();
    let server = thread::spawn(move || {
        for step in 0..7 {
            let (mut connection, _) = listener.accept().unwrap();
            connection
                .set_read_timeout(Some(Duration::from_secs(8)))
                .unwrap();
            let mut request = BufReader::new(connection.try_clone().unwrap());
            let mut path = String::new();
            request.read_line(&mut path).unwrap();
            let mut length = 0;
            let mut bearer = String::new();
            loop {
                let mut line = String::new();
                request.read_line(&mut line).unwrap();
                if line == "\r\n" {
                    break;
                }
                if let Some((k, v)) = line.split_once(':') {
                    match k.to_lowercase().as_str() {
                        "content-length" => length = v.trim().parse().unwrap(),
                        "authorization" => bearer = v.trim().to_owned(),
                        _ => {}
                    }
                }
            }
            let mut body = vec![0; length];
            request.read_exact(&mut body).unwrap();
            let form: HashMap<_, _> = url::form_urlencoded::parse(&body).into_owned().collect();
            let reply = match step {
                0 => {
                    assert!(path.starts_with("POST /api/accounts/oauth/token "));
                    let a = server_state.lock().unwrap();
                    assert_eq!(form["client_id"], "oaiapp_fixture");
                    assert_eq!(form["redirect_uri"], a["redirect_uri"]);
                    assert_eq!(form["resource"], RESOURCE);
                    assert_eq!(
                        B64.encode(Sha256::digest(form["code_verifier"].as_bytes())),
                        a["code_challenge"]
                    );
                    json!({"token_type":"Bearer","access_token":"fixture-access","refresh_token":"fixture-renew","scope":oauth::SCOPES,"expires_in":3600,"id_token":signed(claims(&a["nonce"]))}).to_string()
                }
                1 => {
                    assert!(path.starts_with("GET /.well-known/jwks.json "));
                    jwks().to_string()
                }
                2 => {
                    assert_eq!(bearer, "Bearer fixture-access");
                    assert!(path.starts_with("GET /v1/models "));
                    json!({"models":[{"slug":"visible","display_name":"Visible model","visibility":"list"},{"slug":"hidden","visibility":"hidden"}]}).to_string()
                }
                3 | 4 => {
                    assert_eq!(bearer, "Bearer fixture-access");
                    assert!(path.starts_with("POST /v1/responses "));
                    let b: Value = serde_json::from_slice(&body).unwrap();
                    assert_eq!(b["store"], false);
                    assert_eq!(b["stream"], true);
                    assert_eq!(b["input"][0]["content"], "what is a firewall?");
                    if step == 4 {
                        assert_eq!(b["input"][1]["role"], "assistant");
                        assert_eq!(b["input"][1]["content"], "sample reply");
                        assert_eq!(b["input"][2]["role"], "user");
                        assert_eq!(b["input"][2]["content"], "explain that");
                    }
                    assert!(b["tools"].is_null());
                    "data: {\"type\":\"response.output_text.delta\",\"delta\":\"sample reply\"}\n\ndata: {\"type\":\"response.completed\"}\n\n".into()
                }
                5 => {
                    assert_eq!(form["grant_type"], "refresh_token");
                    assert_eq!(form["refresh_token"], "fixture-renew");
                    json!({"token_type":"Bearer","access_token":"renewed-access","refresh_token":"rotated-renew","expires_in":3600}).to_string()
                }
                _ => {
                    assert!(path.starts_with("POST /api/accounts/oauth/revoke "));
                    assert_eq!(form["token"], "rotated-renew");
                    String::new()
                }
            };
            write!(
                connection,
                "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{reply}",
                reply.len()
            )
            .unwrap();
        }
    });
    let login = client
        .login(None, &AtomicBool::new(false), |url| {
            assert_eq!(url.host_str(), Some("auth.openai.com"));
            let fields: HashMap<_, _> = url.query_pairs().into_owned().collect();
            assert_eq!(fields["client_id"], "dynamic_agent_client");
            assert_eq!(fields["agent_name_hint"], "CaDi v1");
            assert!(fields["ext_agent_host_id"].starts_with("urn:uuid:"));
            assert_eq!(fields["code_challenge_method"], "S256");
            let mut callback = Url::parse(&fields["redirect_uri"]).unwrap();
            callback
                .query_pairs_mut()
                .append_pair("state", &fields["state"])
                .append_pair("client_id", "oaiapp_fixture")
                .append_pair("code", "test-code");
            *authorization.lock().unwrap() = fields;
            thread::spawn(move || {
                let mut bad = callback.clone();
                bad.set_query(Some("state=wrong&code=unrelated"));
                assert!(ureq::get(bad.as_str()).call().is_err());
                assert_eq!(ureq::get(callback.as_str()).call().unwrap().status(), 200);
            });
            Ok(())
        })
        .unwrap();
    assert_eq!(login, "oaiapp_fixture");
    let models = client.models(&login).unwrap();
    assert_eq!(models.len(), 1);
    assert_eq!(models[0].name, "Visible model");
    assert_eq!(
        client
            .ask(
                &login,
                &models[0].slug,
                &[crate::conversation::Message::user("what is a firewall?")]
            )
            .unwrap(),
        "sample reply"
    );
    let follow_up = [
        crate::conversation::Message::user("what is a firewall?"),
        crate::conversation::Message {
            role: "assistant",
            content: "sample reply".into(),
        },
        crate::conversation::Message::user("explain that"),
    ];
    assert_eq!(
        client.ask(&login, &models[0].slug, &follow_up).unwrap(),
        "sample reply"
    );
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        assert_eq!(
            std::fs::metadata(&client.file)
                .unwrap()
                .permissions()
                .mode()
                & 0o777,
            0o600
        );
    }
    preferences::transact(&client.file, |a: &mut Accounts| {
        a.items[0].session.as_mut().unwrap().expires = 0;
        Ok(())
    })
    .unwrap();
    assert_eq!(client.token(&login).unwrap(), "renewed-access");
    client.logout(&login).unwrap();
    let accounts: Accounts = preferences::load(&client.file).unwrap();
    assert!(accounts.items[0].session.is_none());
    assert_eq!(accounts.active.as_deref(), Some(login.as_str()));
    server.join().unwrap();
}
