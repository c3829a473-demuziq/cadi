mod oauth;
#[cfg(test)]
mod tests;
use crate::preferences;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{
    io::Read,
    net::TcpListener,
    path::PathBuf,
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc,
    },
    time::{Duration, SystemTime, UNIX_EPOCH},
};

const ISSUER: &str = "https://auth.openai.com";
const RESOURCE: &str = "https://api.openai.com/v1";
const PLAN_SCOPE: &str = "chatgpt.tokens.use.direct";
const RESPONSE_CAP: u64 = 4 * 1024 * 1024;

struct JwtIdentity {
    subject: String,
    label: String,
}
#[derive(Default, Serialize, Deserialize)]
struct Accounts {
    host: String,
    active: Option<String>,
    items: Vec<Account>,
}
#[derive(Serialize, Deserialize)]
struct Account {
    id: String,
    subject: String,
    label: String,
    session: Option<Session>,
}
#[derive(Serialize, Deserialize)]
struct Session {
    access: String,
    refresh: String,
    scopes: String,
    expires: u64,
}
impl Session {
    fn enabled(&self) -> bool {
        self.scopes.split_whitespace().any(|s| s == PLAN_SCOPE)
    }
    fn issue(v: &Value, previous: Option<&Self>) -> Result<Self, String> {
        let bad = "The authorization server returned an incomplete session. Sign in again.";
        if !v["token_type"]
            .as_str()
            .is_some_and(|t| t.eq_ignore_ascii_case("bearer"))
        {
            return Err(bad.into());
        }
        let access = v["access_token"]
            .as_str()
            .filter(|s| !s.is_empty())
            .ok_or(bad)?;
        let ttl = v["expires_in"]
            .as_u64()
            .filter(|n| *n > 0 && *n < 86400 * 365)
            .ok_or(bad)?;
        Ok(Self {
            access: access.into(),
            refresh: v["refresh_token"]
                .as_str()
                .or_else(|| previous.map(|p| p.refresh.as_str()))
                .unwrap_or("")
                .into(),
            scopes: v["scope"]
                .as_str()
                .or_else(|| previous.map(|p| p.scopes.as_str()))
                .unwrap_or("")
                .into(),
            expires: now() + ttl,
        })
    }
}
fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}
fn path() -> Result<PathBuf, String> {
    Ok(preferences::directory()?.join("chatgpt-accounts.json"))
}
type ResultText<T> = Result<T, String>;
#[derive(Clone, Default)]
pub struct Choice {
    pub id: String,
    pub label: String,
    pub signed_in: bool,
    pub enabled: bool,
}
#[derive(Default)]
pub struct Saved {
    pub active: Option<String>,
    pub choices: Vec<Choice>,
}
pub fn saved() -> ResultText<Saved> {
    let a: Accounts = preferences::load(&path()?)?;
    Ok(Saved {
        active: a.active,
        choices: a
            .items
            .into_iter()
            .map(|x| {
                let suffix =
                    x.id.chars()
                        .rev()
                        .take(6)
                        .collect::<String>()
                        .chars()
                        .rev()
                        .collect::<String>();
                Choice {
                    id: x.id,
                    label: format!("{} · {suffix}", x.label),
                    signed_in: x.session.is_some(),
                    enabled: x.session.as_ref().is_some_and(Session::enabled),
                }
            })
            .collect(),
    })
}
pub fn select(id: &str) -> ResultText<()> {
    preferences::transact(&path()?, |a: &mut Accounts| {
        if !a.items.iter().any(|x| x.id == id) {
            return Err("That ChatGPT account is unavailable.".into());
        }
        a.active = Some(id.into());
        Ok(())
    })
}
fn agent() -> ResultText<ureq::Agent> {
    let tls =
        native_tls::TlsConnector::new().map_err(|_| "Could not start a secure connection.")?;
    Ok(ureq::AgentBuilder::new()
        .redirects(0)
        .tls_connector(Arc::new(tls))
        .timeout(Duration::from_secs(120))
        .timeout_connect(Duration::from_secs(12))
        .build())
}
fn read_bytes(reader: impl Read, max: u64) -> ResultText<Vec<u8>> {
    let mut bytes = vec![];
    reader
        .take(max + 1)
        .read_to_end(&mut bytes)
        .map_err(|_| "The connection ended before the reply arrived.")?;
    if bytes.len() as u64 > max {
        return Err("The provider reply exceeded the size limit.".into());
    }
    Ok(bytes)
}
fn known_error(code: &str, status: u16) -> String {
    let hint = match code {
        "subscription_sharing_usage_limit_exceeded" => {
            "You reached the plan usage limit. Check Manage usage in ChatGPT."
        }
        "subscription_sharing_usage_unavailable" | "subscription_sharing_user_unavailable" => {
            "ChatGPT plan usage is temporarily unavailable. Try again later."
        }
        "insufficient_scope"
        | "chatpass_v2_scope_not_authorized"
        | "chatpass_v2_invalid_authorization_context" => {
            "Sign in again and allow CaDi to use your ChatGPT plan."
        }
        "model_not_found" | "unsupported_model" => {
            "Refresh the models for this account and select another text model."
        }
        _ => match status {
            401 => "Sign in to ChatGPT again.",
            403 => "Check whether this account or workspace allows CaDi to use its plan.",
            429 => "Check your plan limits in Manage usage before retrying.",
            _ => "Try again or check your connection to OpenAI.",
        },
    };
    format!("ChatGPT request failed (HTTP {status}). {hint}")
}
fn error_code(v: &Value) -> &str {
    v.pointer("/error/code")
        .or_else(|| v.pointer("/error/type"))
        .or_else(|| v.get("code"))
        .or_else(|| v.get("error"))
        .and_then(Value::as_str)
        .unwrap_or("")
}
fn success(result: Result<ureq::Response, ureq::Error>) -> ResultText<ureq::Response> {
    match result {
        Ok(r) if (200..300).contains(&r.status()) => Ok(r),
        Ok(_) => Err("The server returned an unexpected redirect.".into()),
        Err(ureq::Error::Status(status, r)) => {
            let v: Value =
                serde_json::from_reader(r.into_reader().take(16384)).unwrap_or(Value::Null);
            Err(known_error(error_code(&v), status))
        }
        Err(_) => {
            Err("Could not reach OpenAI. Check the internet connection and try again.".into())
        }
    }
}
fn json_body(result: Result<ureq::Response, ureq::Error>) -> ResultText<Value> {
    serde_json::from_slice(&read_bytes(success(result)?.into_reader(), RESPONSE_CAP)?)
        .map_err(|_| "OpenAI returned an unreadable reply.".into())
}

struct Client {
    file: PathBuf,
    http: ureq::Agent,
    issuer: String,
    api: String,
}
impl Client {
    fn open() -> ResultText<Self> {
        Ok(Self {
            file: path()?,
            http: agent()?,
            issuer: ISSUER.into(),
            api: RESOURCE.into(),
        })
    }
    fn auth_endpoint(&self, name: &str) -> String {
        format!("{}/api/accounts/oauth/{name}", self.issuer)
    }
}
pub fn login(known: Option<&str>, cancel: &AtomicBool) -> ResultText<String> {
    Client::open()?.login(known, cancel, |url| {
        webbrowser::open(url.as_str())
            .map_err(|_| "Could not open your default browser for ChatGPT sign-in.".into())
    })
}
pub fn logout(id: &str) -> ResultText<String> {
    Client::open()?.logout(id)
}
pub fn models(id: &str) -> ResultText<Vec<Model>> {
    Client::open()?.models(id)
}
pub fn ask(id: &str, model: &str, messages: &[crate::conversation::Message]) -> ResultText<String> {
    Client::open()?.ask(id, model, messages)
}
impl Client {
    fn login(
        &self,
        known: Option<&str>,
        cancel: &AtomicBool,
        open: impl FnOnce(&url::Url) -> ResultText<()>,
    ) -> ResultText<String> {
        let file = &self.file;
        let (host, subject, reconsent) = preferences::transact(file, |a: &mut Accounts| {
            if a.host.is_empty() {
                a.host = oauth::host_id()?;
            }
            let previous = match known {
                Some(id) => Some(
                    a.items
                        .iter()
                        .find(|x| x.id == id)
                        .ok_or("That account is no longer saved.")?,
                ),
                None => None,
            };
            Ok((
                a.host.clone(),
                previous.map(|x| x.subject.clone()),
                previous
                    .and_then(|x| x.session.as_ref())
                    .is_some_and(|s| !s.enabled()),
            ))
        })?;
        let listener = TcpListener::bind(("127.0.0.1", 0))
            .map_err(|_| "Could not open the local sign-in callback on this computer.")?;
        let attempt = oauth::Attempt::new(
            listener
                .local_addr()
                .map_err(|_| "Local sign-in address unavailable.")?
                .port(),
        )?;
        let url = attempt.authorize(&host, known, reconsent);
        open(&url)?;
        let (code, id) = oauth::wait(listener, &attempt, known, cancel)?;
        let http = &self.http;
        let tokens = json_body(http.post(&self.auth_endpoint("token")).send_form(&[
            ("grant_type", "authorization_code"),
            ("client_id", &id),
            ("code", &code),
            ("code_verifier", &attempt.verifier),
            ("redirect_uri", &attempt.redirect),
            ("resource", RESOURCE),
        ]))?;
        let jwt = tokens["id_token"]
            .as_str()
            .ok_or("ChatGPT did not return an identity token.")?;
        let identity = oauth::identity(
            jwt,
            &json_body(
                http.get(&format!("{}/.well-known/jwks.json", self.issuer))
                    .call(),
            )?,
            &id,
            &attempt.nonce,
            now(),
        )?;
        if subject.as_ref().is_some_and(|s| s != &identity.subject) {
            return Err("The signed-in account differs from the selected account.".into());
        }
        let session = Session::issue(&tokens, None)?;
        if cancel.load(Ordering::Relaxed) {
            return Err("Sign-in cancelled.".into());
        }
        preferences::transact(file, |a: &mut Accounts| {
            if a.items
                .iter()
                .any(|x| x.id == id && x.subject != identity.subject)
            {
                return Err("This registration belongs to a different account.".into());
            }
            a.items.retain(|x| x.id != id);
            a.items.push(Account {
                id: id.clone(),
                subject: identity.subject,
                label: identity.label,
                session: Some(session),
            });
            a.active = Some(id.clone());
            Ok(())
        })?;
        Ok(id)
    }

    fn logout(&self, id: &str) -> ResultText<String> {
        let http = &self.http;
        preferences::transact(&self.file, |a: &mut Accounts| {
            let acc = a
                .items
                .iter_mut()
                .find(|x| x.id == id)
                .ok_or("Account unavailable.")?;
            let mut remote = true;
            if let Some(s) = acc.session.take() {
                if !s.refresh.is_empty() {
                    let fields = [
                        ("token", s.refresh.as_str()),
                        ("token_type_hint", "refresh_token"),
                        ("client_id", id),
                    ];
                    remote = success(http.post(&self.auth_endpoint("revoke")).send_form(&fields))
                        .is_ok();
                    if !remote {
                        std::thread::sleep(Duration::from_millis(300));
                        remote =
                            success(http.post(&self.auth_endpoint("revoke")).send_form(&fields))
                                .is_ok();
                    }
                }
            }
            Ok(if remote{"Signed out of this account."}else{"Signed out locally. Remote revocation was unconfirmed. Use Manage usage to disconnect CaDi in ChatGPT."}.into())
        })
    }
    fn token(&self, id: &str) -> ResultText<String> {
        let file = &self.file;
        let read = |accounts: Accounts| -> ResultText<Option<String>> {
            let s = accounts
                .items
                .into_iter()
                .find(|x| x.id == id)
                .and_then(|x| x.session)
                .ok_or("Continue with ChatGPT to sign in.")?;
            if !s.enabled() {
                return Err("Sign in again and allow CaDi to use your plan.".into());
            }
            Ok((s.expires > now() + 60).then_some(s.access))
        };
        if let Some(current) = read(preferences::load(file)?)? {
            return Ok(current);
        }
        // Serialize renewal and the atomic save of the rotated refresh token across app instances.
        preferences::transact(file, |a: &mut Accounts| {
            let acc = a
                .items
                .iter_mut()
                .find(|x| x.id == id)
                .ok_or("Account unavailable.")?;
            let s = acc
                .session
                .as_ref()
                .ok_or("Sign in again to use this account.")?;
            if !s.enabled() {
                return Err("Sign in again and allow CaDi to use your plan.".into());
            }
            if s.expires > now() + 60 {
                return Ok(Some(s.access.clone()));
            }
            if s.refresh.is_empty() {
                return Ok(None);
            }
            let result = self.http.post(&self.auth_endpoint("token")).send_form(&[
                ("grant_type", "refresh_token"),
                ("client_id", id),
                ("refresh_token", &s.refresh),
                ("resource", RESOURCE),
            ]);
            let v = match result {
                Err(ureq::Error::Status(status, r)) => {
                    let body: Value =
                        serde_json::from_reader(r.into_reader().take(16384)).unwrap_or(Value::Null);
                    if matches!(
                        error_code(&body),
                        "invalid_grant"
                            | "invalid_refresh_token"
                            | "token_expired"
                            | "refresh_token_expired"
                            | "refresh_token_invalidated"
                            | "refresh_token_reused"
                    ) {
                        acc.session = None;
                        return Ok(None);
                    }
                    return Err(known_error(error_code(&body), status));
                }
                other => json_body(other)?,
            };
            let fresh = Session::issue(&v, Some(s))?;
            let access = fresh.enabled().then(|| fresh.access.clone());
            acc.session = Some(fresh);
            Ok(access)
        })?
        .ok_or_else(|| "Please sign in again and allow ChatGPT plan usage.".into())
    }
}
#[derive(Clone)]
pub struct Model {
    pub slug: String,
    pub name: String,
}
fn catalog(v: &Value) -> ResultText<Vec<Model>> {
    let models: Vec<_> = v["models"]
        .as_array()
        .ok_or("ChatGPT returned no model catalog.")?
        .iter()
        .filter(|m| m["visibility"] == "list")
        .filter_map(|m| {
            let slug = m["slug"].as_str().filter(|s| !s.is_empty())?;
            Some(Model {
                slug: slug.into(),
                name: m["display_name"].as_str().unwrap_or(slug).into(),
            })
        })
        .collect();
    if models.is_empty() {
        return Err("This ChatGPT account has no available models for CaDi.".into());
    }
    Ok(models)
}
impl Client {
    fn models(&self, id: &str) -> ResultText<Vec<Model>> {
        let http = &self.http;
        let key = self.token(id)?;
        catalog(&json_body(
            http.get(&format!("{}/models", self.api))
                .set("Authorization", &format!("Bearer {key}"))
                .call(),
        )?)
    }
}
fn stream_text(body: &str) -> ResultText<String> {
    let mut text = String::new();
    let normalized = body.replace("\r\n", "\n");
    for event in normalized.split("\n\n") {
        let data = event
            .lines()
            .filter_map(|l| l.strip_prefix("data:"))
            .map(str::trim_start)
            .collect::<Vec<_>>()
            .join("\n");
        if data.is_empty() || data == "[DONE]" {
            continue;
        }
        let v: Value = serde_json::from_str(&data)
            .map_err(|_| "Could not read the ChatGPT response stream.")?;
        match v["type"].as_str() {
            Some("response.output_text.delta" | "response.refusal.delta") => {
                text.push_str(v["delta"].as_str().unwrap_or(""))
            }
            Some("response.completed") => {
                if text.trim().is_empty() {
                    return Err("ChatGPT completed the request without a text reply.".into());
                }
                return Ok(text);
            }
            Some("response.failed" | "error") => {
                return Err(known_error(
                    error_code(v.get("response").unwrap_or(&v)),
                    200,
                ))
            }
            Some("response.incomplete") => {
                return Err("ChatGPT reported an incomplete reply. Try a shorter question.".into())
            }
            _ => {}
        }
    }
    Err("The connection ended before ChatGPT confirmed the reply. Try again.".into())
}
impl Client {
    fn ask(
        &self,
        id: &str,
        model: &str,
        messages: &[crate::conversation::Message],
    ) -> ResultText<String> {
        if messages.is_empty() {
            return Err("Type a question first.".into());
        }
        if model.is_empty() {
            return Err("List models and choose one first.".into());
        }
        let http = &self.http;
        let key = self.token(id)?;
        let body = json!({"model":model,"instructions":crate::provider::PLAIN_HELP,"input":messages,"stream":true,"store":false});
        let r = success(
            http.post(&format!("{}/responses", self.api))
                .set("Authorization", &format!("Bearer {key}"))
                .set("Accept", "text/event-stream")
                .send_json(body),
        )?;
        let bytes = read_bytes(r.into_reader(), RESPONSE_CAP)?;
        stream_text(std::str::from_utf8(&bytes).map_err(|_| "ChatGPT returned unreadable text.")?)
    }
}
