use crate::{connector::edit_menu, provider};
use eframe::egui::{self, Key, KeyboardShortcut, Modifiers, RichText};
use serde::Serialize;

#[derive(Clone, Serialize)]
pub struct Message {
    pub role: &'static str,
    pub content: String,
}
impl Message {
    pub fn user(text: impl Into<String>) -> Self {
        Self {
            role: "user",
            content: text.into(),
        }
    }
    fn assistant(text: &str) -> Self {
        Self {
            role: "assistant",
            content: text.into(),
        }
    }
}

enum Reply {
    Waiting,
    Received(String),
    Failed(String),
}
struct Turn {
    question: String,
    audit: bool,
    reply: Reply,
}

#[derive(Default)]
pub struct Conversation {
    turns: Vec<Turn>,
    draft: String,
    attach: bool,
    reveal: bool,
}
impl Conversation {
    pub fn prepare_report(&mut self, explain: bool) {
        self.attach = true;
        if self.draft.trim().is_empty() && explain {
            self.draft="Explain this scan in plain English. Quote the finding that matters most, explain what it can and cannot tell me, and suggest one safe next check.".into();
        }
        self.reveal = true;
    }
    pub fn begin(&mut self, audit: Option<&str>) -> Result<Vec<Message>, String> {
        if self
            .turns
            .last()
            .is_some_and(|t| matches!(t.reply, Reply::Waiting))
        {
            return Err("Wait for the current reply before sending again.".into());
        }
        let report = if self.attach {
            Some(audit.ok_or("Run a scan before attaching a report.")?)
        } else {
            None
        };
        let question = match (self.draft.trim(), self.attach) {
            ("", true) => "Explain my scan results in plain language. What should I review first?",
            (q, _) => q,
        };
        let prompt = provider::prompt(question, report)?;
        let mut used = prompt.len();
        let mut recent = Vec::new();
        for turn in self.turns.iter().rev() {
            let Reply::Received(answer) = &turn.reply else {
                continue;
            };
            used += turn.question.len() + answer.len();
            if recent.len() == 8 || used > 96_000 {
                break;
            }
            recent.push(turn);
        }
        let mut messages = Vec::with_capacity(recent.len() * 2 + 1);
        for turn in recent.into_iter().rev() {
            if let Reply::Received(answer) = &turn.reply {
                messages.push(Message::user(&turn.question));
                messages.push(Message::assistant(answer));
            }
        }
        messages.push(Message::user(prompt));
        self.turns.push(Turn {
            question: question.into(),
            audit: self.attach,
            reply: Reply::Waiting,
        });
        self.reveal = true;
        self.draft.clear();
        self.attach = false;
        Ok(messages)
    }
    pub fn finish(&mut self, result: Result<String, String>) {
        let Some(turn) = self.turns.last_mut() else {
            return;
        };
        if !matches!(turn.reply, Reply::Waiting) {
            return;
        }
        turn.reply = match result {
            Ok(text) => Reply::Received(text),
            Err(reason) => {
                if self.draft.is_empty() && !self.attach {
                    self.draft = turn.question.clone();
                    self.attach = turn.audit;
                }
                Reply::Failed(reason)
            }
        };
    }
    pub fn show(
        &mut self,
        ui: &mut egui::Ui,
        enabled: bool,
        busy: bool,
        audit_available: bool,
    ) -> bool {
        ui.horizontal(|ui| {
            ui.heading("Conversation");
            if !self.turns.is_empty()
                && ui
                    .add_enabled(!busy, egui::Button::new("New chat"))
                    .clicked()
            {
                *self = Self::default();
            }
        });
        if !self.turns.is_empty() {
            egui::ScrollArea::vertical()
                .id_salt("messages")
                .max_height(210.)
                .stick_to_bottom(true)
                .show(ui, |ui| {
                    for (i, turn) in self.turns.iter().enumerate() {
                        ui.push_id(i, |ui| {
                            ui.label(
                                RichText::new(if turn.audit {
                                    "You · report attached"
                                } else {
                                    "You"
                                })
                                .strong(),
                            );
                            ui.add(egui::Label::new(&turn.question).selectable(true).wrap());
                            match &turn.reply {
                                Reply::Waiting => {
                                    ui.label("Waiting for a reply…");
                                }
                                Reply::Received(text) => {
                                    ui.horizontal(|ui| {
                                        ui.strong("Assistant");
                                        if ui.small_button("Copy reply").clicked() {
                                            ui.ctx().copy_text(text.clone());
                                        }
                                    });
                                    ui.add(egui::Label::new(text).selectable(true).wrap());
                                }
                                Reply::Failed(reason) => {
                                    ui.colored_label(ui.visuals().error_fg_color, reason);
                                }
                            }
                            ui.separator();
                        });
                    }
                });
        }
        let id = ui.make_persistent_id("message-draft");
        let editor = egui::ScrollArea::vertical()
            .id_salt("draft-scroll")
            .max_height(88.)
            .show(ui, |ui| {
                egui::TextEdit::multiline(&mut self.draft)
                    .id(id)
                    .desired_width(f32::INFINITY)
                    .desired_rows(3)
                    .hint_text(if self.turns.is_empty() {
                        "Ask a question or paste your results…"
                    } else {
                        "Write a follow-up…"
                    })
                    .return_key(KeyboardShortcut::new(Modifiers::SHIFT, Key::Enter))
                    .show(ui)
            })
            .inner;
        let focused = editor.response.has_focus();
        edit_menu(editor, &self.draft);
        ui.add_enabled(
            audit_available || self.attach,
            egui::Checkbox::new(
                &mut self.attach,
                "Include the selected report in this request",
            ),
        );
        let can_send = enabled
            && !busy
            && (!self.attach || audit_available)
            && (!self.draft.trim().is_empty() || self.attach);
        let enter=focused && can_send && ui.input(|i| i.events.iter().any(|e| matches!(e,egui::Event::Key{key:Key::Enter,pressed:true,repeat:false,modifiers,..} if modifiers.is_none())));
        let row = ui.horizontal_wrapped(|ui| {
            let clicked = ui
                .add_enabled(can_send, egui::Button::new("Send"))
                .clicked();
            ui.label("Enter to send · Shift+Enter for a new line");
            clicked
        });
        if std::mem::take(&mut self.reveal) {
            row.response.scroll_to_me(Some(egui::Align::Max));
        }
        let clicked = row.inner;
        if clicked || enter {
            ui.memory_mut(|m| m.request_focus(id));
        }
        clicked || enter
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn sending_clears_draft_and_follow_up_uses_both_roles_without_resending_raw_audit() {
        let mut c = Conversation {
            attach: true,
            ..Default::default()
        };
        let initial = c.begin(Some("private audit fixture")).unwrap();
        assert!(initial[0].content.contains("private audit fixture"));
        assert!(c.draft.is_empty() && !c.attach);
        c.draft = "What does that mean?".into();
        assert!(c.begin(None).is_err());
        c.finish(Ok("The firewall is enabled.".into()));
        let next = c.begin(None).unwrap();
        assert_eq!(next.len(), 3);
        assert_eq!(next[1].role, "assistant");
        assert_eq!(next[2].content, "What does that mean?");
        assert!(!next
            .iter()
            .any(|m| m.content.contains("private audit fixture")));
    }
    #[test]
    fn failed_message_preserves_a_newer_draft_and_is_excluded_from_history() {
        let mut c = Conversation {
            draft: "First".into(),
            ..Default::default()
        };
        c.begin(None).unwrap();
        c.draft = "New draft".into();
        c.finish(Err("Offline".into()));
        assert_eq!(c.draft, "New draft");
        assert_eq!(c.begin(None).unwrap().len(), 1);
        c.finish(Err("Offline".into()));
        assert_eq!(c.draft, "New draft");
    }
}
