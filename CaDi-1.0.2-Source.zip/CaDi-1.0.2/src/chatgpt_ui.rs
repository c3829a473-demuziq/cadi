use crate::{
    chatgpt::{self, Model, Saved},
    conversation::{Conversation, Message},
};
use eframe::egui::{self, RichText};
use std::{
    sync::{
        atomic::{AtomicBool, Ordering},
        mpsc, Arc,
    },
    thread,
    time::Duration,
};

enum Outcome {
    Connected(String),
    Models(Vec<Model>),
    Text(String),
    Message(String),
}
struct Pending {
    rx: mpsc::Receiver<Result<Outcome, String>>,
    cancel: Arc<AtomicBool>,
    login: bool,
}
#[derive(Default)]
pub struct PlanPanel {
    saved: Saved,
    loaded: bool,
    pending: Option<Pending>,
    models: Vec<Model>,
    model: String,
    chat: Conversation,
    status: String,
    error: bool,
}
impl Drop for PlanPanel {
    fn drop(&mut self) {
        if let Some(job) = &self.pending {
            job.cancel.store(true, Ordering::Relaxed);
        }
    }
}
impl PlanPanel {
    pub fn prepare_report(&mut self, explain: bool) {
        self.chat.prepare_report(explain);
    }
    pub fn busy(&self) -> bool {
        self.pending.is_some()
    }
    fn error(&mut self, message: String) {
        self.status = message;
        self.error = true;
    }
    fn reload(&mut self) {
        match chatgpt::saved() {
            Ok(saved) => self.saved = saved,
            Err(e) => self.error(e),
        }
    }
    fn reset_account(&mut self) {
        self.models.clear();
        self.model.clear();
        self.chat = Conversation::default();
        self.status.clear();
    }
    fn launch(
        &mut self,
        ctx: &egui::Context,
        login: bool,
        f: impl FnOnce(&AtomicBool) -> Result<Outcome, String> + Send + 'static,
    ) {
        let (tx, rx) = mpsc::channel();
        let cancel = Arc::new(AtomicBool::new(false));
        self.pending = Some(Pending {
            rx,
            cancel: cancel.clone(),
            login,
        });
        self.error = false;
        self.status = if login {
            "Finish signing in in your browser. Then return to CaDi."
        } else {
            "Connecting to ChatGPT…"
        }
        .into();
        let ctx = ctx.clone();
        thread::spawn(move || {
            let _ = tx.send(f(&cancel));
            ctx.request_repaint();
        });
    }
    fn refresh_models(&mut self, ctx: &egui::Context, id: String) {
        self.launch(ctx, false, move |_| {
            chatgpt::models(&id).map(Outcome::Models)
        });
    }
    fn poll(&mut self, ctx: &egui::Context) {
        let Some(job) = &self.pending else { return };
        let result = match job.rx.try_recv() {
            Ok(r) => r,
            Err(mpsc::TryRecvError::Empty) => {
                ctx.request_repaint_after(Duration::from_millis(180));
                return;
            }
            Err(_) => Err("The connection stopped. Try again.".into()),
        };
        self.pending = None;
        match result {
            Ok(Outcome::Connected(id)) => {
                self.reset_account();
                self.reload();
                if self.saved.choices.iter().any(|a| a.id == id && a.enabled) {
                    self.refresh_models(ctx, id);
                } else {
                    self.error("Signed in. To ask questions, sign in again and allow CaDi to use your ChatGPT plan.".into());
                }
            }
            Ok(Outcome::Models(models)) => {
                if !models.iter().any(|m| m.slug == self.model) {
                    self.model = models[0].slug.clone();
                }
                self.models = models;
                self.status = "ChatGPT models are ready.".into();
            }
            Ok(Outcome::Text(text)) => {
                self.chat.finish(Ok(text));
                self.status.clear();
            }
            Ok(Outcome::Message(message)) => {
                self.reload();
                self.status = message;
            }
            Err(e) => {
                self.chat.finish(Err(e.clone()));
                self.reload();
                self.error(e);
            }
        }
    }
    pub fn show(&mut self, ui: &mut egui::Ui, ctx: &egui::Context, audit: Option<&str>) {
        if !self.loaded {
            self.loaded = true;
            self.reload();
            if let Some(a) = self
                .saved
                .choices
                .iter()
                .find(|a| Some(&a.id) == self.saved.active.as_ref() && a.enabled)
            {
                self.refresh_models(ctx, a.id.clone());
            }
        }
        self.poll(ctx);
        let current = self
            .saved
            .choices
            .iter()
            .find(|a| Some(&a.id) == self.saved.active.as_ref())
            .cloned();
        ui.label("Use your ChatGPT plan to ask questions. Sign in through your browser.");
        ui.add_enabled_ui(!self.busy(), |ui| {
            let mut selected = self.saved.active.clone();
            if !self.saved.choices.is_empty() {
                egui::ComboBox::from_id_salt("chatgpt-account")
                    .selected_text(
                        current
                            .as_ref()
                            .map(|a| a.label.as_str())
                            .unwrap_or("Choose account"),
                    )
                    .show_ui(ui, |ui| {
                        for a in &self.saved.choices {
                            ui.selectable_value(&mut selected, Some(a.id.clone()), &a.label);
                        }
                    });
            }
            if selected != self.saved.active {
                if let Some(id) = selected {
                    match chatgpt::select(&id) {
                        Ok(()) => {
                            self.reset_account();
                            self.reload();
                            if self.saved.choices.iter().any(|a| a.id == id && a.enabled) {
                                self.refresh_models(ctx, id);
                            }
                        }
                        Err(e) => self.error(e),
                    }
                }
                return;
            }
            ui.horizontal_wrapped(|ui| {
                if current.as_ref().is_none_or(|a| !a.enabled)
                    && ui.button("Continue with ChatGPT").clicked()
                {
                    let known = self.saved.active.clone();
                    self.launch(ctx, true, move |c| {
                        chatgpt::login(known.as_deref(), c).map(Outcome::Connected)
                    });
                }
                if let Some(a) = &current {
                    if ui.button("Add account").clicked() {
                        self.launch(ctx, true, |c| {
                            chatgpt::login(None, c).map(Outcome::Connected)
                        });
                    }
                    if a.signed_in && ui.button("Sign out").clicked() {
                        let id = a.id.clone();
                        self.reset_account();
                        self.launch(ctx, false, move |_| {
                            chatgpt::logout(&id).map(Outcome::Message)
                        });
                    }
                    ui.hyperlink_to("Manage usage", "https://chatgpt.com/settings/usage");
                }
            });
            let Some(account) = current.as_ref().filter(|a| a.enabled) else {
                return;
            };
            ui.horizontal_wrapped(|ui| {
                ui.label("Model");
                egui::ComboBox::from_id_salt("plan-model")
                    .selected_text(
                        self.models
                            .iter()
                            .find(|m| m.slug == self.model)
                            .map(|m| m.name.as_str())
                            .unwrap_or("Choose a model"),
                    )
                    .show_ui(ui, |ui| {
                        for m in &self.models {
                            ui.selectable_value(&mut self.model, m.slug.clone(), &m.name);
                        }
                    });
                if ui.button("List models").clicked() {
                    self.refresh_models(ctx, account.id.clone());
                }
                if ui
                    .add_enabled(!self.model.is_empty(), egui::Button::new("Test model"))
                    .clicked()
                {
                    let id = account.id.clone();
                    let model = self.model.clone();
                    self.launch(ctx, false, move |_| {
                        chatgpt::ask(&id, &model, &[Message::user("Reply with OK.")]).map(|_| {
                            Outcome::Message("Connected. The model returned a reply.".into())
                        })
                    });
                }
            });
        });
        if let Some(job) = &self.pending {
            ui.horizontal(|ui| {
                ui.spinner();
                if job.login && ui.button("Cancel sign-in").clicked() {
                    job.cancel.store(true, Ordering::Relaxed);
                }
            });
        }
        if !self.status.is_empty() {
            ui.label(RichText::new(&self.status).color(if self.error {
                ui.visuals().error_fg_color
            } else if self.busy() {
                ui.visuals().weak_text_color()
            } else {
                ui.visuals().hyperlink_color
            }));
        }
        if let Some(account) = self
            .saved
            .choices
            .iter()
            .find(|a| Some(&a.id) == self.saved.active.as_ref() && a.enabled)
        {
            let id = account.id.clone();
            ui.add_space(8.);
            let busy = self.busy();
            let send = ui
                .push_id("subscription-chat", |ui| {
                    self.chat
                        .show(ui, !self.model.is_empty(), busy, audit.is_some())
                })
                .inner;
            if send {
                match self.chat.begin(audit) {
                    Ok(messages) => {
                        let model = self.model.clone();
                        self.launch(ctx, false, move |_| {
                            chatgpt::ask(&id, &model, &messages).map(Outcome::Text)
                        });
                    }
                    Err(reason) => self.error(reason),
                }
            }
        }
    }
}
