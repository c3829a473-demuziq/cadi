use eframe::egui::{self, Color32, FontFamily, FontId, Stroke, TextStyle};
use serde::{Deserialize, Serialize};

#[derive(Default, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Appearance {
    #[default]
    Light,
    Dark,
}

pub struct Colors {
    pub page: Color32,
    pub sidebar: Color32,
    pub card: Color32,
    pub border: Color32,
    pub text: Color32,
    pub secondary: Color32,
    pub accent: Color32,
    pub selected: Color32,
    pub warning: Color32,
    pub unknown: Color32,
    pub error: Color32,
}
impl Appearance {
    pub fn colors(self) -> Colors {
        let rgb = Color32::from_rgb;
        match self {
            Self::Light => Colors {
                page: rgb(249, 251, 252),
                sidebar: rgb(231, 238, 240),
                card: Color32::WHITE,
                border: rgb(112, 127, 133),
                text: rgb(19, 32, 38),
                secondary: rgb(55, 75, 84),
                accent: rgb(0, 86, 68),
                selected: rgb(204, 232, 222),
                warning: rgb(119, 61, 0),
                unknown: rgb(82, 48, 117),
                error: rgb(147, 27, 46),
            },
            Self::Dark => Colors {
                page: rgb(16, 23, 29),
                sidebar: rgb(25, 34, 41),
                card: rgb(32, 43, 51),
                border: rgb(123, 146, 156),
                text: rgb(249, 253, 255),
                secondary: rgb(215, 228, 234),
                accent: rgb(154, 250, 208),
                selected: rgb(44, 71, 67),
                warning: rgb(255, 207, 150),
                unknown: rgb(229, 204, 255),
                error: rgb(255, 176, 179),
            },
        }
    }
    pub fn apply(self, ctx: &egui::Context) {
        let c = self.colors();
        let (mut v, t) = match self {
            Self::Light => (egui::Visuals::light(), egui::Theme::Light),
            Self::Dark => (egui::Visuals::dark(), egui::Theme::Dark),
        };
        ctx.set_theme(t);
        v.panel_fill = c.page;
        v.window_fill = c.card;
        v.extreme_bg_color = c.card;
        v.text_edit_bg_color = Some(c.card);
        v.override_text_color = Some(c.text);
        v.weak_text_color = Some(c.secondary);
        v.error_fg_color = c.error;
        v.warn_fg_color = c.warning;
        v.hyperlink_color = c.accent;
        v.selection.bg_fill = c.selected;
        v.selection.stroke = Stroke::new(1.5, c.text);
        v.disabled_alpha = 0.76;
        for w in [
            &mut v.widgets.noninteractive,
            &mut v.widgets.inactive,
            &mut v.widgets.hovered,
            &mut v.widgets.active,
            &mut v.widgets.open,
        ] {
            w.fg_stroke = Stroke::new(1.5, c.text);
            w.bg_stroke = Stroke::new(1., c.border);
        }
        v.widgets.inactive.weak_bg_fill = c.sidebar;
        v.widgets.hovered.weak_bg_fill = c.selected;
        v.widgets.active.weak_bg_fill = c.selected;
        v.widgets.open.weak_bg_fill = c.selected;
        ctx.set_visuals(v);
        ctx.style_mut(|s| {
            for (style, size) in [
                (TextStyle::Body, 16.),
                (TextStyle::Button, 16.),
                (TextStyle::Small, 14.),
            ] {
                s.text_styles
                    .insert(style, FontId::new(size, FontFamily::Proportional));
            }
            s.text_styles
                .insert(TextStyle::Monospace, FontId::monospace(15.));
            s.spacing.button_padding = egui::vec2(7., 4.);
        });
    }
}
