use serde::{de::DeserializeOwned, Serialize};
use std::{
    fs::{self, File},
    io::{ErrorKind, Write},
    path::{Path, PathBuf},
};

pub fn directory() -> Result<PathBuf, String> {
    if cfg!(windows) {
        return std::env::var_os("LOCALAPPDATA")
            .map(|p| PathBuf::from(p).join("CaDi"))
            .ok_or_else(|| "Cannot locate local app data.".into());
    }
    let home = PathBuf::from(std::env::var_os("HOME").ok_or("Cannot find your home directory.")?);
    if cfg!(target_os = "macos") {
        Ok(home.join("Library/Application Support/CaDi"))
    } else {
        Ok(std::env::var_os("XDG_CONFIG_HOME")
            .map(PathBuf::from)
            .filter(|p| p.is_absolute())
            .unwrap_or_else(|| home.join(".config"))
            .join("cadi"))
    }
}
pub fn load<T: DeserializeOwned + Default>(path: &Path) -> Result<T, String> {
    match fs::read(path) {
        Ok(bytes) => serde_json::from_slice(&bytes).map_err(|_| {
            format!(
                "Could not read {}. The existing file was preserved.",
                path.display()
            )
        }),
        Err(e) if e.kind() == ErrorKind::NotFound => Ok(T::default()),
        Err(e) => Err(e.to_string()),
    }
}
pub fn update<T: DeserializeOwned + Serialize + Default + Clone>(
    path: &Path,
    edit: impl FnOnce(&mut T),
) -> Result<T, String> {
    transact(path, |data: &mut T| {
        edit(data);
        Ok(data.clone())
    })
}

pub fn transact<T: DeserializeOwned + Serialize + Default, R>(
    path: &Path,
    edit: impl FnOnce(&mut T) -> Result<R, String>,
) -> Result<R, String> {
    let dir = path.parent().ok_or("Missing settings directory.")?;
    fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    let lock = File::options()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(path.with_extension("lock"))
        .map_err(|e| e.to_string())?;
    lock.lock().map_err(|e| e.to_string())?;
    let mut data = load(path)?;
    let result = edit(&mut data)?;
    let mut f = tempfile::NamedTempFile::new_in(dir).map_err(|e| e.to_string())?;
    serde_json::to_writer_pretty(f.as_file_mut(), &data).map_err(|e| e.to_string())?;
    f.flush()
        .and_then(|_| f.as_file().sync_all())
        .map_err(|e| e.to_string())?;
    f.persist(path).map_err(|e| e.to_string())?;
    Ok(result)
}
