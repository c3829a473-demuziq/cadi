use eframe::egui;

#[derive(Default)]
pub struct Monitor {
    pub args: Vec<String>,
    phone: String,
    endpoint: String,
    model: String,
    file: String,
    folder: String,
}
impl Monitor {
    pub fn show(&mut self, ui: &mut egui::Ui, available: bool) -> bool {
        let mut command = None;
        ui.label("Watch SSH and remote-desktop connections while signed in, including after this window closes. New connections generate local alerts. Your device must be awake.");
        ui.add_enabled_ui(available,|ui|{
            ui.horizontal_wrapped(|ui|{
                for (label, action) in [("Refresh incidents","events"),("Enable background alerts","enable"),("Turn off","disable")]{
                    if ui.button(label).clicked(){command=Some(vec!["watch".into(),action.into()]);}
                }
            });
            ui.collapsing("Phone and on-device AI (optional)",|ui|{
                ui.label("Phone alerts contain a generic notice. Use a private HTTPS ntfy topic you control and subscribe to it on your phone.");
                ui.add(egui::TextEdit::singleline(&mut self.phone).password(true).hint_text("Private HTTPS topic URL"));
                ui.horizontal_wrapped(|ui|{
                    if ui.add_enabled(!self.phone.trim().is_empty(),egui::Button::new("Enable phone alerts")).clicked(){command=Some(vec!["watch".into(),"phone".into(),self.phone.trim().into()]);}
                    if ui.button("Disable phone alerts").clicked(){command=Some(vec!["watch".into(),"phone".into()]);}
                });
                ui.label("Optional automatic explanations use a model served on this device. CaDi sends only the service names, at most once per ten minutes.");
                ui.add(egui::TextEdit::singleline(&mut self.endpoint).hint_text("http://127.0.0.1:11434/v1"));
                ui.add(egui::TextEdit::singleline(&mut self.model).hint_text("Local model ID"));
                ui.horizontal_wrapped(|ui|{
                    if ui.add_enabled(!self.model.trim().is_empty(),egui::Button::new("Enable local explanations")).clicked(){
                        command=Some(vec!["watch".into(),"model".into(),self.endpoint.trim().into(),self.model.trim().into()]);
                    }
                    if ui.button("Disable local explanations").clicked(){command=Some(vec!["watch".into(),"model".into()]);}
                });
            });
            ui.collapsing("Back up or recover a file",|ui|{
                ui.label("Save a copy before an incident. To recover it, enter the .cadi backup path and a destination folder. Recovery writes a new file.");
                ui.add(egui::TextEdit::singleline(&mut self.file).desired_width(f32::INFINITY).hint_text("Full path to the original file or .cadi backup"));
                ui.add(egui::TextEdit::singleline(&mut self.folder).desired_width(f32::INFINITY).hint_text("Full path to an existing destination folder"));
                ui.horizontal_wrapped(|ui|{
                    for (label, op) in [("Save backup","backup"),("Restore copy","restore")]{
                        if ui.add_enabled(!self.file.is_empty() && !self.folder.is_empty(),egui::Button::new(label)).clicked(){
                            command=Some(vec![op.into(),self.file.clone(),self.folder.clone()]);
                        }
                    }
                });
            });
        });
        if let Some(args) = command {
            self.args = args;
            true
        } else {
            false
        }
    }
}
