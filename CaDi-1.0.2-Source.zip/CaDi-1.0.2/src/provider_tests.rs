use super::*;
fn request(
    p: &Profile,
    key: &str,
    op: Operation,
    question: &str,
    audit: Option<&str>,
) -> Result<Reply, String> {
    let messages = if op == Operation::Ask {
        vec![crate::conversation::Message::user(prompt(question, audit)?)]
    } else {
        vec![]
    };
    super::request(p, key, op, &messages)
}
use std::{
    io::{BufRead, BufReader, Write},
    net::TcpListener,
    thread,
};
struct Wire {
    line: String,
    headers: Vec<String>,
    body: Value,
}
fn server(reply: &str, status: &str, extra: &str) -> (String, thread::JoinHandle<Wire>) {
    let socket = TcpListener::bind(("127.0.0.1", 0)).unwrap();
    let base = format!("http://{}/v1", socket.local_addr().unwrap());
    let output=format!("HTTP/1.1 {status}\r\nConnection: close\r\nContent-Type: application/json\r\n{extra}Content-Length: {}\r\n\r\n{reply}",reply.len());
    let t = thread::spawn(move || {
        let (mut stream, _) = socket.accept().unwrap();
        let mut read = BufReader::new(stream.try_clone().unwrap());
        let mut line = String::new();
        read.read_line(&mut line).unwrap();
        let mut headers = Vec::new();
        let mut len = 0;
        loop {
            let mut h = String::new();
            read.read_line(&mut h).unwrap();
            if h == "\r\n" {
                break;
            }
            if let Some((name, v)) = h.split_once(':') {
                if name.eq_ignore_ascii_case("content-length") {
                    len = v.trim().parse().unwrap();
                }
            }
            headers.push(h.trim().to_lowercase());
        }
        let mut bytes = vec![0; len];
        read.read_exact(&mut bytes).unwrap();
        stream.write_all(output.as_bytes()).unwrap();
        Wire {
            line,
            headers,
            body: serde_json::from_slice(&bytes).unwrap_or(Value::Null),
        }
    });
    (base, t)
}
fn profile(base: String, format: Format) -> Profile {
    Profile {
        name: "Example".into(),
        base,
        model: "local-test".into(),
        auth: if format == Format::Anthropic {
            Auth::XApiKey
        } else {
            Auth::Bearer
        },
        format,
    }
}
#[test]
fn compatible_provider_and_opt_in_data() {
    let (url, c) = server(
        r#"{"choices":[{"message":{"content":"OK"}}]}"#,
        "200 OK",
        "",
    );
    let p = profile(url, Format::Chat);
    assert!(
        matches!(request(&p,"fixture",Operation::Ask,"hello",None),Ok(Reply::Text(s)) if s=="OK")
    );
    let w = c.join().unwrap();
    assert!(w.line.starts_with("POST /v1/chat/completions "));
    assert!(w.headers.contains(&"authorization: bearer fixture".into()));
    assert_eq!(w.body["messages"][0]["content"], PLAIN_HELP);
    assert_eq!(w.body["messages"][1]["content"], "hello");
}
#[test]
fn native_anthropic_messages_and_auth() {
    let (url, c) = server(
        r#"{"content":[{"type":"text","text":"answer"}]}"#,
        "200 OK",
        "",
    );
    let p = profile(url, Format::Anthropic);
    assert!(
        matches!(request(&p,"fixture",Operation::Ask,"explain",Some("TEST-REPORT")),Ok(Reply::Text(s)) if s=="answer")
    );
    let w = c.join().unwrap();
    assert!(w.line.starts_with("POST /v1/messages "));
    assert!(w.headers.contains(&"x-api-key: fixture".into()));
    assert!(w.headers.contains(&"anthropic-version: 2023-06-01".into()));
    assert!(w.body["messages"][0]["content"]
        .as_str()
        .unwrap()
        .contains("TEST-REPORT"));
}
#[test]
fn responses_api_test_never_attaches_audit() {
    let (url, c) = server(
        r#"{"output":[{"type":"message","content":[{"type":"output_text","text":"OK"}]}]}"#,
        "200 OK",
        "",
    );
    let p = profile(url, Format::Responses);
    assert!(
        matches!(request(&p,"",Operation::Test,"",Some("private fixture")),Ok(Reply::Text(s)) if s=="OK")
    );
    let w = c.join().unwrap();
    assert!(w.line.starts_with("POST /v1/responses "));
    assert_eq!(w.body["store"], false);
    assert_eq!(w.body["input"][0]["content"], "Reply with OK.");
}
#[test]
fn errors_and_redirects_do_not_echo_secrets() {
    for (status, extra) in [
        ("401 Unauthorized", ""),
        ("302 Found", "Location: http://127.0.0.1:1/\r\n"),
    ] {
        let (url, c) = server("fixture-private-key", status, extra);
        let result = request(
            &profile(url, Format::Chat),
            "fixture-private-key",
            Operation::Models,
            "",
            None,
        );
        let Err(message) = result else {
            panic!("expected an HTTP error")
        };
        assert!(message.contains(&status[..3]));
        assert!(!message.contains("fixture-private-key"));
        c.join().unwrap();
    }
}
#[test]
fn model_list_and_private_endpoints() {
    let (url, c) = server(
        r#"{"data":[{"id":"qwen"},{"id":"a"},{"id":"qwen"}]}"#,
        "200 OK",
        "",
    );
    let p = profile(url, Format::Chat);
    assert!(
        matches!(request(&p,"",Operation::Models,"",None),Ok(Reply::Models(ids)) if ids==["a","qwen"])
    );
    let w = c.join().unwrap();
    assert!(w.line.starts_with("GET /v1/models "));
    assert!(!w.headers.iter().any(|h| h.starts_with("authorization:")));
    let p = profile("http://example.org/v1".into(), Format::Chat);
    assert!(matches!(request(&p,"key",Operation::Test,"",None),Err(e) if e.contains("HTTPS")));
}
#[test]
fn endpoint_identity_is_bound_to_profile_and_origin() {
    let mut p = profile("https://cloud.example/v1".into(), Format::Chat);
    let id = p.key_id().unwrap();
    p.base.push('/');
    assert_eq!(p.key_id().unwrap(), id);
    p.base = "https://other.example/v1".into();
    assert_ne!(p.key_id().unwrap(), id);
    p.base = "https://cloud.example/v1?key=secret".into();
    assert!(p.key_id().is_err());
    p.base = "https://user:secret@cloud.example/v1".into();
    assert!(p.key_id().is_err());
}
#[test]
#[ignore = "requires an explicitly started local inference server"]
fn real_local_inference() {
    let p = profile(std::env::var("CADI_LOCAL_TEST_URL").unwrap(), Format::Chat);
    assert!(
        matches!(request(&p,"",Operation::Models,"",None),Ok(Reply::Models(v)) if v.contains(&p.model))
    );
    let result = request(&p, "", Operation::Ask, "Once upon a time", None);
    match result {
        Ok(Reply::Text(text)) => assert!(!text.trim().is_empty()),
        Err(e) => panic!("{e}"),
        _ => panic!("text expected"),
    }
}

#[test]
fn pasted_key_tolerates_outer_whitespace_and_rejects_a_second_line() {
    assert_eq!(clean_key("  fixture-key\r\n").unwrap(), "fixture-key");
    assert!(clean_key("fixture\nsecond").is_err());
    assert!(clean_key("fixture key").is_err());
}
#[test]
fn openai_uses_a_text_model_and_preserves_manual_selection() {
    let index = PRESETS.iter().position(|p| p.0 == "OpenAI").unwrap();
    let mut profile = Profile::preset(index);
    assert_eq!(profile.model, OPENAI_DEFAULT_MODEL);
    profile.select_listed_model(&["a-speech-model".into(), "gpt-4.1".into()]);
    assert_eq!(profile.model, "gpt-4.1");
    profile.model = "my-custom-model".into();
    profile.select_listed_model(&["a-speech-model".into()]);
    assert_eq!(profile.model, "my-custom-model");
    profile.model.clear();
    profile.select_listed_model(&["a-speech-model".into()]);
    assert!(profile.model.is_empty());
    assert!(
        matches!(request(&profile,"",Operation::Models,"",None),Err(e) if e.contains("OpenAI Platform API key"))
    );
    profile.base = "https://chatgpt.com".into();
    assert!(profile.base_url().is_err());
}
#[test]
fn billing_errors_and_rate_limits_are_distinct_without_echoing_provider_messages() {
    let quota = status_hint(
        429,
        br#"{"error":{"code":"insufficient_quota","message":"do-not-echo"}}"#.as_slice(),
    );
    let rate = status_hint(
        429,
        br#"{"error":{"code":"rate_limit_exceeded"}}"#.as_slice(),
    );
    assert!(quota.contains("billing") && !quota.contains("do-not-echo"));
    assert!(rate.contains("Wait"));
}
