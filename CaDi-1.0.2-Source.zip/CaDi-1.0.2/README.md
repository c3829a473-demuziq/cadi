# CaDi

CaDi helps you audit and harden devices you administer. Start with a read-only scan, review its findings, and choose which changes to apply. Then run the scan again to verify the result.

- Review listening services, selected security settings, kernel fixes, and running processes.
- Get local alerts for newly observed remote-access connections. CaDi does not automatically disconnect anyone.
- Back up a file and restore a verified copy. CaDi cannot recover a copy someone already took.

## Get started

See the [quick start](QUICKSTART.md) for platform instructions. Start with a scan; you do not need to sign in or enable background alerts. On Debian, you can run a read-only scan directly from this repository with Python: `python3 -I -B engine/cadi_guard.py audit`.

**Validation:** See the 1.0.2 verification report for platform-specific coverage. See the [verification report](validation/RESULTS.md) for what was tested and what is still open.

## Privacy and optional AI

In **Connector**, sign in with ChatGPT or connect using your own API key. Preview the selected report before sending it.

## Connect a model

Open **Connector**. Use **ChatGPT subscription → Continue with ChatGPT** for eligible ChatGPT plans. Use **API key or local model** for OpenAI, Anthropic, Ollama, LM Studio, or a compatible endpoint. **List models** queries the endpoint. **Test model** makes a short inference request. **Send** submits the draft and any report visibly selected for sharing. **New chat** clears the displayed conversation. [OpenAI sign-in guidance](https://developers.openai.com/siwc/token-sharing-open-source)

## What the checks cover

- **Kernel** compares selected fix levels for Ventura or Sonoma (CVE-2024-23225), Windows builds 19044/19045/22621/22631 (CVE-2024-30088), Debian Bullseye or Bookworm (CVE-2024-1086), and Debian Trixie (CVE-2025-38686). OS update and protection checks are independent of those bundled rules. Linux also reads CPU mitigations reported by the running kernel. [Apple advisory](https://support.apple.com/en-us/120886) · [Microsoft advisory](https://msrc.microsoft.com/update-guide/vulnerability/CVE-2024-30088) · [Debian Trixie advisory](https://security-tracker.debian.org/tracker/CVE-2025-38686)
- **Harden Mac** lets you select and apply the firewall and stealth settings locally, then reads the resulting values. **Hardening plan** previews additional OS-specific changes. Use the restore information and verify your own remote access before applying network settings.

## Build from source

Use Rust 1.90 or later. On an Intel Mac with Xcode Command Line Tools, run `python3 tools/build_mac.py`. This verifies and embeds the pinned Python runtime, signs the bundle locally and creates a ZIP. On a native Debian desktop or Windows x64 developer machine, run `cargo build --locked --release`. Rename the resulting executable to **CaDi** or **CaDi.exe**, place the included **engine** folder beside it, and on Windows unpack the official x64 Python embeddable distribution into **runtime** beside the executable. The Windows release used CPython 3.14.10. Linux uses system Python at /usr/bin/python3 and requires an X11/XWayland display and working OpenGL for the desktop.

For headless use, run `python3 -I -B engine/cadi_guard.py --help`. Installing the Python engine also provides the `cadi-guard` command. Normal scans do not require an AI account.

## Verify

Run `cargo test --locked` and `python3 -B -m unittest discover -s engine/tests` on Linux. The optional local inference test needs a running model endpoint and CADI_LOCAL_TEST_URL. The source includes the guarded Debian VM scenario and the separate systemd user-service registration check. The VM scenario expects the engine, tests, Rust test executable, llama.cpp, and the TinyStories smoke model. Run the scenarios only in the disposable guest described in the validation evidence. [Release verification](validation/RESULTS.md)


## License

CaDi's own code is available under the [MIT License](LICENSE). Bundled third-party components retain their own [notices](macos/Licenses).
