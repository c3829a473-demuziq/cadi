# CaDi v1

Before replacing a previous build, turn off its background alerts and quit it. Extract the full download and enable the alerts you want. If you use the optional Connector, sign in again with your own account. Put the app where you want to keep it before enabling background alerts.

- **Intel Mac** — open CaDi v1.app. The app includes Python. This test release is ad-hoc signed and has no Apple notarization.
- **Windows 10 or 11 x64** — open CaDi.exe. Python is included. The executable has no Authenticode publisher signature.
- **Debian 13 x64 desktop** — run `./CaDi` with X11 or XWayland, OpenGL, system Python 3.9 or later and libssl3 available. On a headless Debian server, run `python3 -I -B engine/cadi_guard.py kernel`. Substitute `processes`, `audit`, or `watch events` for other reports.

## Understand a scan

Choose a scan, run it, and click **Explain this scan**. Connector selects a timestamped report and drafts a question. **Preview report to share** shows the exact report. Click **Send** when you are ready. **Ask Connector** opens a draft for your own question. The report menu lets you choose a different completed scan. PIDs can be reused, so check the timestamp. Earlier messages and replies from the current thread provide limited follow-up context.

Staying signed in and running local scans use no hosted AI tokens. **Send** and **Test model** generate model requests. Hosted requests can use a subscription allowance or incur API charges. Saved API keys use Keychain on macOS. Keys entered on Windows or Linux are available for the session.

## Review a connection alert

Open **Incident monitor → Enable background alerts**. The watcher checks established TCP connections about every 15 seconds on local ports 22, 3283, 3389 and 5900. It continues after closing the window and starts again at sign-in. **Refresh incidents** displays the last successful sample time and recent observations. Desktop notifications depend on OS notification permissions and a running display session. A headless server records incidents locally. Short connections between checks can be missed. A person using an existing session may create no new observation.

The default response is a local alert. CaDi preserves the connection, so you can review the service, peer and time before deciding what to do. An established connection can belong to you or someone you authorized. In a known breach, isolate the host from its local console and secure the affected accounts from a separate trusted device. Phone alerts stay off until you enable a private HTTPS ntfy topic and subscribe to that same topic on your phone. CaDi sends a generic notice without a peer address. Network outages can prevent delivery. The local incident log retains up to 150 alert groups and the viewer shows the most recent 20.

Optional automatic AI explanations require an on-device, loopback-only model server and an explicitly supplied model ID. The worker shares only the service names, asks for at most 160 output tokens, and makes at most one model request per ten minutes. Choose a genuinely local model if you want to avoid an upstream bill. The worker cannot run model-suggested commands.

## Startup before login

Ordinary background registration runs under your user account. To cover logged-out time on Debian, enable the watcher in CaDi, then use `sudo loginctl enable-linger YOUR_USERNAME`. The user service can then start at boot. To stop it, choose **Turn off** or run `python3 -I -B engine/cadi_guard.py watch disable`.

The downloads also include **install_boot_watch.py** for an administrator who wants boot monitoring for a regular account on macOS or Windows. The helper registers a LaunchDaemon under the chosen user on macOS or a limited S4U startup task on Windows. Enable ordinary background monitoring first. Run the helper from a trusted, administrator-controlled installation with `install --user USER --watch-script FULL_PATH_TO_cadi_watch.py`. Run it with `remove` to remove the additional startup registration. macOS ships both scripts in the app’s `Contents/Resources` folder. Use a trusted, system-installed Python interpreter with `-I` to run administrative setup. After reboot, use the last successful sample time to verify operation. Pre-login Mac and Windows registration still needs native validation. Powered-off, suspended, locked encrypted boot volumes and OS policy can limit coverage.

## Process review

**Processes** compares two OS lists twice. It flags repeated disagreements and explains limits on visibility. On a compromised OS both lists can omit the same process. **Review** shows the available identity information. CaDi offers a quit request for eligible third-party GUI apps owned by the logged-in user on macOS and Windows. On Linux, it offers SIGTERM for ordinary user-owned executables below the user’s home directory when a kernel process handle is available. The request checks the process identity again. Save work before requesting a quit. A process can decline or restart.

## Recover a file

Under **Incident monitor → Back up or recover a file**, enter a full source file path and an existing folder, ideally on an external drive. **Save backup** creates a .cadi archive for one file up to 512 MiB. Store sensitive backups on an encrypted, disconnected drive and keep a trusted copy. To recover, enter the .cadi file path and destination folder and choose **Restore copy**. CaDi verifies the stored checksum and writes a new file. An archive made after theft cannot take back an attacker’s copy.

## Kernel checks

**Kernel check** combines selected vendor advisory comparisons, OS-reported protections and update information where available. **Unknown** means the check lacks evidence for a conclusion.


## Stop using CaDi

1. Turn off background alerts in **Incident monitor**. If you separately installed pre-login monitoring, use the same setup helper with `remove`.
2. If you used Connector, sign out, then quit CaDi.
3. Remove the app or extracted folder. Keep your backups somewhere safe first. Removing CaDi does not undo security settings you chose to apply.
